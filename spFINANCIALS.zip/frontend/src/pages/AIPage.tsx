import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { aiApi } from "../services/api";
import { Brain, AlertTriangle, TrendingUp, Search, Sparkles, Zap } from "lucide-react";
import AnalysisPanel from "../components/analysis/AnalysisPanel";
import { PortfolioHealthW } from "../widgets/Widgets";

// ── Company Analysis Search ───────────────────────────────────
function CompanyAnalysis() {
  const [symbol, setSymbol] = useState("");
  const [searched, setSearched] = useState("");

  const QUICK = [["2222","أرامكو"],["1120","الراجحي"],["2010","سابك"],["7010","stc"],["1180","الأهلي"]];

  return (
    <div className="card space-y-4">
      <div className="flex items-center gap-2">
        <Search size={16} className="text-blue-400" />
        <h2 className="text-sm font-bold text-slate-300">تحليل أي سهم برمزه</h2>
      </div>
      <div className="flex gap-2">
        <input className="input flex-1" placeholder="أدخل رمز السهم مثل: 2222 أو 1120"
          value={symbol} onChange={e => setSymbol(e.target.value.toUpperCase())}
          onKeyDown={e => e.key === "Enter" && symbol && setSearched(symbol)} />
        <button className="btn-primary shrink-0" onClick={() => symbol && setSearched(symbol)} disabled={!symbol}>
          <Search size={15} /> تحليل
        </button>
      </div>
      <div className="flex gap-2 flex-wrap">
        {QUICK.map(([sym, name]) => (
          <button key={sym} className="tag-b cursor-pointer hover:opacity-80" style={{padding: "5px 12px", border: "none"}}
            onClick={() => { setSymbol(sym); setSearched(sym); }}>{sym} {name}</button>
        ))}
      </div>
      {searched && <AnalysisPanel symbol={searched} />}
    </div>
  );
}


// ── Portfolio insight — fair value + safety per holding (investing.com style) ──
// investing.com-style fair value indicator: a bar starting at the centre
// (price == fair value) that leans toward the tier the stock currently sits in.
function fairValueTier(upside: number | null) {
  if (upside == null) return { label: "غير متاح", color: "#64748b" };
  if (upside >= 25) return { label: "تقييم مبخس", color: "#10b981" };
  if (upside >= 8)  return { label: "جيد",         color: "#34d399" };
  if (upside > -8)  return { label: "عادل",         color: "#f59e0b" };
  if (upside > -25) return { label: "مرتفع",        color: "#fb923c" };
  return                    { label: "مبالغ فيه",   color: "#f43f5e" };
}

function FairValueBar({ upside }: { upside: number | null }) {
  const tier = fairValueTier(upside);
  if (upside == null) return <span className="text-xs text-slate-500">{tier.label}</span>;
  const dev = Math.max(-50, Math.min(50, upside));
  const pos = 50 + dev; // 0..100%, 50 = centre (price == fair value)
  return (
    <div style={{ width: 96 }} dir="ltr">
      <div className="text-[11px] font-bold mb-1.5" style={{ color: tier.color }}>{tier.label}</div>
      <div className="relative h-1.5 rounded-full" style={{ background: "linear-gradient(90deg, #f43f5e, #f59e0b 50%, #10b981)" }}>
        <div className="absolute" style={{ left: "50%", top: -3, width: 1, height: 8, background: "rgba(255,255,255,.4)" }} />
        <div className="absolute rounded-full" style={{
          top: -3, width: 8, height: 8, left: `calc(${pos}% - 4px)`,
          background: "#fff", border: `2px solid ${tier.color}`,
        }} />
      </div>
    </div>
  );
}

function PortfolioInsight() {
  const { data } = useQuery({ queryKey: ["ai-portfolio-insight"], queryFn: () => aiApi.portfolioInsight().then(r => r.data.data) });
  const companies = data?.companies ?? [];
  const safeColor = (s: number) => s >= 65 ? "#10b981" : s >= 45 ? "#f59e0b" : "#f43f5e";
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-4">
        <Brain size={16} className="text-violet-400" />
        <h2 className="text-sm font-bold text-white">رؤية الذكاء لشركات محفظتك — القيمة العادلة ودرجة السلامة</h2>
      </div>
      {data?.advice && (
        <div className="bg-[#111c30] rounded-xl p-3.5 mb-4 text-sm text-slate-300 leading-relaxed flex gap-2">
          <Sparkles size={15} className="text-amber-400 shrink-0 mt-0.5" />
          <span>{data.advice}</span>
        </div>
      )}
      {companies.length === 0 ? (
        <p className="text-slate-500 text-sm py-6 text-center">أضف شركات إلى محفظتك لتظهر رؤية الذكاء عنها تلقائياً.</p>
      ) : (
        <div className="overflow-x-auto">
          <table className="w-full text-sm min-w-[640px]">
            <thead><tr className="border-b border-[#1a2540]">
              {["الشركة", "السعر", "القيمة العادلة", "الفرصة", "التقييم", "درجة السلامة", "تقييم AI", "القرار"].map(h => <th key={h} className="th text-start">{h}</th>)}
            </tr></thead>
            <tbody>
              {companies.map((c: any) => (
                <tr key={c.symbol} className="border-b border-[#1a2540]/40 hover:bg-[#111c30]">
                  <td className="td"><span className="text-white font-semibold text-[13px]">{c.name}</span> <span className="tag-b ms-1" style={{ fontSize: 10 }}>{c.symbol}</span></td>
                  <td className="td font-mono">{c.price != null ? c.price.toFixed(2) : "—"}</td>
                  <td className="td font-mono">{c.fair_value != null ? c.fair_value.toFixed(2) : "—"}</td>
                  <td className="td">{c.upside_pct != null ? <span style={{ color: c.upside_pct >= 0 ? "#10b981" : "#f43f5e" }} className="text-xs font-bold">{c.upside_pct >= 0 ? "+" : ""}{c.upside_pct}%</span> : "—"}</td>
                  <td className="td"><FairValueBar upside={c.upside_pct} /></td>
                  <td className="td">
                    <div className="flex items-center gap-1.5">
                      <div className="h-1.5 rounded-full bg-slate-800" style={{ width: 46 }}><div className="h-1.5 rounded-full" style={{ width: `${c.safety_score}%`, background: safeColor(c.safety_score) }} /></div>
                      <span className="text-xs" style={{ color: safeColor(c.safety_score) }}>{c.safety_label}</span>
                    </div>
                  </td>
                  <td className="td font-bold" style={{ color: safeColor(c.ai_score) }}>{c.ai_score}/100</td>
                  <td className="td">{c.decision?.label && <span className="px-2 py-0.5 rounded-lg text-[11px] font-bold" style={{ background: c.decision.color + "22", color: c.decision.color }}>{c.decision.label}</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
          <p className="text-[11px] text-slate-500 mt-3">القيمة العادلة = متوسط تقدير المحللين · درجة السلامة = الصحة المالية · لدعم القرار فقط، والقرار يبقى بيدك.</p>
        </div>
      )}
    </div>
  );
}

// ── AI Portfolio Analysis ─────────────────────────────────────
export default function AIPage() {
  const qc = useQueryClient();

  const { data: status } = useQuery({
    queryKey: ["ai-status"],
    queryFn: () => aiApi.status().then(r => r.data.data),
    refetchInterval: 30000,
  });
  const { data: report } = useQuery({
    queryKey: ["ai-full-report"],
    queryFn: () => aiApi.fullReport().then(r => r.data.data),
  });
  const { data: evaluation } = useQuery({
    queryKey: ["ai-evaluation"],
    queryFn: () => aiApi.evaluation().then(r => r.data.data),
  });
  const { data: opportunities } = useQuery({
    queryKey: ["ai-opportunities"],
    queryFn: () => aiApi.opportunities().then(r => r.data.data),
  });
  const { data: risk } = useQuery({
    queryKey: ["ai-risk"],
    queryFn: () => aiApi.risk().then(r => r.data.data),
  });

  const runMutation = useMutation({
    mutationFn: () => aiApi.run().then(r => r.data),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["ai-report"] });
      qc.invalidateQueries({ queryKey: ["ai-evaluation"] });
      qc.invalidateQueries({ queryKey: ["ai-status"] });
    },
  });

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">تحليل الذكاء الاصطناعي</h1>
          <p className="text-slate-400 text-sm mt-1">رؤية عن شركات محفظتك، وتحليل أي سهم بالبحث</p>
        </div>
        {status && (
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full ${status.is_running ? "bg-amber-400 animate-pulse" : "bg-emerald-400"}`} />
            <Brain size={16} className="text-purple-400" />
            <span className="text-xs text-slate-500">Gemini AI</span>
          </div>
        )}
      </div>

      {/* Portfolio insight — fair value + safety per holding */}
      <PortfolioInsight />

      {/* Portfolio evaluation — the fair analysis-based bar, plus a textual (no-numbers) decision + analysis */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <TrendingUp size={16} className="text-blue-400" />
          <h2 className="text-sm font-bold text-slate-300">تقييم المحفظة</h2>
          {evaluation?.source === "AI" && <span className="tag-v ms-auto" style={{fontSize:10}}>AI</span>}
        </div>

        <PortfolioHealthW />

        {evaluation && (
          <div className="mt-5 pt-5" style={{ borderTop: "1px solid #1a2540" }}>
            <div className="flex flex-wrap gap-2 mb-3">
              {[
                { label: "التنويع", value: evaluation.diversification_score },
                { label: "إدارة المخاطر", value: evaluation.risk_score },
                { label: "الأداء", value: evaluation.performance_score },
              ].map(m => m.value !== undefined && (
                <span key={m.label} className="px-2.5 py-1 rounded-full text-xs font-bold"
                  style={{
                    background: m.value >= 70 ? "rgba(16,185,129,.14)" : m.value >= 45 ? "rgba(245,158,11,.14)" : "rgba(244,63,94,.14)",
                    color:      m.value >= 70 ? "#10b981"              : m.value >= 45 ? "#f59e0b"              : "#f43f5e",
                  }}>
                  {m.label}: {m.value >= 70 ? "جيد" : m.value >= 45 ? "متوسط" : "ضعيف"}
                </span>
              ))}
              {evaluation.overall_score !== undefined && (
                <span className="px-2.5 py-1 rounded-full text-xs font-bold"
                  style={{
                    background: evaluation.overall_score >= 70 ? "rgba(16,185,129,.18)" : evaluation.overall_score >= 45 ? "rgba(245,158,11,.18)" : "rgba(244,63,94,.18)",
                    color:      evaluation.overall_score >= 70 ? "#10b981"              : evaluation.overall_score >= 45 ? "#f59e0b"              : "#f43f5e",
                  }}>
                  القرار: {evaluation.overall_score >= 70 ? "المحفظة في وضع جيد" : evaluation.overall_score >= 45 ? "المحفظة في وضع متوسط، تحتاج مراجعة" : "المحفظة تحتاج إعادة نظر"}
                </span>
              )}
            </div>
            {evaluation.summary && <p className="text-slate-300 text-sm bg-[#111c30] rounded-xl p-3">{evaluation.summary}</p>}
          </div>
        )}
      </div>

      {/* Company search — any symbol */}
      <CompanyAnalysis />

      {/* Opportunities */}
      {opportunities && opportunities.length > 0 && (
        <div className="card">
          <div className="flex items-center gap-2 mb-4">
            <Zap size={16} className="text-amber-400" />
            <h2 className="text-sm font-bold text-slate-300">الفرص المكتشفة</h2>
          </div>
          <div className="space-y-3">
            {opportunities.map((op: any, i: number) => (
              <div key={i} className="p-4 bg-[#111c30] rounded-xl border border-[#1a2540]">
                <div className="flex items-start justify-between gap-3 mb-2">
                  <p className="text-white font-semibold text-sm">{op.title || op.company_name}</p>
                  {op.score && <span className="tag-g shrink-0">{op.score}/100</span>}
                </div>
                {op.description && <p className="text-slate-400 text-xs">{op.description}</p>}
                {op.potential_return && <p className="text-emerald-400 text-xs mt-1">عائد متوقع: {op.potential_return}%</p>}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Risk */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <AlertTriangle size={16} className="text-red-400" />
          <h2 className="text-sm font-bold text-slate-300">تحليل المخاطر</h2>
          {risk?.source === "AI" && <span className="tag-v ms-auto" style={{fontSize:10}}>AI</span>}
        </div>
        {!risk ? (
          <p className="text-slate-500 text-sm py-4 text-center">لا توجد بيانات حالياً — يُبنى تحليل المخاطر تلقائياً عند وجود شركات في المحفظة وتفعيل مفتاح الذكاء</p>
        ) : (
        <>
          {risk.overall_risk_level && (
            <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-semibold mb-3
              ${risk.overall_risk_level === "LOW" ? "tag-g" : risk.overall_risk_level === "MEDIUM" ? "tag-a" : "tag-r"}`}>
              مستوى المخاطر: {risk.overall_risk_level === "LOW" ? "منخفض" : risk.overall_risk_level === "MEDIUM" ? "متوسط" : "عالٍ"}
            </div>
          )}
          {risk.summary && <p className="text-slate-300 text-sm bg-[#111c30] rounded-xl p-3">{risk.summary}</p>}
          {risk.risks && risk.risks.length > 0 && (
            <div className="mt-3 space-y-2">
              {risk.risks.map((r: any, i: number) => (
                <div key={i} className="flex items-start gap-2 p-3 bg-[#111c30] rounded-xl">
                  <AlertTriangle size={13} className="text-amber-400 mt-0.5 shrink-0" />
                  <p className="text-slate-300 text-xs">{r.description || r}</p>
                </div>
              ))}
            </div>
          )}
        </>
        )}
      </div>

      {/* AI Report */}
      <div className="card">
        <div className="flex items-center gap-2 mb-4">
          <Brain size={16} className="text-purple-400" />
          <h2 className="text-sm font-bold text-slate-300">التقرير الشامل</h2>
          {report?.source === "AI" && <span className="tag-v ms-auto" style={{fontSize:10}}>AI</span>}
        </div>
        {!report?.content ? (
          <p className="text-slate-500 text-sm py-4 text-center">لا توجد بيانات حالياً — يُبنى التقرير تلقائياً عند وجود شركات في المحفظة وتفعيل مفتاح الذكاء</p>
        ) : (
          <div className="bg-[#111c30] rounded-xl p-4 text-slate-300 text-sm whitespace-pre-wrap leading-relaxed max-h-80 overflow-y-auto">
            {report.content}
          </div>
        )}
      </div>
    </div>
  );
}
