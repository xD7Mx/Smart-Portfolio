import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { settingsApi, companiesApi } from "../services/api";
import { useAppStore } from "../store/appStore";
import { Settings, Brain, MessageSquare, Database, Shield, Info, Globe, Activity, RefreshCw, LayoutGrid, ArrowUp, ArrowDown, Home, MoonStar } from "lucide-react";
import { useT } from "../i18n";
import { PAGES } from "../components/common/MainLayout";

const SECTIONS = [
  { id: "general",   labelKey: "set.general",  icon: Settings },
  { id: "customize", labelKey: "set.customize", icon: LayoutGrid },
  { id: "integrations", labelKey: "set.integrations", icon: Activity },
  { id: "language",  labelKey: "set.language", icon: Globe },
  { id: "ai",        labelKey: "set.ai",       icon: Brain },
  { id: "telegram",  labelKey: "set.telegram", icon: MessageSquare },
  { id: "backup",    labelKey: "set.backup",   icon: Database },
  { id: "security",  labelKey: "set.security", icon: Shield },
  { id: "about",     labelKey: "set.about",    icon: Info },
] as const;

const SHARIA_SYNC_KEY = "sharia_last_sync";

function formatSyncTime(ts: number): string {
  const d = new Date(ts);
  const date = d.toLocaleDateString("en-GB");
  const time = d.toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit" });
  return `${date} — ${time}`;
}

function ShariaSyncCard() {
  const qc = useQueryClient();
  const [result, setResult] = useState<{ checked: number; updated: number } | null>(null);
  const [lastSync, setLastSync] = useState<number | null>(() => {
    const v = localStorage.getItem(SHARIA_SYNC_KEY);
    return v ? Number(v) : null;
  });
  const mutation = useMutation({
    mutationFn: () => companiesApi.syncSharia().then(r => r.data?.data),
    onSuccess: (data) => {
      setResult(data);
      const now = Date.now();
      localStorage.setItem(SHARIA_SYNC_KEY, String(now));
      setLastSync(now);
      ["portfolio", "companies", "portfolio-summary"].forEach(k => qc.invalidateQueries({ queryKey: [k] }));
    },
  });
  return (
    <div className="card mt-4">
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-sm font-bold text-slate-300 flex items-center gap-2">
          <MoonStar size={15} className="text-emerald-400" /> التوافق الشرعي
        </h2>
        <button className="btn-ghost" onClick={() => mutation.mutate()} disabled={mutation.isPending}>
          <RefreshCw size={14} className={mutation.isPending ? "animate-spin" : ""} /> مزامنة الآن
        </button>
      </div>
      <p className="text-sm text-slate-400">
        الذكاء الاصطناعي يبحث عن حالة التوافق الشرعي لشركات محفظتك اعتماداً على معايير الفرز الشرعي
        المعروفة والمنشورة (كمعايير المقاصد) — مرة واحدة فقط لكل شركة، ويُخزَّن على السيرفر دائماً.
        لا يُسجَّل أي رمز أخضر إلا بثقة عالية؛ إن لم يكن الذكاء متأكداً تبقى الشركة "غير محدد".
      </p>
      <div className="flex items-center gap-2 mt-3 text-xs">
        <span className="tag-n">آخر مزامنة</span>
        <span className="text-slate-400">{lastSync ? formatSyncTime(lastSync) : "لم تتم أي مزامنة بعد"}</span>
      </div>
      {result && (
        <p className="text-xs text-slate-500 mt-2">
          تم فحص {result.checked} شركة، وتحديث {result.updated} منها.
          {result.checked > 0 && result.updated === 0 && " (لم يكن الذكاء متأكداً بما يكفي لهذه الشركات — ستُحاول المزامنة القادمة مجدداً)"}
        </p>
      )}
    </div>
  );
}

export default function SettingsPage() {
  const t = useT();
  const qc = useQueryClient();
  const [active, setActive] = useState("general");
  const { language, setLanguage, tickers, setTicker, theme, setTheme,
          customColors, setCustomColors,
          pageOrder, hiddenPages, startPage, movePage, togglePage, setStartPage } = useAppStore();
  const { data: integrations = [], isFetching: intFetching } = useQuery({
    queryKey: ["settings/integrations"],
    queryFn: () => settingsApi.integrations().then(r => Array.isArray(r.data.data) ? r.data.data : []),
    refetchInterval: 120000,
  });
  const { data: settings } = useQuery({ queryKey: ["settings"],  queryFn: () => settingsApi.get().then(r => r.data.data) });
  const { data: aiCfg }    = useQuery({ queryKey: ["settings/ai"], queryFn: () => settingsApi.ai().then(r => r.data.data) });
  const { data: tgCfg }    = useQuery({ queryKey: ["settings/telegram"], queryFn: () => settingsApi.telegram().then(r => r.data.data) });

  return (
    <div className="flex gap-6 fade-in">
      {/* Sidebar */}
      <aside className="w-48 shrink-0">
        <nav className="space-y-1">
          {SECTIONS.map(({ id, labelKey, icon: Icon }) => (
            <button key={id} onClick={() => setActive(id)} className={"nav-link" + (active === id ? " nav-active" : "")}>
              <Icon size={16} />{t(labelKey)}
            </button>
          ))}
        </nav>
      </aside>

      {/* Content */}
      <div className="flex-1 space-y-6">
        {active === "general" && (
          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">{t("set.generalTitle")}</h2>
            <div className="grid grid-cols-2 gap-4 text-sm">
              {[[t("set.appName"), settings?.app], [t("set.version"), settings?.version], [t("set.currency"), settings?.currency], [t("set.portfolioMode"), settings?.portfolio_mode]].map(([k, v]) => (
                <div key={k as string}><p className="text-xs text-slate-500 mb-1">{k}</p><p className="font-medium text-white">{(v as string) ?? "—"}</p></div>
              ))}
            </div>
          </div>
        )}

        {active === "customize" && (
          <>
          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-2">ترتيب الصفحات وظهورها</h2>
            <p className="text-sm text-slate-400 mb-4">رتّب صفحات القائمة الجانبية بالأسهم، أخفِ ما لا تحتاجه، واختر صفحة البداية 🏠 عند فتح الموقع.</p>
            <div className="space-y-1.5">
              {pageOrder.map((id, i) => {
                const page = PAGES[id];
                if (!page) return null;
                const Icon = page.icon;
                const hidden = hiddenPages.includes(id);
                return (
                  <div key={id} className="flex items-center gap-3 p-2.5 rounded-xl bg-[#111c30]">
                    <Icon size={15} className={hidden ? "text-slate-600" : "text-slate-400"} />
                    <span className={"text-sm font-semibold flex-1 " + (hidden ? "text-slate-600 line-through" : "text-white")}>{t(page.key)}</span>
                    <button className={"p-1.5 rounded-lg transition-colors " + (startPage === id ? "text-amber-400" : "text-slate-600 hover:text-amber-400")}
                      title="اجعلها صفحة البداية" disabled={hidden}
                      onClick={() => setStartPage(id)}>
                      <Home size={14} />
                    </button>
                    {id !== "settings" && (
                      <button className={"switch" + (!hidden ? " on" : "")} onClick={() => togglePage(id)} title={hidden ? "إظهار" : "إخفاء"} />
                    )}
                    <div className="flex flex-col">
                      <button className="text-slate-600 hover:text-white disabled:opacity-20" disabled={i === 0} onClick={() => movePage(id, -1)}><ArrowUp size={13} /></button>
                      <button className="text-slate-600 hover:text-white disabled:opacity-20" disabled={i === pageOrder.length - 1} onClick={() => movePage(id, 1)}><ArrowDown size={13} /></button>
                    </div>
                  </div>
                );
              })}
            </div>
            <p className="text-[11px] text-slate-600 mt-3">🏠 صفحة البداية الحالية: {t(PAGES[startPage]?.key ?? "nav.dashboard")}</p>
          </div>

          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">المظهر (Theme)</h2>
            <p className="text-sm text-slate-400 mb-4">اختر المظهر — يُحفظ اختيارك تلقائياً.</p>
            <div className="flex gap-3 flex-wrap">
              <button onClick={() => setTheme("dark")} className={theme === "dark" ? "btn-primary" : "btn-ghost"}>🌙 داكن</button>
              <button onClick={() => setTheme("light")} className={theme === "light" ? "btn-primary" : "btn-ghost"}>☀️ فاتح</button>
              <button onClick={() => setTheme("custom")} className={theme === "custom" ? "btn-primary" : "btn-ghost"}>🎨 مخصص</button>
            </div>
            {theme === "custom" && (
              <div className="mt-4 grid grid-cols-2 gap-4 max-w-sm">
                <div>
                  <label className="label">لون الخلفية</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={customColors.bg} onChange={e => setCustomColors({ bg: e.target.value })}
                      className="w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent" />
                    <span className="text-xs text-slate-400 font-mono" dir="ltr">{customColors.bg}</span>
                  </div>
                </div>
                <div>
                  <label className="label">لون النص</label>
                  <div className="flex items-center gap-2">
                    <input type="color" value={customColors.text} onChange={e => setCustomColors({ text: e.target.value })}
                      className="w-10 h-10 rounded-lg cursor-pointer border-0 bg-transparent" />
                    <span className="text-xs text-slate-400 font-mono" dir="ltr">{customColors.text}</span>
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">{t("set.marketTickers")}</h2>
            <p className="text-sm text-slate-400 mb-4">{t("set.marketTickersDesc")}</p>
            <div className="space-y-1">
              {([["tasi", t("market.tasi")], ["brent", t("market.brent")], ["gold", t("market.gold")]] as const).map(([k, label]) => (
                <div key={k} className="stat-row">
                  <span className="stat-lbl">{label}</span>
                  <button className={"switch" + (tickers[k] ? " on" : "")} onClick={() => setTicker(k, !tickers[k])} aria-label={label} />
                </div>
              ))}
            </div>
          </div>
          </>
        )}

        {active === "integrations" && (
          <div className="card">
            <div className="flex items-center justify-between mb-2">
              <h2 className="text-sm font-bold text-slate-300">{t("set.integrationsTitle")}</h2>
              <button className="btn-ghost" onClick={async () => {
                const r = await settingsApi.integrations(true);
                qc.setQueryData(["settings/integrations"], Array.isArray(r.data.data) ? r.data.data : []);
              }} disabled={intFetching}>
                <RefreshCw size={14} className={intFetching ? "animate-spin" : ""} /> {t("set.refresh")}
              </button>
            </div>
            <p className="text-sm text-slate-400 mb-5">{t("set.integrationsDesc")}</p>
            <div className="space-y-2">
              {integrations.length === 0 && (
                <div className="text-slate-500 text-sm py-4 text-center">{t("set.checking")}</div>
              )}
              {integrations.map((it: any) => {
                const map: any = {
                  up:             { color: "#10b981", bg: "rgba(16,185,129,.12)", label: t("set.statusUp") },
                  down:           { color: "#f43f5e", bg: "rgba(244,63,94,.12)",  label: t("set.statusDown") },
                  not_configured: { color: "#64748b", bg: "rgba(100,116,139,.12)", label: t("set.statusNotConfigured") },
                  disabled:       { color: "#64748b", bg: "rgba(100,116,139,.12)", label: t("set.statusDisabled") },
                };
                const s = map[it.status] || map.down;
                const isUp = it.status === "up";
                const limit = Number(it.daily_limit || 0);
                const used = Number(it.daily_used || 0);
                const pct = limit > 0 ? Math.min(100, Math.round((used / limit) * 100)) : 0;
                return (
                  <div key={it.id} className="p-3 rounded-xl bg-[#111c30]">
                    <div className="flex items-center gap-3">
                      <span className="relative flex h-3 w-3 shrink-0">
                        {isUp && <span className="animate-ping absolute inline-flex h-full w-full rounded-full opacity-60" style={{background: s.color}} />}
                        <span className="relative inline-flex rounded-full h-3 w-3" style={{background: s.color}} />
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-white text-sm font-semibold">{language === "ar" ? it.name_ar : it.name}</p>
                        {!isUp && it.detail && <p className="text-xs text-slate-500 truncate">{it.detail}</p>}
                      </div>
                      <span className="text-xs font-bold px-2.5 py-1 rounded-full" style={{color: s.color, background: s.bg}}>{s.label}</span>
                    </div>

                    {/* Usage shown ONLY when green — keeps the UI clean otherwise */}
                    {isUp && limit > 0 && (
                      <div className="mt-3 ps-6">
                        <div className="flex items-center justify-between text-xs mb-1.5">
                          <span className="text-slate-400">{t("set.dailyUsage")}</span>
                          <span className="text-slate-300 font-medium">{used.toLocaleString()} / {limit.toLocaleString()}</span>
                        </div>
                        <div className="h-2 bg-[#1a2540] rounded-full overflow-hidden">
                          <div className="h-full rounded-full transition-all"
                            style={{width: pct + "%", background: pct >= 90 ? "#f43f5e" : pct >= 70 ? "#f59e0b" : "linear-gradient(90deg,#3b82f6,#10b981)"}} />
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {active === "integrations" && <ShariaSyncCard />}

        {active === "language" && (
          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">{t("set.langTitle")}</h2>
            <p className="text-sm text-slate-400 mb-4">{t("set.langDesc")}</p>
            <div className="flex gap-3">
              <button onClick={() => setLanguage("ar")} className={language === "ar" ? "btn-primary" : "btn-ghost"}>{t("set.arabic")}</button>
              <button onClick={() => setLanguage("en")} className={language === "en" ? "btn-primary" : "btn-ghost"}>{t("set.english")}</button>
            </div>
          </div>
        )}

        {active === "ai" && (
          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">{t("set.aiTitle")}</h2>
            <div className="space-y-3 text-sm">
              {[[t("set.provider"), aiCfg?.provider], [t("set.model"), aiCfg?.model], [t("set.temperature"), aiCfg?.temperature], [t("set.maxTokens"), aiCfg?.max_tokens]].map(([k, v]) => (
                <div key={k as string} className="flex justify-between py-2 border-b border-[#1a2540]">
                  <span className="text-slate-400">{k}</span><span className="font-medium text-white">{(v as string) ?? "—"}</span>
                </div>
              ))}
              <div className="flex justify-between py-2">
                <span className="text-slate-400">{t("set.apiKey")}</span>
                <span className={aiCfg?.key_configured ? "tag-g" : "tag-r"}>{aiCfg?.key_configured ? t("set.configured") : t("set.notConfigured")}</span>
              </div>
            </div>
          </div>
        )}

        {active === "telegram" && (
          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">{t("set.telegramTitle")}</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between py-2 border-b border-[#1a2540]">
                <span className="text-slate-400">{t("set.statusLabel")}</span>
                <span className={tgCfg?.enabled ? "tag-g" : "tag-n"}>{tgCfg?.enabled ? t("set.enabled") : t("set.disabled")}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-[#1a2540]"><span className="text-slate-400">{t("set.botUsername")}</span><span className="text-white">{tgCfg?.username ?? "—"}</span></div>
              <button className="btn-ghost">{t("set.testConn")}</button>
            </div>
          </div>
        )}

        {active === "backup" && (
          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">{t("set.backupTitle")}</h2>
            <p className="text-sm text-slate-400 mb-4">{t("set.backupDesc")}</p>
            <div className="flex gap-3">
              <button className="btn-primary">{t("set.createBackup")}</button>
              <button className="btn-ghost">{t("set.restoreBackup")}</button>
            </div>
          </div>
        )}

        {active === "security" && (
          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">{t("set.securityTitle")}</h2>
            <p className="text-sm text-slate-400">{t("set.securityDesc")}</p>
          </div>
        )}

        {active === "about" && (
          <div className="card">
            <h2 className="text-sm font-bold text-slate-300 mb-4">{t("set.aboutTitle")}</h2>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between"><span className="text-slate-400">{t("set.appName")}</span><span className="text-white">Smart Portfolio</span></div>
              <div className="flex justify-between"><span className="text-slate-400">{t("set.version")}</span><span className="text-white">1.0.0</span></div>
              <div className="flex justify-between"><span className="text-slate-400">{t("set.philosophy")}</span><span className="text-blue-400">{t("set.motto")}</span></div>
              <p className="text-xs text-slate-500 pt-2 border-t border-[#1a2540]">
                {t("set.aboutText")}
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
