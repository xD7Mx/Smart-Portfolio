import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { reportsApi } from "../services/api";
import { FileText, FilePlus, Eye, X, Printer, Trash2, Download } from "lucide-react";
import { useT } from "../i18n";

const money = (n: number) => (n ?? 0).toLocaleString("en-US", { maximumFractionDigits: 0 });

const TYPES = [
  { key: "DAILY",   label: "يومي" },
  { key: "WEEKLY",  label: "أسبوعي" },
  { key: "MONTHLY", label: "شهري" },
  { key: "ANNUAL",  label: "سنوي" },
];

function ReportModal({ id, autoPrint = false, onClose }: { id: number; autoPrint?: boolean; onClose: () => void }) {
  const { data } = useQuery({ queryKey: ["report", id], queryFn: () => reportsApi.get(id).then(r => r.data.data) });
  const m = data?.metrics || {};
  React.useEffect(() => {
    if (autoPrint && data) { const t = setTimeout(() => window.print(), 400); return () => clearTimeout(t); }
  }, [autoPrint, data]);
  return (
    <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      style={{ padding: "16px", alignItems: "flex-start", overflowY: "auto" }}>
      <div className="modal-box fade-in report-print" style={{ maxWidth: 760, width: "100%", maxHeight: "92vh", overflowY: "auto", margin: "16px auto" }}>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <FileText size={18} className="text-blue-400" />
            <h2 className="text-lg font-bold text-white">تقرير {data?.period || ""}</h2>
          </div>
          <div className="flex items-center gap-1">
            <button className="btn-ghost text-xs" onClick={() => window.print()}><Printer size={13} /> طباعة/PDF</button>
            <button onClick={onClose} className="text-slate-500 hover:text-white p-1"><X size={18} /></button>
          </div>
        </div>
        {!data ? <div className="py-10 text-center text-slate-500 text-sm">جارٍ التحميل...</div> : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              <div className="kpi"><div className="kpi-lbl">القيمة السوقية</div><div className="kpi-val">{money(m.market_value)}</div></div>
              <div className="kpi"><div className="kpi-lbl">إجمالي المدفوع</div><div className="kpi-val">{money(m.total_invested)}</div></div>
              <div className="kpi"><div className="kpi-lbl">الأرباح غير المحققة</div><div className="kpi-val" style={{ color: (m.unrealized_pnl ?? 0) >= 0 ? "#10b981" : "#f43f5e" }}>{(m.unrealized_pnl ?? 0) >= 0 ? "+" : ""}{money(m.unrealized_pnl)}</div></div>
              <div className="kpi"><div className="kpi-lbl">العائد %</div><div className="kpi-val" style={{ color: (m.roi_pct ?? 0) >= 0 ? "#10b981" : "#f43f5e" }}>{(m.roi_pct ?? 0) >= 0 ? "+" : ""}{(m.roi_pct ?? 0).toFixed(2)}%</div></div>
              <div className="kpi"><div className="kpi-lbl">التوزيعات</div><div className="kpi-val">+{money(m.dividends)}</div></div>
              <div className="kpi"><div className="kpi-lbl">عدد الشركات</div><div className="kpi-val">{m.positions_count ?? 0}</div></div>
            </div>

            {data.positions?.length > 0 && (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead><tr className="border-b border-[#1a2540]">{["الشركة", "الأسهم", "القيمة", "الربح/الخسارة"].map(h => <th key={h} className="th text-start">{h}</th>)}</tr></thead>
                  <tbody>
                    {data.positions.map((p: any) => (
                      <tr key={p.symbol} className="border-b border-[#1a2540]/40">
                        <td className="td"><span className="text-white font-semibold text-[13px]">{p.name}</span> <span className="tag-b ms-1" style={{ fontSize: 10 }}>{p.symbol}</span></td>
                        <td className="td font-mono">{money(p.shares)}</td>
                        <td className="td font-mono">{money(p.market_value)}</td>
                        <td className="td font-mono" style={{ color: p.pnl >= 0 ? "#10b981" : "#f43f5e" }}>{p.pnl >= 0 ? "+" : ""}{money(p.pnl)} ({(p.pnl_pct ?? 0).toFixed(1)}%)</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            <div>
              <p className="text-[13px] font-bold text-white mb-2">التحليل</p>
              {data.content ? (
                <div className="bg-[#111c30] rounded-xl p-4 text-slate-300 text-sm whitespace-pre-wrap leading-relaxed">{data.content}</div>
              ) : (
                <p className="text-slate-500 text-xs">النص التحليلي يُولَّد بالذكاء عند تفعيل مفتاح Gemini على الخادم — أرقام التقرير أعلاه حقيقية بكل الأحوال.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function ReportsPage() {
  const t = useT();
  const qc = useQueryClient();
  const [viewId, setViewId] = useState<number | null>(null);
  const [printId, setPrintId] = useState<number | null>(null);
  const { data: reports = [] } = useQuery({
    queryKey: ["reports"],
    queryFn: () => reportsApi.list().then(r => (Array.isArray(r.data.data) ? r.data.data : [])),
  });
  const genMutation = useMutation({
    mutationFn: (type: string) => reportsApi.generate(type).then(r => r.data),
    onSuccess: (r: any) => {
      qc.invalidateQueries({ queryKey: ["reports"] });
      if (r?.data?.id) setViewId(r.data.id);
    },
  });
  const delMutation = useMutation({
    mutationFn: (id: number) => reportsApi.remove(id).then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["reports"] }),
  });

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white">{t("reports.title")}</h1>
          <p className="text-slate-400 text-sm mt-1">أنشئ تقريراً فورياً عن محفظتك — يُحفظ في الأرشيف ويمكن طباعته PDF.</p>
        </div>
      </div>

      {/* Generate card — the button the report is created from */}
      <div className="card">
        <div className="flex items-center gap-2 mb-3">
          <FilePlus size={16} className="text-emerald-400" />
          <h2 className="text-sm font-bold text-white">إنشاء تقرير جديد</h2>
        </div>
        <p className="text-sm text-slate-400 mb-4">اختر نوع الفترة ثم اضغط لإنشاء التقرير — يحسب أرقام محفظتك الحالية ويضيف تحليلاً نصياً.</p>
        <div className="flex flex-wrap gap-2">
          {TYPES.map(item => (
            <button key={item.key} className="btn-primary" disabled={genMutation.isPending}
              onClick={() => genMutation.mutate(item.key)}>
              <FilePlus size={15} /> تقرير {item.label}
            </button>
          ))}
          {genMutation.isPending && <span className="text-xs text-slate-400 self-center">جارٍ إنشاء التقرير...</span>}
        </div>
      </div>

      <div className="card overflow-x-auto p-0">
        <div className="flex items-center gap-2 p-4 border-b border-[#1a2540]">
          <FileText size={16} className="text-blue-400" />
          <h2 className="text-sm font-bold text-slate-300">أرشيف التقارير</h2>
        </div>
        {reports.length === 0 ? (
          <div className="text-center py-12 text-slate-500">
            <FileText size={32} className="mx-auto mb-2 opacity-50" />
            <p className="text-sm">لا توجد تقارير بعد — أنشئ أول تقرير من الأعلى.</p>
          </div>
        ) : (
          <table className="w-full">
            <thead>
              <tr className="border-b border-[#1a2540]">
                <th className="th text-start">النوع</th>
                <th className="th text-start">الفترة</th>
                <th className="th text-start">تاريخ الإنشاء</th>
                <th className="th text-start">الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {reports.map((r: any) => (
                <tr key={r.id} className="hover:bg-[#111c30] transition-colors">
                  <td className="td"><span className="tag-b">{r.type}</span></td>
                  <td className="td text-slate-400">{r.period ?? "—"}</td>
                  <td className="td text-slate-400">{r.generated_at ? new Date(r.generated_at).toLocaleDateString("en-GB") : "—"}</td>
                  <td className="td">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setViewId(r.id)} title="عرض" className="p-1.5 rounded-lg text-slate-500 hover:text-blue-400 hover:bg-blue-500/10 transition-all">
                        <Eye size={15} />
                      </button>
                      <button onClick={() => setPrintId(r.id)} title="تحميل PDF" className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-400 hover:bg-emerald-500/10 transition-all">
                        <Download size={15} />
                      </button>
                      <button onClick={() => delMutation.mutate(r.id)} title="حذف" disabled={delMutation.isPending} className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {viewId != null && <ReportModal id={viewId} onClose={() => setViewId(null)} />}
      {printId != null && <ReportModal id={printId} autoPrint onClose={() => setPrintId(null)} />}
    </div>
  );
}
