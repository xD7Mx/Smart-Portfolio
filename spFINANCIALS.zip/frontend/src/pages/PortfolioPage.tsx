import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Plus, Search, Pencil, Trash2, TrendingUp, TrendingDown, ShoppingCart, X, SlidersHorizontal, Wallet, Scale, Columns3 } from "lucide-react";
import { companiesApi, holdingsApi, transactionsApi, cashApi, allocationApi, portfolioApi } from "../services/api";
import { useT } from "../i18n";
import { searchCompanies, lookupCompany, SaudiCompany } from "../data/saudiCompanies";
import { useAppStore } from "../store/appStore";
import CompanyLogo from "../components/common/CompanyLogo";
import { ShariaBadge } from "../components/common/UI";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";

const fmt = (n: number) => n?.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 }) ?? "—";

const COMPO_COLORS = ["#3b82f6", "#8b5cf6", "#10b981", "#06b6d4", "#f59e0b", "#f43f5e", "#6366f1", "#14b8a6", "#ec4899", "#eab308"];

// ── Portfolio composition — colorful proportional strip of holdings by weight ──
function CompositionCard({ holdings }: { holdings: any[] }) {
  const total = holdings.reduce((a, h) => a + (h.current_value || 0), 0);
  const items = holdings
    .map((h: any) => ({
      name: lookupCompany(h.company?.symbol)?.name_ar || h.company?.name_ar || h.company?.name || h.company?.symbol,
      symbol: h.company?.symbol,
      value: h.current_value || 0,
      pct: total ? (h.current_value || 0) / total * 100 : 0,
    }))
    .sort((a, b) => b.value - a.value)
    .map((it, i) => ({ ...it, color: COMPO_COLORS[i % COMPO_COLORS.length] }));

  return (
    <div className="card">
      <p className="text-[13px] font-bold text-white mb-4">تكوين المحفظة</p>
      {/* Colorful proportional bar */}
      <div className="flex w-full rounded-full overflow-hidden" style={{ height: 34 }}>
        {items.map((it) => (
          <div key={it.symbol} title={`${it.name} — ${it.pct.toFixed(1)}%`}
            style={{ width: `${it.pct}%`, background: `linear-gradient(180deg, ${it.color}, ${it.color}cc)` }}
            className="h-full transition-all hover:brightness-110" />
        ))}
      </div>
      {/* Legend grid */}
      <div className="grid grid-cols-2 gap-x-5 gap-y-2 mt-4">
        {items.map((it) => (
          <div key={it.symbol} className="flex items-center gap-2 text-[12.5px] min-w-0">
            <span className="rounded-full shrink-0" style={{ width: 9, height: 9, background: it.color }} />
            <span className="text-slate-300 truncate flex-1">{it.name}</span>
            <span className="font-bold text-white shrink-0">{it.pct.toFixed(1)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Portfolio charts: composition + top companies by profit ────
function PortfolioCharts({ holdings }: { holdings: any[] }) {
  const withValue = holdings.filter((h: any) => (h.current_value || 0) > 0);
  if (withValue.length === 0) return null;
  // Ranked by total profit realised within the portfolio (capital gains + dividends),
  // not by raw position size — a company can be small yet the most profitable.
  const profitData = withValue
    .map((h: any) => {
      const capitalGain = (h.current_value || 0) - (h.total_cost || 0);
      const dividends = h.total_dividends_received || 0;
      return {
        name: lookupCompany(h.company?.symbol)?.name_ar || h.company?.name_ar || h.company?.name || h.company?.symbol,
        profit: capitalGain + dividends,
        capitalGain,
        dividends,
      };
    })
    .sort((a, b) => b.profit - a.profit)
    .slice(0, 8);
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
      <CompositionCard holdings={withValue} />
      <div className="card">
        <p className="text-[13px] font-bold text-white mb-2">أعلى الشركات ربحاً (رأسمالي + توزيعات)</p>
        <div style={{ height: 190 }} dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={profitData} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.12)" />
              <XAxis dataKey="name" tick={{ fontSize: 10, fill: "#94a3b8" }} interval={0} angle={-12} height={40} />
              <YAxis tick={{ fontSize: 10, fill: "#64748b" }} width={44} tickFormatter={(v: number) => fmt(v)} />
              <Tooltip contentStyle={{ background: "var(--pop)", border: "1px solid var(--line)", color: "var(--tip-text)", borderRadius: 10, fontSize: 12 }}
                formatter={(v: any, n: any, p: any) => [
                  `${fmt(v)} (رأسمالي ${fmt(p.payload.capitalGain)} + توزيعات ${fmt(p.payload.dividends)})`,
                  "إجمالي الربح",
                ]} />
              <Bar dataKey="profit" radius={[6, 6, 0, 0]}>
                {profitData.map((d, i) => <Cell key={i} fill={d.profit >= 0 ? "#10b981" : "#f43f5e"} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

// ── Modal components ─────────────────────────────────────────
function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return (
    <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-box fade-in">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-lg font-bold text-white">{title}</h2>
          <button onClick={onClose} className="text-slate-500 hover:text-white p-1"><X size={18} /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div><label className="label">{label}</label>{children}</div>;
}

// ── Add/Edit Company Modal ────────────────────────────────────
function CompanyModal({ company, onClose }: { company?: any; onClose: () => void }) {
  const t = useT();
  const qc = useQueryClient();
  const [form, setForm] = useState({
    symbol:   company?.symbol   ?? "",
    name:     company?.name     ?? "",
    name_ar:  company?.name_ar  ?? "",
    sector:   company?.sector   ?? "",
    market:   company?.market   ?? "تداول",
    currency: company?.currency ?? "SAR",
  });
  const [suggestions, setSuggestions] = useState<SaudiCompany[]>([]);
  const set = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm(f => ({ ...f, [k]: e.target.value }));

  // Live Saudi market directory from Sahmak (real symbols + Arabic/English
  // names); merged with the built-in list, so search works even before a key.
  const { data: directory = [] } = useQuery({
    queryKey: ["market-directory"],
    queryFn: () => companiesApi.directory().then(r => Array.isArray(r.data?.data) ? r.data.data : []),
    staleTime: 24 * 60 * 60 * 1000,
    retry: 0,
  });

  // Autocomplete: search by symbol / Arabic name / English name, then autofill everything
  const onSymbolInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const v = e.target.value;
    setForm(f => ({ ...f, symbol: v }));
    const q = v.trim().toLowerCase();
    const local = searchCompanies(v);
    const seen = new Set(local.map(c => c.symbol));
    const remote: SaudiCompany[] = q
      ? directory
          .filter((c: any) => {
            const sym = String(c.symbol || "");
            return !seen.has(sym) && (sym.startsWith(q) || (c.name || "").includes(v) || (c.name_en || "").toLowerCase().includes(q));
          })
          .slice(0, 8)
          .map((c: any) => ({ symbol: String(c.symbol), name_ar: c.name || c.name_en, name_en: c.name_en || c.name, sector: "" }))
      : [];
    setSuggestions([...local, ...remote].slice(0, 10));
  };
  const pick = (c: SaudiCompany) => {
    setForm(f => ({ ...f, symbol: c.symbol, name: c.name_en, name_ar: c.name_ar, sector: c.sector }));
    setSuggestions([]);
  };

  const mutation = useMutation({
    mutationFn: () => company
      ? companiesApi.update(company.id, form).then(r => r.data)
      : companiesApi.add(form).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["companies"] }); qc.invalidateQueries({ queryKey: ["portfolio"] }); onClose(); },
  });

  return (
    <Modal title={company ? t("port.editCompany") : t("port.newCompany")} onClose={onClose}>
      <div className="space-y-3">
        <Field label="ابحث بالرمز أو الاسم (عربي/إنجليزي)">
          <div className="relative">
            <input className="input" value={form.symbol} onChange={onSymbolInput}
              placeholder="2222 · أرامكو · Aramco" autoFocus />
            {suggestions.length > 0 && (
              <div className="absolute z-20 top-full mt-1 w-full rounded-xl overflow-hidden shadow-2xl"
                style={{background: "var(--pop)", border: "1px solid var(--line)", maxHeight: 220, overflowY: "auto"}}>
                {suggestions.map(c => (
                  <button key={c.symbol} type="button"
                    className="w-full text-start px-3 py-2.5 hover:bg-[#111c30] flex items-center gap-3 transition-colors"
                    onClick={() => pick(c)}>
                    <CompanyLogo symbol={c.symbol} size={26} />
                    <span className="tag-b shrink-0">{c.symbol}</span>
                    <span className="text-white text-sm font-semibold">{c.name_ar}</span>
                    <span className="text-slate-500 text-xs ms-auto">{c.name_en} · {c.sector}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("common.sector")}><input className="input" value={form.sector} onChange={set("sector")} placeholder="—" /></Field>
          <div />
        </div>
        <Field label={t("port.nameEn")}><input className="input" value={form.name} onChange={set("name")} placeholder="Aramco" /></Field>
        <Field label={t("port.nameAr")}><input className="input" value={form.name_ar} onChange={set("name_ar")} placeholder="أرامكو السعودية" /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label={t("port.marketField")}>
            <select className="input" value={form.market} onChange={set("market")}>
              <option>تداول</option><option>نوماد</option><option>السوق الموازية</option>
            </select>
          </Field>
          <Field label={t("port.currency")}>
            <select className="input" value={form.currency} onChange={set("currency")}>
              <option>SAR</option><option>USD</option>
            </select>
          </Field>
        </div>
        <div className="flex gap-3 pt-2">
          <button className="btn-primary flex-1" onClick={() => mutation.mutate()} disabled={mutation.isPending}>
            {mutation.isPending ? t("common.saving") : t("common.save")}
          </button>
          <button className="btn-ghost" onClick={onClose}>{t("common.cancel")}</button>
        </div>
        {mutation.isError && <p className="text-red-400 text-xs">{t("common.error")}</p>}
      </div>
    </Modal>
  );
}

// ── Transaction Modal — full investment-reference engine ─────
const TX_TYPES = [
  { id: "BUY",          label: "شراء",              color: "#10b981" },
  { id: "SELL",         label: "بيع",               color: "#f43f5e" },
  { id: "DIVIDEND",     label: "توزيع نقدي",        color: "#f59e0b" },
  { id: "REINVESTMENT", label: "إعادة استثمار",     color: "#06b6d4" },
  { id: "BONUS",        label: "منحة أسهم",         color: "#8b5cf6" },
  { id: "SPLIT",        label: "تجزئة",             color: "#6366f1" },
];

function TransactionModal({ company, onClose }: { company: any; onClose: () => void }) {
  const tr = useT();
  const qc = useQueryClient();
  const [type, setType] = useState("BUY");
  const [f, setF] = useState({ shares: "", price: "", amount: "", factor: "2", date: new Date().toISOString().split("T")[0] });
  const upd = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setF(s => ({ ...s, [k]: e.target.value }));

  const mutation = useMutation({
    mutationFn: () => {
      const payload: any = { company_id: company.id, transaction_type: type, transaction_date: f.date };
      if (type === "BUY" || type === "SELL") { payload.shares = Number(f.shares); payload.price_per_share = Number(f.price); }
      if (type === "DIVIDEND") { payload.amount = Number(f.amount); }
      if (type === "REINVESTMENT") { payload.amount = Number(f.amount); payload.price_per_share = Number(f.price); }
      if (type === "BONUS") { payload.shares = Number(f.shares); }
      if (type === "SPLIT") { payload.factor = Number(f.factor); }
      return transactionsApi.add(payload).then(r => r.data);
    },
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["portfolio"] });
      qc.invalidateQueries({ queryKey: ["portfolio-summary"] });
      qc.invalidateQueries({ queryKey: ["transactions"] });
      qc.invalidateQueries({ queryKey: ["cash"] });
      onClose();
    },
  });

  const valid =
    (type === "BUY" || type === "SELL") ? Number(f.shares) > 0 && Number(f.price) > 0 :
    type === "DIVIDEND" ? Number(f.amount) > 0 :
    type === "REINVESTMENT" ? Number(f.amount) > 0 && Number(f.price) > 0 :
    type === "BONUS" ? Number(f.shares) > 0 :
    Number(f.factor) > 0;

  const hint: Record<string, string> = {
    BUY: "يُخصم الإجمالي من السيولة المتاحة تلقائياً",
    SELL: "يُضاف صافي البيع إلى السيولة المتاحة تلقائياً",
    DIVIDEND: "يُضاف المبلغ إلى السيولة وإلى إجمالي التوزيعات",
    REINVESTMENT: "يشتري أسهماً بمبلغ التوزيع — تُسجَّل كأسهم إعادة استثمار",
    BONUS: "تُضاف الأسهم مجاناً وينخفض متوسط التكلفة تلقائياً",
    SPLIT: "مثال: معامل 2 يعني كل سهم يصبح سهمين والسعر ينخفض للنصف",
  };

  return (
    <Modal title={`معاملة — ${company.name_ar || company.name}`} onClose={onClose}>
      <div className="space-y-3">
        <Field label={tr("port.txType")}>
          <div className="grid grid-cols-3 gap-2">
            {TX_TYPES.map(t => (
              <button key={t.id} onClick={() => setType(t.id)}
                className="py-2 rounded-xl text-xs font-bold transition-all border"
                style={type === t.id
                  ? { background: t.color + "22", color: t.color, borderColor: t.color + "66" }
                  : { borderColor: "var(--line)", color: "#64748b" }}>
                {t.label}
              </button>
            ))}
          </div>
        </Field>

        {(type === "BUY" || type === "SELL") && (
          <div className="grid grid-cols-2 gap-3">
            <Field label="عدد الأسهم"><input className="input" type="number" value={f.shares} onChange={upd("shares")} placeholder="0" /></Field>
            <Field label="سعر السهم"><input className="input" type="number" step="0.01" value={f.price} onChange={upd("price")} placeholder="0.00" /></Field>
          </div>
        )}
        {type === "DIVIDEND" && (
          <Field label="مبلغ التوزيع الإجمالي"><input className="input" type="number" step="0.01" value={f.amount} onChange={upd("amount")} placeholder="0.00" /></Field>
        )}
        {type === "REINVESTMENT" && (
          <div className="grid grid-cols-2 gap-3">
            <Field label="مبلغ التوزيع"><input className="input" type="number" step="0.01" value={f.amount} onChange={upd("amount")} placeholder="0.00" /></Field>
            <Field label="سعر الشراء"><input className="input" type="number" step="0.01" value={f.price} onChange={upd("price")} placeholder="0.00" /></Field>
          </div>
        )}
        {type === "BONUS" && (
          <Field label="عدد أسهم المنحة"><input className="input" type="number" value={f.shares} onChange={upd("shares")} placeholder="0" /></Field>
        )}
        {type === "SPLIT" && (
          <Field label="معامل التجزئة"><input className="input" type="number" step="0.1" value={f.factor} onChange={upd("factor")} placeholder="2" /></Field>
        )}

        <Field label={tr("port.txDate")}><input className="input" type="date" value={f.date} onChange={upd("date")} /></Field>

        <div className="bg-[#111c30] rounded-xl p-3 text-xs text-slate-400">{hint[type]}</div>

        {(type === "BUY" || type === "SELL") && Number(f.shares) > 0 && Number(f.price) > 0 && (
          <div className="bg-[#111c30] rounded-xl p-3 text-sm">
            <span className="text-slate-400">{tr("port.txTotal")}</span>
            <span className="text-white font-bold">{fmt(Number(f.shares) * Number(f.price))}</span>
          </div>
        )}
        {type === "REINVESTMENT" && Number(f.amount) > 0 && Number(f.price) > 0 && (
          <div className="bg-[#111c30] rounded-xl p-3 text-sm">
            <span className="text-slate-400">أسهم جديدة: </span>
            <span className="text-white font-bold">{(Number(f.amount) / Number(f.price)).toFixed(4)}</span>
          </div>
        )}

        <div className="flex gap-3 pt-1">
          <button className="btn-primary flex-1" onClick={() => mutation.mutate()} disabled={mutation.isPending || !valid}>
            {mutation.isPending ? tr("port.processing") : tr("port.confirmTx")}
          </button>
          <button className="btn-ghost" onClick={onClose}>{tr("common.cancel")}</button>
        </div>
        {mutation.isError && <p className="text-red-400 text-xs">{(mutation.error as any)?.response?.data?.detail || tr("common.error")}</p>}
      </div>
    </Modal>
  );
}

// ── Cash Deposit / Withdraw (الضخ الشهري) ────────────────────
function CashModal({ onClose }: { onClose: () => void }) {
  const qc = useQueryClient();
  const [mode, setMode] = useState<"deposit" | "withdraw">("deposit");
  const [amount, setAmount] = useState("");
  const mutation = useMutation({
    mutationFn: () => (mode === "deposit"
      ? cashApi.deposit({ amount: Number(amount) })
      : cashApi.withdraw({ amount: Number(amount) })).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["cash"] }); onClose(); },
  });
  return (
    <Modal title="السيولة النقدية" onClose={onClose}>
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-2">
          <button onClick={() => setMode("deposit")} className="py-2 rounded-xl text-sm font-bold border"
            style={mode === "deposit" ? {background:"rgba(16,185,129,.13)",color:"#10b981",borderColor:"rgba(16,185,129,.4)"} : {borderColor:"#1a2540",color:"#64748b"}}>إيداع (ضخ)</button>
          <button onClick={() => setMode("withdraw")} className="py-2 rounded-xl text-sm font-bold border"
            style={mode === "withdraw" ? {background:"rgba(244,63,94,.13)",color:"#f43f5e",borderColor:"rgba(244,63,94,.4)"} : {borderColor:"#1a2540",color:"#64748b"}}>سحب</button>
        </div>
        <Field label="المبلغ"><input className="input" type="number" step="0.01" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" autoFocus /></Field>
        <div className="flex gap-3 pt-1">
          <button className="btn-primary flex-1" onClick={() => mutation.mutate()} disabled={mutation.isPending || !(Number(amount) > 0)}>تأكيد</button>
          <button className="btn-ghost" onClick={onClose}>إلغاء</button>
        </div>
        {mutation.isError && <p className="text-red-400 text-xs">{(mutation.error as any)?.response?.data?.detail || "حدث خطأ"}</p>}
      </div>
    </Modal>
  );
}

// ── Edit Holding (shares / avg cost — for migrating an existing portfolio) ──
function HoldingModal({ holding, onClose }: { holding: any; onClose: () => void }) {
  const tr = useT();
  const qc = useQueryClient();
  const [qty, setQty] = useState(String(holding.quantity ?? holding.total_shares ?? ""));
  const [avg, setAvg] = useState(String(holding.average_cost ?? ""));
  const mutation = useMutation({
    mutationFn: () => holdingsApi.update(holding.company_id ?? holding.company?.id, {
      quantity: Number(qty), average_cost: Number(avg),
    }).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["portfolio"] }); qc.invalidateQueries({ queryKey: ["portfolio-summary"] }); onClose(); },
  });
  return (
    <Modal title={`تعديل المركز — ${holding.company?.name_ar || holding.company?.name}`} onClose={onClose}>
      <div className="space-y-3">
        <div className="grid grid-cols-2 gap-3">
          <Field label="عدد الأسهم"><input className="input" type="number" value={qty} onChange={e => setQty(e.target.value)} /></Field>
          <Field label="متوسط التكلفة"><input className="input" type="number" step="0.01" value={avg} onChange={e => setAvg(e.target.value)} /></Field>
        </div>
        {Number(qty) > 0 && Number(avg) > 0 && (
          <div className="bg-[#111c30] rounded-xl p-3 text-sm">
            <span className="text-slate-400">إجمالي المستثمر: </span>
            <span className="text-white font-bold">{(Number(qty) * Number(avg)).toLocaleString()}</span>
          </div>
        )}
        <div className="flex gap-3 pt-1">
          <button className="btn-primary flex-1" onClick={() => mutation.mutate()} disabled={mutation.isPending || !qty || !avg}>
            {mutation.isPending ? tr("common.saving") : tr("common.save")}
          </button>
          <button className="btn-ghost" onClick={onClose}>{tr("common.cancel")}</button>
        </div>
        {mutation.isError && <p className="text-red-400 text-xs">{tr("common.error")}</p>}
      </div>
    </Modal>
  );
}

// ── Delete Confirm ────────────────────────────────────────────
function DeleteModal({ company, onClose }: { company: any; onClose: () => void }) {
  const tr = useT();
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: () => companiesApi.remove(company.id).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["companies"] }); qc.invalidateQueries({ queryKey: ["portfolio"] }); onClose(); },
  });
  return (
    <Modal title={tr("port.deleteCompany")} onClose={onClose}>
      <p className="text-slate-300 mb-6">{tr("port.deleteConfirm")} <strong className="text-white">{company.name_ar || company.name}</strong>{tr("port.deleteWarn")}</p>
      <div className="flex gap-3">
        <button className="btn-danger flex-1" onClick={() => mutation.mutate()} disabled={mutation.isPending}>
          {mutation.isPending ? tr("port.deleting") : tr("port.yesDelete")}
        </button>
        <button className="btn-ghost flex-1" onClick={onClose}>{tr("common.cancel")}</button>
      </div>
    </Modal>
  );
}

// ── Portfolio Financial Metrics (المؤشرات المالية للمحفظة) ────
function PortfolioMetricsCard() {
  const { data: m } = useQuery({ queryKey: ["portfolio-metrics"], queryFn: () => portfolioApi.metrics().then(r => r.data.data), retry: 0 });
  if (!m) return null;
  const cells = [
    ["مكرر الربحية P/E", m.pe_ratio != null ? m.pe_ratio.toFixed(2) : null],
    ["عائد التوزيعات", m.dividend_yield != null ? m.dividend_yield.toFixed(2) + "%" : null],
    ["العائد على الحقوق ROE", m.roe != null ? m.roe.toFixed(1) + "%" : null],
    ["ربحية السهم EPS", m.eps != null ? m.eps.toFixed(2) : null],
    ["هامش الربح", m.profit_margin != null ? m.profit_margin.toFixed(1) + "%" : null],
    ["اتجاه المحللين", m.analyst_upside_pct != null ? (m.analyst_upside_pct >= 0 ? "+" : "") + m.analyst_upside_pct.toFixed(1) + "%" : null],
  ].filter(([, v]) => v != null);
  if (cells.length === 0) return null;
  return (
    <div className="card">
      <div className="flex items-center gap-2 mb-3">
        <TrendingUp size={15} className="text-blue-400" />
        <h2 className="text-[13px] font-bold text-white">المؤشرات المالية للمحفظة</h2>
        <span className="text-[11px] text-slate-500 mr-auto">متوسط مرجّح لـ {m.companies_covered} شركة</span>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
        {cells.map(([lbl, v]) => (
          <div key={lbl as string} className="kpi"><div className="kpi-lbl">{lbl}</div><div className="kpi-val">{v}</div></div>
        ))}
      </div>
    </div>
  );
}

// ── Target Weights & Rebalance (advisory only) ───────────────
function RebalanceCard() {
  const qc = useQueryClient();
  const [targets, setTargets] = useState<Record<number, string>>({});
  const [showSuggestions, setShowSuggestions] = useState(false);

  const { data: alloc } = useQuery({
    queryKey: ["allocation"],
    queryFn: () => allocationApi.get().then(r => r.data.data),
  });
  const { data: reb, refetch: runRebalance, isFetching } = useQuery({
    queryKey: ["rebalance"],
    queryFn: () => allocationApi.rebalance().then(r => r.data.data),
    enabled: false,
  });
  const saveMutation = useMutation({
    mutationFn: () => allocationApi.setTargets(
      Object.entries(targets).map(([id, w]) => ({ company_id: Number(id), target_weight: Number(w) || 0 }))
    ).then(r => r.data),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["allocation"] }); },
  });

  const items = alloc?.items ?? [];
  if (!items.length) return null;
  const val = (id: number, fallback: number) => targets[id] !== undefined ? targets[id] : String(fallback || "");
  const sumTargets = items.reduce((a: number, it: any) => a + (Number(val(it.company_id, it.target_weight)) || 0), 0);

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Scale size={15} className="text-cyan-400" />
          <h2 className="text-[13px] font-bold text-white">الأوزان المستهدفة وإعادة التوازن</h2>
        </div>
        <div className="flex items-center gap-2">
          <span className={"text-xs font-bold " + (Math.abs(sumTargets - 100) < 0.01 ? "text-emerald-400" : "text-amber-400")}>المجموع: {sumTargets.toFixed(1)}%</span>
          <button className="btn-ghost" onClick={() => saveMutation.mutate()} disabled={saveMutation.isPending}>حفظ الأوزان</button>
          <button className="btn-primary" onClick={() => { setShowSuggestions(true); runRebalance(); }} disabled={isFetching}>
            {isFetching ? "جاري الحساب..." : "اقتراح إعادة التوازن"}
          </button>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead><tr className="border-b border-[#1a2540]">
            <th className="th text-start">الشركة</th>
            <th className="th text-start">القيمة</th>
            <th className="th text-start">الوزن الحالي</th>
            <th className="th text-start">الوزن المستهدف %</th>
            <th className="th text-start">المتبقي للهدف</th>
            <th className="th text-start">المتبقي (أسهم)</th>
          </tr></thead>
          <tbody>
            {items.map((it: any) => {
              const investable = alloc?.investable || 0;
              const tw = Number(val(it.company_id, it.target_weight)) || 0;
              const remaining = tw / 100 * investable - (it.market_value || 0);
              const remShares = it.last_price > 0 ? remaining / it.last_price : 0;
              return (
              <tr key={it.company_id}>
                <td className="td"><span className="text-white font-semibold text-[13px]">{it.name}</span> <span className="tag-b ms-1" style={{fontSize:10,padding:"2px 6px"}}>{it.symbol}</span></td>
                <td className="td text-slate-300">{fmt(it.market_value)}</td>
                <td className="td"><span className="tag-n">{it.current_weight}%</span></td>
                <td className="td">
                  <input className="input" style={{width: 90, padding: "6px 10px"}} type="number" min="0" max="100" step="0.5"
                    value={val(it.company_id, it.target_weight)}
                    onChange={e => setTargets(s => ({ ...s, [it.company_id]: e.target.value }))} />
                </td>
                <td className="td">
                  {tw > 0 ? (
                    <span className={remaining > 1 ? "profit text-xs font-bold" : "text-emerald-400 text-xs font-bold"}>
                      {remaining > 1 ? `${fmt(remaining)}` : "تحقق ✓"}
                    </span>
                  ) : <span className="text-slate-600 text-xs">—</span>}
                </td>
                <td className="td">
                  {tw > 0 && remaining > 1 && it.last_price > 0
                    ? <span className="tag-b" style={{fontSize:10}}>≈ {Math.ceil(remShares).toLocaleString("en-US")} سهم بآخر إغلاق {it.last_price.toLocaleString("en-US", {maximumFractionDigits:2})}</span>
                    : <span className="text-slate-600 text-xs">—</span>}
                </td>
              </tr>
            );})}
          </tbody>
        </table>
      </div>
      {showSuggestions && reb && (
        <div className="mt-4 rounded-xl p-4" style={{background:"rgba(6,182,212,.06)", border:"1px solid rgba(6,182,212,.2)"}}>
          <p className="text-cyan-300 text-xs font-bold mb-3">اقتراحات إعادة التوازن — {reb.note || "القرار يبقى بيدك"}</p>
          {(reb.suggestions ?? []).length === 0 ? (
            <p className="text-slate-500 text-xs">{reb.message || "لا توجد اقتراحات"}</p>
          ) : (
            <div className="space-y-1.5">
              {reb.suggestions.filter((s: any) => s.action !== "HOLD").map((s: any) => (
                <div key={s.company_id} className="flex items-center gap-3 text-xs">
                  <span className={s.action === "BUY" ? "tag-g" : "tag-r"}>{s.action === "BUY" ? "شراء" : "بيع"}</span>
                  <span className="text-white font-semibold">{s.name}</span>
                  <span className="text-slate-400">{fmt(Math.abs(s.delta_value))}{s.est_shares ? ` (≈ ${s.est_shares} سهم)` : ""}</span>
                  <span className="text-slate-600 ms-auto">{s.current_weight}% ← {s.target_weight}%</span>
                </div>
              ))}
              {reb.suggestions.every((s: any) => s.action === "HOLD") && <p className="text-emerald-400 text-xs">المحفظة متوازنة ✓</p>}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────
export default function PortfolioPage() {
  const t = useT();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [addOpen, setAddOpen]   = useState(false);
  const [editComp, setEditComp] = useState<any>(null);
  const [txComp, setTxComp]     = useState<any>(null);
  const [delComp, setDelComp]   = useState<any>(null);
  const [editHold, setEditHold] = useState<any>(null);
  const [cashOpen, setCashOpen] = useState(false);
  const [colsOpen, setColsOpen] = useState(false);
  const { portfolioCols: cols, togglePortfolioCol } = useAppStore();

  const { data: holdings = [], isLoading } = useQuery({
    queryKey: ["portfolio"],
    queryFn: () => holdingsApi.list().then(r => Array.isArray(r.data?.data) ? r.data.data : []),
  });

  const { data: companies = [] } = useQuery({
    queryKey: ["companies"],
    queryFn: () => companiesApi.list().then(r => Array.isArray(r.data.data) ? r.data.data : []),
  });

  const filtered = holdings.filter((h: any) => {
    const q = search.toLowerCase();
    return !q || (h.company?.name || "").toLowerCase().includes(q)
              || (h.company?.name_ar || "").includes(q)
              || (h.company?.symbol || "").toLowerCase().includes(q);
  });

  if (isLoading) return (
    <div className="space-y-4 fade-in">
      <div className="h-8 skeleton w-48" />
      {[...Array(5)].map((_, i) => <div key={i} className="h-16 skeleton" />)}
    </div>
  );

  return (
    <div className="space-y-5 fade-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">{t("port.title")}</h1>
          <p className="text-slate-400 text-sm mt-0.5">{holdings.length} {t("port.count")}</p>
        </div>
        <div className="flex gap-2">
          <button className="btn-ghost" onClick={() => setCashOpen(true)}>
            <Wallet size={15} /> السيولة
          </button>
          <button className="btn-primary" onClick={() => setAddOpen(true)}>
            <Plus size={16} /> {t("port.addCompany")}
          </button>
        </div>
      </div>

      {/* Search */}
      <div className="relative">
        <Search size={15} className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input className="input px-9" placeholder={t("port.searchCompany")} value={search} onChange={e => setSearch(e.target.value)} />
      </div>

      {/* Table */}
      <div className="card overflow-x-auto p-0">
        {/* Column customization (point 10) */}
        <div className="flex items-center justify-end px-3 pt-2 relative">
          <button className="p-1.5 rounded-lg text-slate-500 hover:text-white hover:bg-[#111c30] transition-all"
            title="تخصيص الأعمدة" onClick={() => setColsOpen(o => !o)}>
            <Columns3 size={15} />
          </button>
          {colsOpen && (
            <div className="absolute top-9 end-3 z-30 rounded-xl p-2 shadow-2xl"
              style={{background:"var(--pop)", border:"1px solid var(--line)", minWidth: 170}}>
              {([["sector", t("common.sector")], ["shares", t("port.shares")], ["avgCost", t("port.avgCost")],
                 ["lastPrice", "آخر سعر"], ["marketValue", t("port.marketValue")], ["weight", "% من المحفظة"],
                 ["pnl", t("common.pnl")], ["dividends", "عائد التوزيعات"], ["actions", t("common.actions")]] as const).map(([id, label]) => (
                <button key={id} className="w-full flex items-center justify-between gap-3 px-2 py-1.5 rounded-lg hover:bg-[#111c30] text-xs text-slate-300"
                  onClick={() => togglePortfolioCol(id)}>
                  {label}
                  <span className={"w-3.5 h-3.5 rounded flex items-center justify-center text-[9px] " + (cols[id] ? "bg-blue-500 text-white" : "bg-[#1a2540]")}>{cols[id] ? "✓" : ""}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#1a2540]">
              <th className="th text-start">{t("common.company")}</th>
              {cols.sector && <th className="th text-start">{t("common.sector")}</th>}
              {cols.shares && <th className="th text-start">{t("port.shares")}</th>}
              {cols.avgCost && <th className="th text-start">{t("port.avgCost")}</th>}
              {cols.lastPrice && <th className="th text-start">آخر سعر</th>}
              {cols.marketValue && <th className="th text-start">{t("port.marketValue")}</th>}
              {cols.weight && <th className="th text-start">% من المحفظة</th>}
              {cols.pnl && <th className="th text-start">{t("common.pnl")}</th>}
              {cols.dividends && <th className="th text-start">عائد التوزيعات</th>}
              {cols.actions && <th className="th text-start">{t("common.actions")}</th>}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr><td colSpan={1 + Object.values(cols).filter(Boolean).length} className="td text-center text-slate-500 py-10">{t("port.empty")}</td></tr>
            )}
            {filtered.map((h: any) => {
              const totalMV = filtered.reduce((a: number, x: any) => a + (x.current_value || 0), 0);
              const pnl    = (h.current_value || 0) - (h.total_cost || 0);
              const pnlPct = h.total_cost ? (pnl / h.total_cost) * 100 : 0;
              const avgCost = h.total_shares ? (h.total_cost / h.total_shares) : 0;
              const weight = totalMV ? (h.current_value || 0) / totalMV * 100 : 0;
              const divPct = h.total_cost ? (h.total_dividends_received || 0) / h.total_cost * 100 : 0;
              return (
                <tr key={h.id} className="hover:bg-[#111c30] transition-colors group">
                  <td className="td">
                    <button onClick={() => navigate("/portfolio/" + h.company?.id)} className="text-start hover:opacity-80 transition-opacity">
                      {(() => {
                        const dir = lookupCompany(h.company?.symbol);
                        const ar = dir?.name_ar || h.company?.name_ar || h.company?.name;
                        const en = dir?.name_en || (h.company?.name !== ar ? h.company?.name : "");
                        return (
                          <div className="flex items-center gap-2.5 flex-wrap">
                            <CompanyLogo symbol={h.company?.symbol} color={h.company?.color} size={30} logoUrl={h.company?.logo_url} />
                            <ShariaBadge status={h.company?.sharia_status} />
                            <span className="text-white font-bold text-[13px]">{ar}</span>
                            <span className="tag-b" style={{fontSize: 10, padding: "2px 7px"}}>{h.company?.symbol}</span>
                            {en && <span className="text-slate-500 text-[11px]" dir="ltr">{en}</span>}
                          </div>
                        );
                      })()}
                    </button>
                  </td>
                  {cols.sector && <td className="td">
                    <span className="tag-b">{h.company?.sector || "—"}</span>
                  </td>}
                  {cols.shares && <td className="td text-slate-300">{h.total_shares?.toLocaleString() ?? "—"}</td>}
                  {cols.avgCost && <td className="td text-slate-300">{fmt(avgCost)}</td>}
                  {cols.lastPrice && <td className="td text-slate-300">{h.last_price ? h.last_price.toLocaleString("en-US", {maximumFractionDigits: 2}) + "" : "—"}</td>}
                  {cols.marketValue && <td className="td text-white font-semibold">{fmt(h.current_value)}</td>}
                  {cols.weight && <td className="td">
                    <div className="flex items-center gap-2" style={{minWidth: 80}}>
                      <div className="h-1.5 rounded-full bg-slate-800 flex-1" style={{maxWidth: 56}}>
                        <div className="h-1.5 rounded-full bg-blue-500" style={{width: `${Math.min(100, weight)}%`}} />
                      </div>
                      <span className="text-xs text-slate-300">{weight.toFixed(1)}%</span>
                    </div>
                  </td>}
                  {cols.pnl && <td className="td">
                    <div className="flex items-center gap-1.5">
                      {pnl >= 0 ? <TrendingUp size={14} className="text-emerald-400" /> : <TrendingDown size={14} className="text-red-400" />}
                      <div>
                        <p className={pnl >= 0 ? "profit font-semibold text-sm" : "loss font-semibold text-sm"}>{pnl >= 0 ? "+" : ""}{fmt(pnl)}</p>
                        <p className={pnl >= 0 ? "text-xs text-emerald-400" : "text-xs text-red-400"}>{pnlPct.toFixed(2)}%</p>
                      </div>
                    </div>
                  </td>}
                  {cols.dividends && <td className="td">
                    {h.total_dividends_received > 0
                      ? <span className="tag-g">+{fmt(h.total_dividends_received)} · {divPct.toFixed(1)}%</span>
                      : <span className="text-slate-600 text-xs">—</span>}
                  </td>}
                  {cols.actions && <td className="td">
                    <div className="flex items-center gap-1">
                      <button onClick={() => setTxComp(h.company)} title="شراء/بيع"
                        className="p-1.5 rounded-lg text-slate-500 hover:text-blue-400 hover:bg-blue-500/10 transition-all">
                        <ShoppingCart size={14} />
                      </button>
                      <button onClick={() => setEditHold(h)} title="تعديل الأسهم/التكلفة"
                        className="p-1.5 rounded-lg text-slate-500 hover:text-violet-400 hover:bg-violet-500/10 transition-all">
                        <SlidersHorizontal size={14} />
                      </button>
                      <button onClick={() => setEditComp(h.company)} title="تعديل"
                        className="p-1.5 rounded-lg text-slate-500 hover:text-amber-400 hover:bg-amber-500/10 transition-all">
                        <Pencil size={14} />
                      </button>
                      <button onClick={() => setDelComp(h.company)} title="حذف"
                        className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Charts — real allocation of the current portfolio */}
      <PortfolioCharts holdings={holdings} />

      {/* Portfolio-level financial indicators (weighted averages) */}
      <PortfolioMetricsCard />

      {/* Current weights vs target + rebalance suggestions */}
      <RebalanceCard />

      {/* Companies without holdings */}
      {companies.length > 0 && (
        <div className="card">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-slate-300">{t("port.allCompanies")}</h2>
            <span className="tag-b">{companies.length}</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {companies.map((c: any) => (
              <button key={c.id} onClick={() => navigate("/portfolio/" + c.id)}
                className="tag-n hover:text-white transition-colors cursor-pointer">
                {c.symbol} · {c.name_ar || c.name}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Modals */}
      {addOpen   && <CompanyModal onClose={() => setAddOpen(false)} />}
      {editComp  && <CompanyModal company={editComp} onClose={() => setEditComp(null)} />}
      {txComp    && <TransactionModal company={txComp} onClose={() => setTxComp(null)} />}
      {delComp   && <DeleteModal company={delComp} onClose={() => setDelComp(null)} />}
      {editHold  && <HoldingModal holding={editHold} onClose={() => setEditHold(null)} />}
      {cashOpen  && <CashModal onClose={() => setCashOpen(false)} />}
    </div>
  );
}
