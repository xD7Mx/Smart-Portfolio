import React from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { notificationsApi } from "../services/api";
import { Bell, Check, Trash2 } from "lucide-react";
import { useT } from "../i18n";

const PRIORITY_COLORS: any = { CRITICAL: "text-red-400", HIGH: "text-amber-400", MEDIUM: "text-blue-400", LOW: "text-slate-400", INFO: "text-slate-500" };

export default function NotificationsPage() {
  const t = useT();
  const qc = useQueryClient();
  const { data: notifs = [] } = useQuery({
    queryKey: ["notifications"],
    queryFn: () => notificationsApi.list().then(r => (Array.isArray(r.data.data) ? r.data.data : [])),
  });

  const readMutation   = useMutation({ mutationFn: notificationsApi.read,   onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }) });
  const deleteMutation = useMutation({ mutationFn: notificationsApi.delete, onSuccess: () => qc.invalidateQueries({ queryKey: ["notifications"] }) });

  const unread  = notifs.filter((n: any) => n.status === "UNREAD");
  const allRead = notifs.filter((n: any) => n.status !== "UNREAD");

  return (
    <div className="space-y-6 fade-in">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">{t("notif.title")}</h1>
          <p className="text-slate-400 text-sm mt-1">{t("notif.subtitle")}</p>
        </div>
        <span className={unread.length > 0 ? "tag-a" : "tag-n"}>{unread.length} {t("notif.unread")}</span>
      </div>

      <div className="card">
        <h2 className="text-sm font-bold text-slate-300 mb-4">{t("notif.unread")}</h2>
        {unread.length === 0 ? (
          <div className="text-center py-8 text-slate-500">
            <Bell size={28} className="mx-auto mb-2 opacity-50" />
            <p className="text-sm">{t("notif.empty")}</p>
          </div>
        ) : (
          <div className="space-y-2.5">
            {unread.map((n: any) => (
              <div key={n.id} className="notif" style={{borderColor: ({CRITICAL:"#f43f5e",HIGH:"#f59e0b",MEDIUM:"#3b82f6",LOW:"#8b5cf6",INFO:"#64748b"} as any)[n.priority] || "#3b82f6"}}>
                <div className="flex-1 min-w-0">
                  <p className="notif-title">{n.title}</p>
                  <p className="notif-msg">{n.message}</p>
                  <p className="notif-time">{n.created_at ? new Date(n.created_at).toLocaleString("en-US") : "—"}</p>
                </div>
                <div className="flex gap-1 shrink-0">
                  <button onClick={() => readMutation.mutate(n.id)} className="p-1.5 rounded-lg text-slate-500 hover:text-emerald-400 hover:bg-emerald-500/10 transition-all"><Check size={14} /></button>
                  <button onClick={() => deleteMutation.mutate(n.id)} className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all"><Trash2 size={14} /></button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {allRead.length > 0 && (
        <div className="card">
          <h2 className="text-sm font-bold text-slate-300 mb-3">{t("notif.read")}</h2>
          <div className="space-y-1">
            {allRead.slice(0, 20).map((n: any) => (
              <div key={n.id} className="flex items-start gap-3 py-2 border-b border-[#1a2540] last:border-0 opacity-60">
                <p className="text-sm flex-1 text-slate-300">{n.title}</p>
                <p className="text-xs text-slate-500">{n.created_at ? new Date(n.created_at).toLocaleDateString("en-GB") : "—"}</p>
                <button onClick={() => deleteMutation.mutate(n.id)} className="p-1 rounded-lg text-slate-500 hover:text-red-400 transition-all"><Trash2 size={12} /></button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
