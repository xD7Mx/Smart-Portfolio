import React, { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  ArrowRight, Plus, X, TrendingUp, TrendingDown, Coins, Activity, Layers, Pencil, Trash2, Check
} from "lucide-react";
import {
  companiesApi, holdingsApi, dividendsApi, transactionsApi, marketApi
} from "../services/api";
import { lookupCompany } from "../data/saudiCompanies";
import CompanyLogo from "../components/common/CompanyLogo";
import { ShariaBadge, ShariaStatusIndicator } from "../components/common/UI";
import AnalysisPanel from "../components/analysis/AnalysisPanel";
import FinancialsTable from "../components/analysis/FinancialsTable";
import OwnershipBar from "../components/analysis/OwnershipBar";
import DividendProfile from "../components/analysis/DividendProfile";
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import clsx from "clsx";

const fmt  = (n: number, dec = 2) => (n ?? 0).toLocaleString("en-US", { minimumFractionDigits: dec, maximumFractionDigits: dec });
const fmt0 = (n: number) => (n ?? 0).toLocaleString("en-US", { maximumFractionDigits: 0 });

const TABS = [
  { id: "overview",  label: "نظرة عامة" },
  { id: "analysis",  label: "تقييم الذكاء" },
  { id: "financials", label: "القوائم المالية" },
  { id: "txs",       label: "سجل العمليات" },
  { id: "divs",      label: "التوزيعات" },
] as const;

const TX_TYPES = [
  { id: "BUY",          label: "شراء",          color: "#10b981" },
  { id: "SELL",         label: "بيع",           color: "#f43f5e" },
  { id: "DIVIDEND",     label: "توزيع نقدي",    color: "#f59e0b" },
  { id: "REINVESTMENT", label: "إعادة استثمار", color: "#06b6d4" },
  { id: "BONUS",        label: "منحة أسهم",     color: "#8b5cf6" },
  { id: "SPLIT",        label: "تجزئة",         color: "#6366f1" },
];
const TX_LABEL: Record<string, { label: string; color: string }> =
  Object.fromEntries(TX_TYPES.map(t => [t.id, t]));

function Empty({ label = "لا توجد بيانات حالياً" }: { label?: string }) {
  return <div className="py-10 text-center text-slate-500 text-sm">{label}</div>;
}

function Stat({ label, value, sub, icon: Icon, ic, color, cls = "" }: any) {
  return (
    <div className="mc">
      <div className={"mc-icon " + ic}><Icon size={14} style={{ color }} /></div>
      <div className="mc-lbl">{label}</div>
      <div className={"mc-val " + cls}>{value}</div>
      {sub && <div className="mc-sub">{sub}</div>}
    </div>
  );
}

/* Quick transaction modal — same engine/payload contract as PortfolioPage */
function TxModal({ companyId, onClose }: { companyId: number; onClose: () => void }) {
  const qc = useQueryClient();
  const [type, setType] = useState("BUY");
  const [f, setF] = useState({ shares: "", price: "", amount: "", factor: "2", date: new Date().toISOString().slice(0, 10) });
  const set = (k: string) => (e: any) => setF(v => ({ ...v, [k]: e.target.value }));

  const mut = useMutation({
    mutationFn: () => {
      const payload: any = { company_id: companyId, transaction_type: type, transaction_date: f.date };
      if (type === "BUY" || type === "SELL") { payload.shares = Number(f.shares); payload.price_per_share = Number(f.price); }
      if (type === "DIVIDEND") { payload.amount = Number(f.amount); }
      if (type === "REINVESTMENT") { payload.amount = Number(f.amount); payload.price_per_share = Number(f.price); }
      if (type === "BONUS") { payload.shares = Number(f.shares); }
      if (type === "SPLIT") { payload.factor = Number(f.factor); }
      return transactionsApi.add(payload).then(r => r.data);
    },
    onSuccess: () => {
      ["portfolio", "portfolio-summary", "transactions", "cash", "holding", "dividends"].forEach(k =>
        qc.invalidateQueries({ queryKey: [k] }));
      onClose();
    },
  });

  const valid =
    (["BUY", "SELL"].includes(type) && Number(f.shares) > 0 && Number(f.price) > 0) ||
    (type === "DIVIDEND" && Number(f.amount) > 0) ||
    (type === "REINVESTMENT" && Number(f.amount) > 0 && Number(f.price) > 0) ||
    (type === "BONUS" && Number(f.shares) > 0) ||
    (type === "SPLIT" && Number(f.factor) > 0);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box max-w-md" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-white">عملية جديدة</h3>
          <button className="text-slate-500 hover:text-white" onClick={onClose}><X size={18} /></button>
        </div>
        <div className="grid grid-cols-3 gap-2 mb-4">
          {TX_TYPES.map(t => (
            <button key={t.id} onClick={() => setType(t.id)}
              className="py-2 rounded-xl text-xs font-bold transition-all border"
              style={type === t.id
                ? { background: t.color + "22", color: t.color, borderColor: t.color + "66" }
                : { borderColor: "var(--line)", color: "#64748b" }}>
              {t.label}
            </button>
          ))}
        </div>
        <div className="space-y-3">
          {["BUY", "SELL", "BONUS"].includes(type) && (
            <div><label className="label">عدد الأسهم</label><input className="input" type="number" value={f.shares} onChange={set("shares")} /></div>
          )}
          {["BUY", "SELL", "REINVESTMENT"].includes(type) && (
            <div><label className="label">سعر السهم</label><input className="input" type="number" value={f.price} onChange={set("price")} /></div>
          )}
          {["DIVIDEND", "REINVESTMENT"].includes(type) && (
            <div><label className="label">مبلغ التوزيع</label><input className="input" type="number" value={f.amount} onChange={set("amount")} /></div>
          )}
          {type === "SPLIT" && (
            <div><label className="label">معامل التجزئة</label><input className="input" type="number" value={f.factor} onChange={set("factor")} /></div>
          )}
          <div><label className="label">التاريخ</label><input className="input" type="date" value={f.date} onChange={set("date")} /></div>
        </div>
        <button className="btn-primary w-full mt-4" disabled={!valid || mut.isPending} onClick={() => mut.mutate()}>
          {mut.isPending ? "جارٍ الحفظ..." : "تنفيذ العملية"}
        </button>
      </div>
    </div>
  );
}

/* Daily price history chart — real closes from the provider, cached 24h */
function PriceChart({ symbol }: { symbol: string }) {
  const [range, setRange] = useState("3mo");
  const { data: points = [] } = useQuery({
    queryKey: ["price-history", symbol, range],
    queryFn: () => marketApi.history(symbol, range).then(r => Array.isArray(r.data?.data) ? r.data.data : []),
    enabled: !!symbol,
  });
  const up = points.length >= 2 && points[points.length - 1].close >= points[0].close;
  const color = up ? "#10b981" : "#f43f5e";
  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <p className="text-[13px] font-bold text-white">حركة السعر</p>
        <div className="flex gap-1.5">
          {[["1mo", "شهر"], ["3mo", "3 أشهر"], ["6mo", "6 أشهر"], ["1y", "سنة"]].map(([id, lbl]) => (
            <button key={id} onClick={() => setRange(id)}
              className={clsx("px-3 py-1 rounded-lg text-[11px] font-bold border transition-all",
                range === id ? "bg-blue-600/20 text-blue-400 border-blue-500/40" : "border-[#1a2540] text-slate-500")}>
              {lbl}
            </button>
          ))}
        </div>
      </div>
      {points.length >= 2 ? (
        <div style={{ height: 220 }} dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={points} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="pcFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={color} stopOpacity={0.3} />
                  <stop offset="100%" stopColor={color} stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.12)" />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#64748b" }} tickFormatter={(d: string) => d.slice(5)} minTickGap={28} />
              <YAxis domain={["auto", "auto"]} tick={{ fontSize: 10, fill: "#64748b" }} width={48} />
              <Tooltip contentStyle={{ background: "var(--pop)", border: "1px solid var(--line)", color: "var(--tip-text)", borderRadius: 10, fontSize: 12 }}
                formatter={(v: any) => [Number(v).toLocaleString("en-US", { maximumFractionDigits: 2 }) + "", "الإغلاق"]} />
              <Area type="monotone" dataKey="close" stroke={color} strokeWidth={2} fill="url(#pcFill)" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      ) : (
        <Empty label="لا توجد بيانات سعرية تاريخية حالياً — تُجلب مرة يومياً عند توفر المصدر" />
      )}
    </div>
  );
}

/* Dividend row — editable (amount) and deletable; both reverse/adjust cash + holding on the server */
function DividendRow({ d }: { d: any }) {
  const qc = useQueryClient();
  const [editing, setEditing] = useState(false);
  const [amount, setAmount] = useState(String(d.received ?? d.received_amount ?? 0));

  const invalidate = () => {
    ["dividends", "holding", "portfolio", "portfolio-summary", "cash", "transactions"].forEach(k =>
      qc.invalidateQueries({ queryKey: [k] }));
  };

  const updateMut = useMutation({
    mutationFn: () => {
      const shares = d.shares_at_time || 1;
      return dividendsApi.update(d.id, { dividend_per_share: Number(amount) / shares, shares_at_time: shares }).then(r => r.data);
    },
    onSuccess: () => { invalidate(); setEditing(false); },
  });
  const deleteMut = useMutation({
    mutationFn: () => dividendsApi.remove(d.id).then(r => r.data),
    onSuccess: invalidate,
  });

  return (
    <tr>
      <td className="td font-mono">{fmt(d.dividend_per_share)}</td>
      <td className="td font-mono profit">
        {editing ? (
          <input className="input" style={{ width: 100, padding: "4px 8px" }} type="number" value={amount}
            onChange={e => setAmount(e.target.value)} autoFocus />
        ) : (
          <>+{fmt0(d.received)}</>
        )}
      </td>
      <td className="td text-slate-500">{d.payment_date ? new Date(d.payment_date).toLocaleDateString("en-GB") : "—"}</td>
      <td className="td">{d.action === "REINVEST" ? <span className="tag-g">إعادة استثمار</span> : <span className="tag-b">نقدي</span>}</td>
      <td className="td">
        <div className="flex items-center gap-1 justify-end">
          {editing ? (
            <>
              <button className="p-1.5 rounded-lg text-emerald-400 hover:bg-emerald-500/10" title="حفظ"
                disabled={updateMut.isPending} onClick={() => updateMut.mutate()}><Check size={14} /></button>
              <button className="p-1.5 rounded-lg text-slate-500 hover:text-white" title="إلغاء"
                onClick={() => { setEditing(false); setAmount(String(d.received ?? 0)); }}><X size={14} /></button>
            </>
          ) : (
            <>
              <button className="p-1.5 rounded-lg text-slate-500 hover:text-amber-400 hover:bg-amber-500/10 transition-all" title="تعديل المبلغ"
                onClick={() => setEditing(true)}><Pencil size={14} /></button>
              <button className="p-1.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all" title="حذف"
                disabled={deleteMut.isPending} onClick={() => deleteMut.mutate()}><Trash2 size={14} /></button>
            </>
          )}
        </div>
      </td>
    </tr>
  );
}

export default function CompanyPage() {
  const { id } = useParams<{ id: string }>();
  const nav = useNavigate();
  const qc = useQueryClient();
  const [tab, setTab] = useState<(typeof TABS)[number]["id"]>("overview");
  const [showTx, setShowTx] = useState(false);

  const { data: company } = useQuery({ queryKey: ["company", id], queryFn: () => companiesApi.get(Number(id)).then(r => r.data.data) });

  // Resolve Sharia status on demand the first time an unresolved stock is opened.
  const resolveSharia = useMutation({
    mutationFn: () => companiesApi.resolveSharia(Number(id)).then(r => r.data?.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["company", id] }),
  });
  React.useEffect(() => {
    if (company && (!company.sharia_status || company.sharia_status === "UNKNOWN") && !resolveSharia.isPending) {
      resolveSharia.mutate();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [company?.id]);
  const { data: holding } = useQuery({ queryKey: ["holding", id], queryFn: () => holdingsApi.get(Number(id)).then(r => r.data.data) });
  const { data: txs = [] } = useQuery({
    queryKey: ["transactions", id],
    queryFn: () => transactionsApi.list().then(r => (Array.isArray(r.data.data) ? r.data.data : []).filter((t: any) => t.company_id === Number(id))),
  });
  const { data: divs = [] } = useQuery({
    queryKey: ["dividends", id],
    queryFn: () => dividendsApi.list().then(r => (Array.isArray(r.data.data) ? r.data.data : []).filter((d: any) => d.company_id === Number(id))),
  });
  if (!company) return <div className="flex items-center justify-center h-64 text-slate-500 text-sm">جارٍ تحميل بيانات الشركة...</div>;

  const ref = lookupCompany(company.symbol);
  const nameAr = company.name_ar || company.company_name_ar || ref?.name_ar || company.company_name;
  const nameEn = ref?.name_en || company.company_name;
  const profit = (holding?.market_value ?? 0) - (holding?.invested_amount ?? 0);
  const roi = holding?.invested_amount > 0 ? (profit / holding.invested_amount) * 100 : 0;
  const up = profit >= 0;
  const freeShares = (holding?.reinvestment_shares ?? 0) + (holding?.total_bonus_shares ?? 0);

  return (
    <div className="space-y-5 fade-in">
      {/* Header — trilingual identity */}
      <div className="flex items-center gap-4 flex-wrap">
        <button className="btn-ghost text-sm flex items-center gap-1" onClick={() => nav("/portfolio")}>
          <ArrowRight size={15} /> المحفظة
        </button>
        <div className="flex items-center gap-3">
          <CompanyLogo symbol={company.symbol} color={company.color} size={44} logoUrl={company.logo_url} />
          <div>
            <div className="flex items-center gap-2">
              <ShariaBadge status={company.sharia_status} size={15} />
              <h2 className="text-lg font-bold text-white">{nameAr}</h2>
              <span className="tag-b">{company.symbol}</span>
            </div>
            <div className="flex items-center gap-2 mt-0.5 text-xs text-slate-500">
              <span dir="ltr">{nameEn}</span>
              {company.sector && <span className="tag-n">{company.sector}</span>}
              {company.sharia_status === "COMPLIANT" && <span className="tag-g">متوافق شرعياً</span>}
            </div>
          </div>
        </div>
        <button className="btn-primary mr-auto flex items-center gap-1.5 text-sm" onClick={() => setShowTx(true)}>
          <Plus size={15} /> عملية جديدة
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        <Stat label="القيمة السوقية" value={fmt0(holding?.market_value)} sub={`المدفوع: ${fmt0(holding?.invested_amount)}`} icon={Activity} ic="ic-b" color="#60a5fa" cls="b" />
        <Stat label="أرباح غير محققة" value={(up ? "+" : "") + fmt0(profit)} sub={(roi >= 0 ? "+" : "") + roi.toFixed(2) + "%"} icon={up ? TrendingUp : TrendingDown} ic={up ? "ic-g" : "ic-r"} color={up ? "#10b981" : "#f43f5e"} cls={up ? "g" : "r"} />
        <Stat label="متوسط التكلفة" value={fmt(holding?.average_cost)} sub={`آخر سعر: ${fmt(holding?.last_price)}`} icon={Coins} ic="ic-v" color="#a78bfa" />
        <Stat label="عدد الأسهم" value={fmt0(holding?.quantity)} sub={`أسهم مجانية: ${fmt(freeShares, 2)}`} icon={Layers} ic="ic-a" color="#f59e0b" />
      </div>

      {/* Tabs */}
      <div className="flex gap-1.5 flex-wrap">
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={clsx("px-4 py-1.5 rounded-xl text-xs font-bold transition-all border",
              tab === t.id ? "bg-blue-600/20 text-blue-400 border-blue-500/40" : "border-[#1a2540] text-slate-500 hover:text-slate-300")}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === "overview" && (
        <>
        <div className="card">
          <p className="text-[13px] font-bold text-white mb-3">التوافق الشرعي</p>
          <ShariaStatusIndicator status={company.sharia_status} loading={resolveSharia.isPending}
            purification={company.purification} source={company.sharia_source} />
        </div>
        <PriceChart symbol={company.symbol} />
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          <div className="card">
            <p className="text-[13px] font-bold text-white mb-3">مؤشر عائد السهم</p>
            <div className="space-y-2 text-sm">
              <div className="stat-row"><span className="stat-lbl">أسهم إعادة الاستثمار</span><span className="stat-val">{fmt(holding?.reinvestment_shares ?? 0, 2)}</span></div>
              <div className="stat-row"><span className="stat-lbl">أسهم المنحة</span><span className="stat-val">{fmt(holding?.total_bonus_shares ?? 0, 2)}</span></div>
              <div className="stat-row"><span className="stat-lbl">توزيعات مستلمة</span><span className="stat-val profit">+{fmt0(holding?.total_dividends_received ?? 0)}</span></div>
              <div className="stat-row border-t border-slate-700/40 pt-2"><span className="stat-lbl font-bold">إجمالي الأسهم المجانية</span><span className="stat-val profit">{fmt(freeShares, 2)}</span></div>
            </div>
          </div>
          <OwnershipBar symbol={company.symbol} />
        </div>
        </>
      )}

      {tab === "analysis" && <AnalysisPanel symbol={company.symbol} name={nameAr} />}

      {tab === "financials" && <FinancialsTable symbol={company.symbol} />}

      {tab === "txs" && (
        <div className="card">
          <p className="text-[13px] font-bold text-white mb-3">سجل العمليات</p>
          {txs.length === 0 ? <Empty label="لا توجد عمليات مسجلة لهذه الشركة" /> : (
            <table className="w-full text-sm">
              <thead><tr>{["النوع", "الكمية", "السعر", "الإجمالي", "التاريخ"].map(h => <th key={h} className="th text-right">{h}</th>)}</tr></thead>
              <tbody>
                {txs.map((t: any) => {
                  const m = TX_LABEL[t.type] || { label: t.type, color: "#64748b" };
                  return (
                    <tr key={t.id}>
                      <td className="td"><span className="px-2 py-0.5 rounded-lg text-[11px] font-bold" style={{ background: m.color + "22", color: m.color }}>{m.label}</span></td>
                      <td className="td font-mono">{fmt(t.quantity, 2)}</td>
                      <td className="td font-mono">{fmt(t.price)}</td>
                      <td className="td font-mono">{fmt0(t.total)}</td>
                      <td className="td text-slate-500">{t.date ? new Date(t.date).toLocaleDateString("en-GB") : "—"}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </div>
      )}

      {tab === "divs" && (
        <div className="space-y-4">
          <DividendProfile symbol={company.symbol} />
          <div className="card">
            <p className="text-[13px] font-bold text-white mb-3">توزيعاتي المستلمة من هذه الشركة</p>
            {divs.length === 0 ? <Empty label="لم تُسجّل بعد أي توزيع مستلم لهذه الشركة في محفظتك" /> : (
              <table className="w-full text-sm">
                <thead><tr>{["للسهم الواحد", "المستلم", "التاريخ", "الإجراء", ""].map(h => <th key={h} className="th text-right">{h}</th>)}</tr></thead>
                <tbody>
                  {divs.map((d: any) => <DividendRow key={d.id} d={d} />)}
                </tbody>
              </table>
            )}
          </div>
        </div>
      )}

      {showTx && <TxModal companyId={Number(id)} onClose={() => setShowTx(false)} />}
    </div>
  );
}
