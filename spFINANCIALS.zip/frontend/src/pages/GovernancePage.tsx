/**
 * Governance — a per-company research desk.
 * Search a stock; the financial statements (3 years) and the AI evaluation
 * (/100 + decision) are fetched and filled automatically from the source —
 * no manual entry, no fake numbers.
 */
import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Shield, Search, X } from "lucide-react";
import { companiesApi } from "../services/api";
import { searchCompanies, lookupCompany, SaudiCompany } from "../data/saudiCompanies";
import CompanyLogo from "../components/common/CompanyLogo";
import FinancialsTable from "../components/analysis/FinancialsTable";
import AnalysisPanel from "../components/analysis/AnalysisPanel";
import { useT } from "../i18n";

export default function GovernancePage() {
  const t = useT();
  const [q, setQ] = useState("");
  const [selected, setSelected] = useState<{ symbol: string; name: string } | null>(null);
  const [suggestions, setSuggestions] = useState<SaudiCompany[]>([]);

  const { data: companies = [] } = useQuery({
    queryKey: ["companies"],
    queryFn: () => companiesApi.list().then(r => (Array.isArray(r.data.data) ? r.data.data : [])),
  });

  const pick = (symbol: string, name: string) => {
    setSelected({ symbol, name });
    setQ("");
    setSuggestions([]);
  };

  return (
    <div className="space-y-5 fade-in">
      <div>
        <h1 className="text-2xl font-bold text-white">الحوكمة</h1>
        <p className="text-slate-400 text-sm mt-1">مركز أبحاث الشركة — القوائم المالية والتقييم يُجلبان تلقائياً</p>
      </div>

      {/* Search */}
      <div className="relative max-w-xl">
        <Search size={15} className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input className="input px-9" placeholder="ابحث عن سهم بالرمز أو الاسم..." value={q}
          onChange={e => { setQ(e.target.value); setSuggestions(searchCompanies(e.target.value)); }} />
        {suggestions.length > 0 && (
          <div className="absolute z-20 top-full mt-1 w-full rounded-xl overflow-hidden shadow-2xl"
            style={{ background: "var(--pop)", border: "1px solid var(--line)", maxHeight: 260, overflowY: "auto" }}>
            {suggestions.map(c => (
              <button key={c.symbol} type="button"
                className="w-full text-start px-3 py-2.5 hover:bg-[#111c30] flex items-center gap-3 transition-colors"
                onClick={() => pick(c.symbol, c.name_ar)}>
                <CompanyLogo symbol={c.symbol} size={26} />
                <span className="tag-b shrink-0">{c.symbol}</span>
                <span className="text-white text-sm font-semibold">{c.name_ar}</span>
                <span className="text-slate-500 text-xs ms-auto">{c.name_en} · {c.sector}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Quick picks from portfolio companies */}
      {companies.length > 0 && !selected && (
        <div className="flex flex-wrap gap-2">
          <span className="text-xs text-slate-500 self-center">من محفظتك:</span>
          {companies.map((c: any) => (
            <button key={c.id} className="tag-n hover:text-white transition-colors cursor-pointer"
              onClick={() => pick(c.symbol, c.name_ar || c.name)}>
              {c.symbol} · {c.name_ar || c.name}
            </button>
          ))}
        </div>
      )}

      {!selected ? (
        <div className="card">
          <div className="py-16 text-center text-slate-500">
            <Shield size={40} className="mx-auto mb-3 opacity-30" />
            <p className="text-sm">اختر سهماً لعرض قوائمه المالية وتقييمه الذكي</p>
          </div>
        </div>
      ) : (
        <>
          <div className="flex items-center gap-3">
            <CompanyLogo symbol={selected.symbol} color={companies.find((c: any) => c.symbol === selected.symbol)?.color} size={40} logoUrl={companies.find((c: any) => c.symbol === selected.symbol)?.logo_url} />
            <div>
              <h2 className="text-lg font-bold text-white">{lookupCompany(selected.symbol)?.name_ar || selected.name}</h2>
              <span className="tag-b">{selected.symbol}</span>
            </div>
            <button className="btn-ghost mr-auto text-xs flex items-center gap-1" onClick={() => setSelected(null)}>
              <X size={13} /> تغيير السهم
            </button>
          </div>

          {/* AI evaluation /100 + decision + fundamentals (auto) */}
          <AnalysisPanel symbol={selected.symbol} name={selected.name} />

          {/* 3-year financial statements (auto-filled) */}
          <div>
            <h3 className="text-[13px] font-bold text-white mb-2 flex items-center gap-1.5">
              <Shield size={14} className="text-blue-400" /> القوائم المالية (3 سنوات)
            </h3>
            <FinancialsTable symbol={selected.symbol} />
          </div>
        </>
      )}
    </div>
  );
}
