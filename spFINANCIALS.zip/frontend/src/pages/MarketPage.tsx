import React from "react";
import { useQuery } from "@tanstack/react-query";
import { Newspaper, CalendarDays, Sparkles } from "lucide-react";
import { marketApi } from "../services/api";
import { useT } from "../i18n";
import { useAppStore } from "../store/appStore";
import { lookupCompany } from "../data/saudiCompanies";

const fmt = (d: string) => d ? new Date(d).toLocaleDateString("en-GB") : "—";
const fmtNum = (n: number) => (n ?? 0).toLocaleString("en-US", { maximumFractionDigits: 2 });

function TickerCard({ variant, label, data, prefix = "" }: { variant: string; label: string; data: any; prefix?: string }) {
  const up = (data?.change_pct ?? 0) >= 0;
  return (
    <div className={`card ${variant}`}>
      <p className="ticker-lbl" style={{color: variant === "ticker-tasi" ? "#34d399" : variant === "ticker-brent" ? "#fbbf24" : "#fde047"}}>{label}</p>
      {data?.price ? (
        <>
          <p className="ticker-val">{prefix}{fmtNum(data.price)}</p>
          <p className="ticker-ch" style={{color: up ? "#34d399" : "#f87171"}}>
            {up ? "▲" : "▼"} {(up ? "+" : "")}{fmtNum(data.change)} ({(up ? "+" : "")}{fmtNum(data.change_pct)}%)
          </p>
        </>
      ) : (
        <p className="ticker-val text-slate-600">—</p>
      )}
    </div>
  );
}

export default function MarketPage() {
  const t = useT();
  const { tickers } = useAppStore();
  const { data: overview } = useQuery({
    queryKey: ["market-overview"],
    queryFn: () => marketApi.overview().then(r => r.data.data),
    refetchInterval: 5 * 60 * 1000,
  });
  const { data: news = [], isLoading } = useQuery({
    queryKey: ["market-news"],
    queryFn: () => marketApi.news().then(r => (Array.isArray(r.data.data) ? r.data.data : [])),
  });
  const { data: events = [] } = useQuery({
    queryKey: ["market-events"],
    queryFn: () => marketApi.events().then(r => (Array.isArray(r.data.data) ? r.data.data : [])),
  });
  const { data: marketSummary } = useQuery({
    queryKey: ["market-summary"],
    queryFn: () => marketApi.summary().then(r => r.data.data),
    refetchInterval: 30 * 60 * 1000,
  });

  const enabled = [
    tickers.tasi && { key: "tasi", variant: "ticker-tasi", label: t("market.tasi"), data: overview?.tasi, prefix: "" },
    tickers.brent && { key: "brent", variant: "ticker-brent", label: t("market.brent"), data: overview?.brent, prefix: "" },
    tickers.gold && { key: "gold", variant: "ticker-gold", label: t("market.gold"), data: overview?.gold, prefix: "" },
  ].filter(Boolean) as any[];

  return (
    <div className="space-y-5 fade-in">
      <div>
        <h1 className="text-2xl font-bold text-white">{t("market.title")}</h1>
        <p className="text-slate-400 text-sm mt-1">{t("market.subtitle")}</p>
      </div>

      {/* Ticker cards — user picks which ones in Settings */}
      {enabled.length > 0 && (
        <div className={`grid gap-4 ${enabled.length === 3 ? "grid-cols-1 md:grid-cols-3" : enabled.length === 2 ? "grid-cols-1 md:grid-cols-2" : "grid-cols-1"}`}>
          {enabled.map(tk => <TickerCard key={tk.key} variant={tk.variant} label={tk.label} data={tk.data} prefix={tk.prefix} />)}
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* News */}
        <div className="card lg:col-span-2">
          <div className="flex items-center gap-2 mb-4">
            <Newspaper size={16} className="text-amber-400" />
            <h2 className="text-sm font-bold text-white">{t("market.news")}</h2>
            {news.some((n: any) => n.source === "AI") && <span className="tag-v ms-auto">{t("market.aiGenerated")}</span>}
          </div>
          {isLoading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => <div key={i} className="h-14 skeleton" />)}
            </div>
          ) : news.length === 0 ? (
            <div className="h-40 flex items-center justify-center text-slate-500 text-sm">{t("market.noNews")}</div>
          ) : (
            <div className="flex flex-col gap-2.5">
              {news.map((n: any, i: number) => {
                const inner = (
                  <div className="flex-1">
                    <p className="text-xs text-slate-500 mb-1">{[n.source, n.company, n.published ? fmt(n.published) : null].filter(Boolean).join(" · ")}</p>
                    <p className="text-sm font-semibold text-white">{n.headline}</p>
                  </div>
                );
                return n.url ? (
                  <a key={n.id ?? i} href={n.url} target="_blank" rel="noopener noreferrer"
                    className="news-item hover:opacity-90 transition-opacity cursor-pointer" style={{borderColor: ["#3b82f6","#8b5cf6","#10b981","#f59e0b"][i % 4]}}>
                    {inner}
                  </a>
                ) : (
                  <div key={n.id ?? i} className="news-item" style={{borderColor: ["#3b82f6","#8b5cf6","#10b981","#f59e0b"][i % 4]}}>{inner}</div>
                );
              })}
            </div>
          )}
        </div>

        {/* Events + AI */}
        <div className="space-y-6">
          <div className="card">
            <div className="flex items-center gap-2 mb-4">
              <CalendarDays size={16} className="text-purple-400" />
              <h2 className="text-sm font-bold text-white">{t("market.calendar")}</h2>
            </div>
            {events.length === 0 ? (
              <div className="h-24 flex items-center justify-center text-slate-500 text-sm">{t("market.noEvents")}</div>
            ) : (
              <div className="flex flex-col gap-2.5">
                {events.map((e: any, i: number) => (
                  <div key={e.id ?? i} className="flex items-start gap-3 p-2.5 bg-[#0a1020] rounded-xl">
                    <div className="w-2 h-2 rounded-full shrink-0 mt-1.5" style={{background: ["#10b981","#3b82f6","#8b5cf6","#64748b"][i % 4]}} />
                    <div className="flex-1 min-w-0">
                      <p className="text-white text-[13px] font-semibold">{e.type}</p>
                      <p className="text-slate-500 text-xs mt-0.5">
                        {(() => {
                          const name = e.company_name || lookupCompany(e.symbol)?.name_ar;
                          return name ? `${name} (${e.symbol})` : e.symbol;
                        })()} · {fmt(e.date)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="card">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles size={16} className="text-amber-400" />
              <h2 className="text-sm font-bold text-white">ملخص السوق (تاسي)</h2>
              {marketSummary?.source === "AI" && <span className="tag-v ms-auto" style={{fontSize:10}}>AI</span>}
            </div>
            <p className="text-sm text-slate-300 leading-relaxed">
              {marketSummary?.summary ?? "جارٍ تحميل حالة السوق..."}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
