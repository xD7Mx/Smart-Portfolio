/**
 * Workspace Dashboard — Customization First.
 * Drag, resize, hide, add widgets; multiple named layouts (Layout Manager);
 * everything auto-saved; one-click reset to defaults.
 */
import React, { useState } from "react";
import { GridLayout, useContainerWidth, verticalCompactor } from "react-grid-layout";
import "react-grid-layout/css/styles.css";
import { Plus, X, RotateCcw, GripVertical, LayoutGrid, Trash2 } from "lucide-react";
import { useAppStore, DEFAULT_LAYOUTS, GridItem } from "../store/appStore";
import { WIDGETS, WIDGET_MAP } from "../widgets/Widgets";

const MOBILE_BREAKPOINT = 680;

/**
 * Mobile default reflow: small stat cards (h<=1) pair two-per-row, larger
 * widgets (charts/lists) take the full width one-per-row — same order as the
 * active layout. Every section reflows automatically for phones without any
 * manual dragging.
 */
function mobileReflow(grid: GridItem[]): GridItem[] {
  const items = [...grid].sort((a, b) => (a.y - b.y) || (a.x - b.x));
  const out: GridItem[] = [];
  let y = 0;
  let halfOpen = false;
  for (const it of items) {
    const isSmall = it.h <= 1;
    if (isSmall) {
      if (!halfOpen) { out.push({ ...it, x: 0, y, w: 1, h: 1 }); halfOpen = true; }
      else { out.push({ ...it, x: 1, y, w: 1, h: 1 }); halfOpen = false; y += 1; }
    } else {
      if (halfOpen) { y += 1; halfOpen = false; }
      out.push({ ...it, x: 0, y, w: 2, h: it.h });
      y += it.h;
    }
  }
  return out;
}

export default function DashboardPage() {
  const { activeLayout, layouts, setActiveLayout, saveGrid, addWidget, removeWidget, addLayout, deleteLayout, resetLayout } = useAppStore();
  const { width, containerRef, mounted } = useContainerWidth();
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [newLayoutOpen, setNewLayoutOpen] = useState(false);
  const [newName, setNewName] = useState("");

  const layout = layouts[activeLayout] ?? Object.values(layouts)[0];
  const grid = layout?.grid ?? [];
  const usedIds = new Set(grid.map(g => g.i));
  const available = WIDGETS.filter(w => !usedIds.has(w.id));

  const isMobile = mounted && width > 0 && width < MOBILE_BREAKPOINT;
  const renderGrid = isMobile ? mobileReflow(grid) : grid;

  return (
    <div className="space-y-4 fade-in">
      {/* Header + Layout Manager */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white">لوحة التحكم</h1>
          <p className="text-slate-400 text-sm mt-0.5">مساحة عملك — اسحب، غيّر الحجم، أضف وأخفِ ما تشاء</p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button className="btn-primary" onClick={() => setGalleryOpen(true)}>
            <Plus size={15} /> إضافة لوحة
          </button>
          <button className="btn-ghost" onClick={resetLayout} title="استعادة الترتيب الافتراضي">
            <RotateCcw size={14} />
          </button>
        </div>
      </div>

      {/* Layout tabs */}
      <div className="flex items-center gap-2 flex-wrap">
        <LayoutGrid size={14} className="text-slate-500" />
        {Object.entries(layouts).map(([id, l]) => (
          <div key={id} className="flex items-center">
            <button
              onClick={() => setActiveLayout(id)}
              className={activeLayout === id
                ? "px-3 py-1.5 rounded-lg text-xs font-bold text-blue-300"
                : "px-3 py-1.5 rounded-lg text-xs text-slate-400 hover:text-white"}
              style={activeLayout === id ? {background: "linear-gradient(135deg,rgba(59,130,246,.2),rgba(139,92,246,.12))", border: "1px solid rgba(59,130,246,.3)"} : {background: "var(--panel)"}}>
              {l.name}
            </button>
            {activeLayout === id && !DEFAULT_LAYOUTS[id] && (
              <button className="text-slate-600 hover:text-red-400 ms-1" onClick={() => deleteLayout(id)} title="حذف التخطيط">
                <Trash2 size={12} />
              </button>
            )}
          </div>
        ))}
        <button className="px-2.5 py-1.5 rounded-lg text-xs text-slate-500 hover:text-white" style={{background:"var(--panel)"}} onClick={() => setNewLayoutOpen(true)}>+ تخطيط جديد</button>
      </div>

      {/* Grid workspace — LTR container (grid math), widgets render RTL inside */}
      <div ref={containerRef} dir="ltr">
        {mounted && grid.length > 0 && (
          <GridLayout
            width={width}
            layout={renderGrid as any}
            gridConfig={isMobile
              ? { cols: 2, rowHeight: 120, margin: [10, 10] }
              : { cols: 12, rowHeight: 120, margin: [12, 12] }}
            dragConfig={{ enabled: !isMobile, handle: ".drag-handle" }}
            resizeConfig={{ enabled: !isMobile }}
            compactor={verticalCompactor}
            onLayoutChange={(l: any) => {
              if (isMobile) return; // mobile view is an auto-reflow, not a saved arrangement
              saveGrid(l.map((it: any) => ({ i: it.i, x: it.x, y: it.y, w: it.w, h: it.h, minW: it.minW, minH: it.minH })));
            }}
          >
            {renderGrid.map(item => {
              const def = WIDGET_MAP[item.i];
              if (!def) return <div key={item.i} style={{display:"none"}} />;
              const C = def.component;
              return (
                <div key={item.i} className="mc group" style={{overflow: "auto", display: "flex", flexDirection: "column"}} dir="rtl">
                  <div className="flex items-center justify-between" style={{marginBottom: 2}}>
                    {isMobile ? <span /> : (
                      <button className="drag-handle cursor-grab text-slate-600 hover:text-slate-300 opacity-0 group-hover:opacity-100 transition-opacity" title="اسحب لتحريك اللوحة">
                        <GripVertical size={13} />
                      </button>
                    )}
                    <button className={isMobile
                      ? "text-slate-600 active:text-red-400"
                      : "text-slate-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity"}
                      onClick={() => removeWidget(item.i)} title="إخفاء اللوحة">
                      <X size={13} />
                    </button>
                  </div>
                  <div className="flex-1 min-h-0"><C /></div>
                </div>
              );
            })}
          </GridLayout>
        )}
        {mounted && grid.length === 0 && (
          <div className="card text-center py-16" dir="rtl">
            <LayoutGrid size={32} className="mx-auto mb-3 text-slate-600" />
            <p className="text-slate-400 text-sm mb-4">هذا التخطيط فارغ — أضف لوحاتك المفضلة</p>
            <button className="btn-primary mx-auto" onClick={() => setGalleryOpen(true)}><Plus size={15} /> إضافة لوحة</button>
          </div>
        )}
      </div>

      {/* Widget Gallery */}
      {galleryOpen && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setGalleryOpen(false)}>
          <div className="modal-box fade-in" style={{maxWidth: 620}}>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-bold text-white">معرض اللوحات</h2>
              <button onClick={() => setGalleryOpen(false)} className="text-slate-500 hover:text-white"><X size={18} /></button>
            </div>
            <p className="text-xs text-slate-500 mb-4">اضغط لوحة لإضافتها إلى تخطيط «{layout?.name}»</p>
            {available.length === 0 ? (
              <p className="text-slate-400 text-sm text-center py-6">كل اللوحات مُضافة بالفعل ✓</p>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 gap-2.5 max-h-[50vh] overflow-auto">
                {available.map(w => (
                  <button key={w.id}
                    className="p-3 rounded-xl text-start transition-all hover:scale-[1.02]"
                    style={{background: "var(--panel)", border: "1px solid var(--line)"}}
                    onClick={() => { addWidget(w.id, w.defaultSize); }}>
                    <Plus size={14} className="text-blue-400 mb-1.5" />
                    <p className="text-white text-[13px] font-semibold">{w.title}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* New layout modal */}
      {newLayoutOpen && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setNewLayoutOpen(false)}>
          <div className="modal-box fade-in" style={{maxWidth: 400}}>
            <h2 className="text-lg font-bold text-white mb-4">تخطيط جديد</h2>
            <input className="input mb-4" placeholder="اسم التخطيط — مثال: المتابعة السريعة" value={newName}
              onChange={e => setNewName(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && newName.trim()) { addLayout(newName.trim()); setNewName(""); setNewLayoutOpen(false); setGalleryOpen(true); } }} />
            <div className="flex gap-2">
              <button className="btn-primary flex-1" disabled={!newName.trim()}
                onClick={() => { addLayout(newName.trim()); setNewName(""); setNewLayoutOpen(false); setGalleryOpen(true); }}>إنشاء</button>
              <button className="btn-ghost" onClick={() => setNewLayoutOpen(false)}>إلغاء</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
