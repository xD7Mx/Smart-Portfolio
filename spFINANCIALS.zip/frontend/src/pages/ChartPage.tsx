import React, { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { CandlestickChart, Search } from "lucide-react";
import NativeChart from "../components/analysis/NativeChart";
import TradingViewChart from "../components/analysis/TradingViewChart";
import CompanyLogo from "../components/common/CompanyLogo";
import { searchCompanies, SaudiCompany } from "../data/saudiCompanies";
import { companiesApi } from "../services/api";
import { useAppStore } from "../store/appStore";

export default function ChartPage() {
  const { theme } = useAppStore();
  const [q, setQ] = useState("");
  const [sug, setSug] = useState<SaudiCompany[]>([]);
  const [chosen, setChosen] = useState<string | null>(null);
  const [engine, setEngine] = useState<"native" | "tv">("native");

  // Quick picks come from the user's own portfolio — not random.
  const { data: companies = [] } = useQuery({
    queryKey: ["companies"],
    queryFn: () => companiesApi.list().then(r => (Array.isArray(r.data.data) ? r.data.data : [])),
  });
  const chips = useMemo(
    () => companies.map((c: any) => ({ symbol: c.symbol, name: c.name_ar || c.name || c.company_name, color: c.color, logo_url: c.logo_url })),
    [companies]
  );

  // default: first portfolio company; if none, nothing until the user searches
  const symbol = chosen ?? (chips[0]?.symbol ?? null);
  const pick = (s: string) => { setChosen(s.toUpperCase()); setQ(""); setSug([]); };

  return (
    <div className="space-y-4 fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-2">
            <CandlestickChart size={22} className="text-blue-400" /> الرسم البياني
          </h1>
          <p className="text-slate-400 text-sm mt-1">شارت شموع احترافي يعمل للأسهم السعودية والعالمية — اكتب أي سهم وفعّل مؤشراتك.</p>
        </div>
        <div className="relative w-full sm:w-80">
          <Search size={15} className="absolute end-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input className="input px-9" placeholder="ابحث عن سهم (بالرمز أو الاسم)..." value={q}
            onChange={e => { setQ(e.target.value); setSug(searchCompanies(e.target.value)); }}
            onKeyDown={e => { if (e.key === "Enter" && q) pick(q); }} />
          {sug.length > 0 && (
            <div className="absolute z-20 top-full mt-1 w-full rounded-xl overflow-hidden shadow-2xl"
              style={{ background: "var(--pop)", border: "1px solid var(--line)", maxHeight: 260, overflowY: "auto" }}>
              {sug.map(c => (
                <button key={c.symbol} type="button" onClick={() => pick(c.symbol)}
                  className="w-full text-start px-3 py-2.5 hover:bg-[#111c30] flex items-center gap-3 transition-colors">
                  <CompanyLogo symbol={c.symbol} size={26} />
                  <span className="tag-b shrink-0">{c.symbol}</span>
                  <span className="text-white text-sm font-semibold">{c.name_ar}</span>
                  <span className="text-slate-500 text-xs ms-auto">{c.name_en}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Portfolio quick picks — empty when the portfolio is empty */}
      {chips.length > 0 && (
        <div className="flex flex-wrap gap-2 items-center">
          <span className="text-xs text-slate-500">من محفظتك:</span>
          {chips.map((c: any) => (
            <button key={c.symbol} onClick={() => pick(c.symbol)}
              className={"px-3 py-1.5 rounded-xl text-xs font-bold border transition-all " +
                (symbol === c.symbol ? "bg-blue-600/20 text-blue-400 border-blue-500/40" : "border-[#1a2540] text-slate-400 hover:text-white")}>
              {c.name}
            </button>
          ))}
        </div>
      )}

      {symbol ? (
        <>
          {/* Engine switch: our native chart works for Saudi; TradingView for US/Pine */}
          <div className="flex gap-2">
            <button onClick={() => setEngine("native")}
              className={"px-3 py-1.5 rounded-xl text-xs font-bold border transition-all " + (engine === "native" ? "bg-blue-600/20 text-blue-400 border-blue-500/40" : "border-[#1a2540] text-slate-400 hover:text-white")}>
              شارت سهمك (يعمل للسعودي)
            </button>
            <button onClick={() => setEngine("tv")}
              className={"px-3 py-1.5 rounded-xl text-xs font-bold border transition-all " + (engine === "tv" ? "bg-blue-600/20 text-blue-400 border-blue-500/40" : "border-[#1a2540] text-slate-400 hover:text-white")}>
              TradingView (أمريكي/باين سكريبت)
            </button>
          </div>

          {engine === "native" ? (
            <div className="card">
              <NativeChart symbol={symbol} theme={theme === "light" ? "light" : "dark"} />
              <p className="text-[11px] text-slate-500 mt-2">
                شارت شموع حقيقي ببياناتنا — يعمل للأسهم السعودية ومؤشر تاسي. فعّل/أطفئ المؤشرات (SMA، RSI) من الأعلى وغيّر الفريم.
              </p>
            </div>
          ) : (
            <>
              <div className="card p-0 overflow-hidden" style={{ height: "72vh", minHeight: 480 }}>
                <TradingViewChart symbol={symbol} theme={theme === "light" ? "light" : "dark"} />
              </div>
              <p className="text-[11px] text-slate-500">
                TradingView يعمل بسلاسة للأسهم الأمريكية والعالمية ويدعم مؤشرات باين سكريبت المنشورة. بيانات السوق السعودي غير متوفرة في نسخته المجانية — استخدم «شارت سهمك» للسعودي.
              </p>
            </>
          )}
        </>
      ) : (
        <div className="card">
          <div className="py-16 text-center text-slate-500">
            <CandlestickChart size={40} className="mx-auto mb-3 opacity-30" />
            <p className="text-sm">ابحث عن سهم من مربع البحث بالأعلى لعرض شارته.</p>
            <p className="text-xs mt-1 text-slate-600">أضِف شركات إلى محفظتك لتظهر هنا كأزرار سريعة.</p>
          </div>
        </div>
      )}
    </div>
  );
}
