import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface GridItem { i: string; x: number; y: number; w: number; h: number; minW?: number; minH?: number }
export interface DashLayout { name: string; grid: GridItem[] }

/* ── Default workspace layouts (user can edit/add/reset) ────── */
const DEFAULT_GRID: GridItem[] = [
  { i: "wealth",       x: 0, y: 0, w: 12, h: 2, minW: 6, minH: 2 },
  { i: "marketValue",  x: 0, y: 2, w: 2,  h: 1 },
  { i: "invested",     x: 2, y: 2, w: 2,  h: 1 },
  { i: "unrealized",   x: 4, y: 2, w: 2,  h: 1 },
  { i: "dividends",    x: 6, y: 2, w: 2,  h: 1 },
  { i: "liquidity",    x: 8, y: 2, w: 2,  h: 1 },
  { i: "companies",    x: 10, y: 2, w: 2, h: 1 },
  { i: "perf",         x: 0, y: 3, w: 6,  h: 3, minW: 4, minH: 3 },
  { i: "sectors",      x: 6, y: 3, w: 6,  h: 3, minW: 4, minH: 3 },
  { i: "goals",        x: 0, y: 6, w: 6,  h: 3, minW: 3, minH: 2 },
  { i: "summary",      x: 6, y: 6, w: 6,  h: 3, minW: 3, minH: 2 },
];

const DAILY_GRID: GridItem[] = [
  { i: "tasi",  x: 0, y: 0, w: 4, h: 1 },
  { i: "brent", x: 4, y: 0, w: 4, h: 1 },
  { i: "gold",  x: 8, y: 0, w: 4, h: 1 },
  { i: "unrealized", x: 0, y: 1, w: 3, h: 1 },
  { i: "liquidity",  x: 3, y: 1, w: 3, h: 1 },
  { i: "topGainer",  x: 6, y: 1, w: 3, h: 1 },
  { i: "topLoser",   x: 9, y: 1, w: 3, h: 1 },
  { i: "news",       x: 0, y: 2, w: 7, h: 4, minW: 4, minH: 3 },
  { i: "calendar",   x: 7, y: 2, w: 5, h: 4, minW: 3, minH: 3 },
  { i: "notifs",     x: 0, y: 6, w: 12, h: 3, minW: 4, minH: 2 },
];

const ANALYSIS_GRID: GridItem[] = [
  { i: "perf",      x: 0, y: 0, w: 7, h: 4, minW: 4, minH: 3 },
  { i: "sectors",   x: 7, y: 0, w: 5, h: 4, minW: 4, minH: 3 },
  { i: "aiSummary", x: 0, y: 4, w: 7, h: 2, minW: 4, minH: 2 },
  { i: "topGainer", x: 7, y: 4, w: 5, h: 1 },
  { i: "topLoser",  x: 7, y: 5, w: 5, h: 1 },
  { i: "summary",   x: 0, y: 6, w: 12, h: 3, minW: 4, minH: 2 },
];

const REVIEW_GRID: GridItem[] = [
  { i: "wealth",    x: 0, y: 0, w: 12, h: 2, minW: 6, minH: 2 },
  { i: "perf",      x: 0, y: 2, w: 6, h: 4, minW: 4, minH: 3 },
  { i: "summary",   x: 6, y: 2, w: 6, h: 4, minW: 3, minH: 2 },
  { i: "goals",     x: 0, y: 6, w: 6, h: 3, minW: 3, minH: 2 },
  { i: "dividends", x: 6, y: 6, w: 3, h: 1 },
  { i: "invested",  x: 9, y: 6, w: 3, h: 1 },
];

export const DEFAULT_LAYOUTS: Record<string, DashLayout> = {
  default:  { name: "الرئيسي",          grid: DEFAULT_GRID },
  daily:    { name: "اليومي",           grid: DAILY_GRID },
  analysis: { name: "التحليل",          grid: ANALYSIS_GRID },
  review:   { name: "المراجعة الشهرية", grid: REVIEW_GRID },
};

export interface CustomColors { bg: string; text: string }

export function applyTheme(t: string, colors?: CustomColors) {
  const el = document.documentElement;
  el.classList.toggle("dark", t === "dark");
  el.classList.toggle("light", t === "light");
  el.classList.toggle("custom", t === "custom");
  if (t === "custom" && colors) {
    el.style.setProperty("--sp-bg", colors.bg);
    el.style.setProperty("--sp-text", colors.text);
  } else {
    el.style.removeProperty("--sp-bg");
    el.style.removeProperty("--sp-text");
  }
}

interface AppState {
  theme: "light" | "dark" | "custom";
  customColors: CustomColors;
  setCustomColors: (c: Partial<CustomColors>) => void;
  sidebarOpen: boolean;
  currency: string;
  portfolioMode: "BUILD" | "MANAGEMENT";
  language: "ar" | "en";
  tickers: { tasi: boolean; brent: boolean; gold: boolean };

  /* Workspace */
  activeLayout: string;
  layouts: Record<string, DashLayout>;

  /* Point 10 — customization everywhere */
  pageOrder: string[];
  hiddenPages: string[];
  startPage: string;
  portfolioCols: Record<string, boolean>;
  movePage: (id: string, dir: -1 | 1) => void;
  togglePage: (id: string) => void;
  setStartPage: (id: string) => void;
  togglePortfolioCol: (id: string) => void;

  setTheme: (t: "light" | "dark" | "custom") => void;
  setTicker: (k: "tasi" | "brent" | "gold", v: boolean) => void;
  toggleTheme: () => void;
  setSidebarOpen: (v: boolean) => void;
  setCurrency: (c: string) => void;
  setPortfolioMode: (m: "BUILD" | "MANAGEMENT") => void;
  setLanguage: (l: "ar" | "en") => void;

  setActiveLayout: (id: string) => void;
  saveGrid: (grid: GridItem[]) => void;
  addWidget: (widgetId: string, size: { w: number; h: number; minW?: number; minH?: number }) => void;
  removeWidget: (widgetId: string) => void;
  addLayout: (name: string) => void;
  renameLayout: (id: string, name: string) => void;
  deleteLayout: (id: string) => void;
  resetLayout: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      theme: "dark",
      customColors: { bg: "#0b1222", text: "#e2e8f0" },
      setCustomColors: (c) => {
        set((s) => ({ customColors: { ...s.customColors, ...c } }));
        const st = get();
        if (st.theme === "custom") applyTheme("custom", st.customColors);
      },
      sidebarOpen: true,
      currency: "SAR",
      portfolioMode: "BUILD",
      language: "ar",
      tickers: { tasi: true, brent: true, gold: true },

      activeLayout: "default",
      layouts: DEFAULT_LAYOUTS,

      pageOrder: ["dashboard", "portfolio", "market", "chart", "governance", "ai", "calculators", "reports", "notifications", "settings"],
      hiddenPages: [],
      startPage: "dashboard",
      portfolioCols: { sector: true, shares: true, avgCost: true, lastPrice: true, marketValue: true, weight: true, pnl: true, dividends: false, actions: true },
      movePage: (id, dir) => set((s) => {
        const order = [...s.pageOrder];
        const i = order.indexOf(id);
        const j = i + dir;
        if (i < 0 || j < 0 || j >= order.length) return {};
        [order[i], order[j]] = [order[j], order[i]];
        return { pageOrder: order };
      }),
      togglePage: (id) => set((s) => {
        if (id === "settings") return {}; // never hide settings
        const hidden = s.hiddenPages.includes(id)
          ? s.hiddenPages.filter(p => p !== id)
          : [...s.hiddenPages, id];
        const startPage = hidden.includes(s.startPage) ? "dashboard" : s.startPage;
        return { hiddenPages: hidden, startPage };
      }),
      setStartPage: (id) => set({ startPage: id }),
      togglePortfolioCol: (id) => set((s) => ({
        portfolioCols: { ...s.portfolioCols, [id]: !s.portfolioCols[id] },
      })),

      setTicker: (k, v) => set((s) => ({ tickers: { ...s.tickers, [k]: v } })),
      setTheme: (t) => {
        set({ theme: t });
        applyTheme(t, get().customColors);
      },
      toggleTheme: () => {
        const next = get().theme === "dark" ? "light" : "dark";
        get().setTheme(next);
      },
      setSidebarOpen: (v) => set({ sidebarOpen: v }),
      setCurrency: (c) => set({ currency: c }),
      setPortfolioMode: (m) => set({ portfolioMode: m }),
      setLanguage: (l) => {
        set({ language: l });
        document.documentElement.dir = l === "ar" ? "rtl" : "ltr";
        document.documentElement.lang = l;
      },

      setActiveLayout: (id) => set({ activeLayout: id }),
      saveGrid: (grid) => set((s) => ({
        layouts: { ...s.layouts, [s.activeLayout]: { ...s.layouts[s.activeLayout], grid } },
      })),
      addWidget: (widgetId, size) => set((s) => {
        const cur = s.layouts[s.activeLayout];
        if (!cur || cur.grid.some(g => g.i === widgetId)) return {};
        const maxY = cur.grid.reduce((m, g) => Math.max(m, g.y + g.h), 0);
        const item: GridItem = { i: widgetId, x: 0, y: maxY, ...size };
        return { layouts: { ...s.layouts, [s.activeLayout]: { ...cur, grid: [...cur.grid, item] } } };
      }),
      removeWidget: (widgetId) => set((s) => {
        const cur = s.layouts[s.activeLayout];
        return { layouts: { ...s.layouts, [s.activeLayout]: { ...cur, grid: cur.grid.filter(g => g.i !== widgetId) } } };
      }),
      addLayout: (name) => set((s) => {
        const id = "custom_" + Date.now();
        return {
          layouts: { ...s.layouts, [id]: { name, grid: [] } },
          activeLayout: id,
        };
      }),
      renameLayout: (id, name) => set((s) => ({
        layouts: { ...s.layouts, [id]: { ...s.layouts[id], name } },
      })),
      deleteLayout: (id) => set((s) => {
        if (Object.keys(s.layouts).length <= 1) return {};
        const rest = { ...s.layouts };
        delete rest[id];
        return { layouts: rest, activeLayout: s.activeLayout === id ? Object.keys(rest)[0] : s.activeLayout };
      }),
      resetLayout: () => set((s) => {
        const def = DEFAULT_LAYOUTS[s.activeLayout];
        if (def) {
          return { layouts: { ...s.layouts, [s.activeLayout]: { ...def, grid: [...def.grid] } } };
        }
        return { layouts: { ...s.layouts, [s.activeLayout]: { ...s.layouts[s.activeLayout], grid: [] } } };
      }),
    }),
    {
      name: "sp-app-store",
      version: 7,
      migrate: (persisted: any) => {
        let order: string[] = persisted?.pageOrder ?? [];
        if (!order.includes("calculators")) {
          order = [...order.filter((p: string) => p !== "reports"), "calculators", "reports"];
        }
        if (!order.includes("chart")) {
          const i = order.indexOf("market");
          if (i >= 0) order = [...order.slice(0, i + 1), "chart", ...order.slice(i + 1)];
          else order = [...order, "chart"];
        }
        order = order.filter((v: string, i: number, a: string[]) => a.indexOf(v) === i);

        // Portfolio evaluation now lives in the AI page, not the dashboard grid —
        // strip any leftover "portfolioHealth" grid entry from saved layouts.
        const layouts = { ...(persisted?.layouts ?? {}) };
        for (const key of Object.keys(layouts)) {
          const grid: GridItem[] = layouts[key]?.grid ?? [];
          if (grid.some((g) => g.i === "portfolioHealth")) {
            layouts[key] = { ...layouts[key], grid: grid.filter((g) => g.i !== "portfolioHealth") };
          }
        }

        return {
          ...persisted,
          customColors: persisted?.customColors ?? { bg: "#0b1222", text: "#e2e8f0" },
          pageOrder: order,
          layouts: Object.keys(layouts).length ? layouts : persisted?.layouts,
          portfolioCols: {
            sector: true, shares: true, avgCost: true, lastPrice: true,
            marketValue: true, weight: true, pnl: true, dividends: false, actions: true,
            ...(persisted?.portfolioCols ?? {}),
          },
        };
      },
    }
  )
);
