import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useAppStore, applyTheme } from "./store/appStore";

// Layout
import MainLayout from "./components/common/MainLayout";

// Pages
import DashboardPage   from "./pages/DashboardPage";
import PortfolioPage   from "./pages/PortfolioPage";
import CompanyPage     from "./pages/CompanyPage";
import MarketPage      from "./pages/MarketPage";
import ReportsPage     from "./pages/ReportsPage";
import NotificationsPage from "./pages/NotificationsPage";
import SettingsPage    from "./pages/SettingsPage";
import AIPage          from "./pages/AIPage";
import GovernancePage  from "./pages/GovernancePage";
import CalculatorsPage from "./pages/CalculatorsPage";
import ChartPage       from "./pages/ChartPage";

// Styles
import "./styles/globals.css";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      staleTime: 30000,
      refetchOnWindowFocus: false,
    },
  },
});

function StartRedirect() {
  const { startPage } = useAppStore();
  return <Navigate to={"/" + (startPage || "dashboard")} replace />;
}

function App() {
  const { theme, language, customColors } = useAppStore();

  useEffect(() => {
    applyTheme(theme, customColors);
  }, [theme, customColors]);

  useEffect(() => {
    document.documentElement.dir = language === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = language;
  }, [language]);

  return (
    <QueryClientProvider client={queryClient}>
      <BrowserRouter>
        <Routes>
          <Route element={<MainLayout />}>
            <Route index element={<StartRedirect />} />
            <Route path="/dashboard"      element={<DashboardPage />} />
            <Route path="/portfolio"      element={<PortfolioPage />} />
            <Route path="/portfolio/:id"  element={<CompanyPage />} />
            <Route path="/market"         element={<MarketPage />} />
            <Route path="/chart"          element={<ChartPage />} />
            <Route path="/governance"      element={<GovernancePage />} />
            <Route path="/ai"             element={<AIPage />} />
            <Route path="/calculators"    element={<CalculatorsPage />} />
            <Route path="/reports"        element={<ReportsPage />} />
            <Route path="/notifications"  element={<NotificationsPage />} />
            <Route path="/settings"       element={<SettingsPage />} />
          </Route>
        </Routes>
      </BrowserRouter>
    </QueryClientProvider>
  );
}

export default App;
