import axios from "axios";
import type { APIResponse } from "../types";

const BASE_URL = import.meta.env.VITE_API_URL || "/api/v1";

const api = axios.create({
  baseURL: BASE_URL,
  headers: { "Content-Type": "application/json" },
  timeout: 30000,
});

// ── Interceptors ─────────────────────────────────────────────
api.interceptors.response.use(
  (res) => res,
  (err) => {
    console.error("API Error:", err?.response?.data?.message || err.message);
    return Promise.reject(err);
  }
);

// ── Portfolio ─────────────────────────────────────────────────
export const portfolioApi = {
  get:        () => api.get<APIResponse>("/holdings"),
  summary:    () => api.get<APIResponse>("/portfolio/summary"),
  health:     () => api.get<APIResponse>("/portfolio/health"),
  roi:        () => api.get<APIResponse>("/portfolio/roi"),
  income:     () => api.get<APIResponse>("/portfolio/income"),
  statistics: () => api.get<APIResponse>("/portfolio/statistics"),
  metrics:    () => api.get<APIResponse>("/portfolio/metrics"),
  history:    (days = 365) => api.get<APIResponse>(`/portfolio/history?days=${days}`),
  snapshot:   () => api.post<APIResponse>("/portfolio/snapshot"),
};

// ── Companies ─────────────────────────────────────────────────
export const companiesApi = {
  list:   ()          => api.get<APIResponse>("/companies"),
  get:    (id: number) => api.get<APIResponse>(`/companies/${id}`),
  add:    (data: any) => api.post<APIResponse>("/companies", data),
  update: (id: number, data: any) => api.put<APIResponse>(`/companies/${id}`, data),
  remove: (id: number) => api.delete<APIResponse>(`/companies/${id}`),
  syncSharia: () => api.post<APIResponse>("/companies/sync-sharia"),
  resolveSharia: (id: number) => api.post<APIResponse>(`/companies/${id}/resolve-sharia`),
  directory: () => api.get<APIResponse>("/companies/directory"),
};

// ── Holdings ──────────────────────────────────────────────────
export const holdingsApi = {
  list: () => api.get<APIResponse>("/holdings"),
  get:  (companyId: number) => api.get<APIResponse>(`/holdings/${companyId}`),
  update: (companyId: number, data: { quantity?: number; average_cost?: number }) =>
    api.patch<APIResponse>(`/holdings/${companyId}`, data),
};

// ── Transactions ──────────────────────────────────────────────
export const transactionsApi = {
  list: () => api.get<APIResponse>("/transactions"),
  add:  (data: any) => api.post<APIResponse>("/transactions", data),
  get:  (id: number) => api.get<APIResponse>(`/transactions/${id}`),
};

// ── Installments ──────────────────────────────────────────────
export const installmentsApi = {
  list:    ()                          => api.get<APIResponse>("/installments"),
  add:     (data: any)                 => api.post<APIResponse>("/installments", data),
  update:  (id: number, status: string) => api.patch<APIResponse>(`/installments/${id}?status=${status}`),
  nearest: ()                          => api.get<APIResponse>("/installments/nearest"),
};

// ── Cash ──────────────────────────────────────────────────────
export const cashApi = {
  get:     () => api.get<APIResponse>("/cash"),
  balance: () => api.get<APIResponse>("/cash"),
  history: (limit = 30) => api.get<APIResponse>(`/cash/history?limit=${limit}`),
  deposit: (data: any) => api.post<APIResponse>("/cash/deposit", data),
  withdraw:(data: any) => api.post<APIResponse>("/cash/withdraw", data),
};

// ── Dividends ─────────────────────────────────────────────────
export const dividendsApi = {
  list:   () => api.get<APIResponse>("/dividends"),
  add:    (data: any) => api.post<APIResponse>("/dividends", data),
  update: (id: number, data: { dividend_per_share?: number; shares_at_time?: number; payment_date?: string }) =>
    api.patch<APIResponse>(`/dividends/${id}`, data),
  remove: (id: number) => api.delete<APIResponse>(`/dividends/${id}`),
};

// ── Bonus Shares ──────────────────────────────────────────────
export const bonusApi = {
  list: () => api.get<APIResponse>("/bonus"),
  add:  (data: any) => api.post<APIResponse>("/bonus", data),
};

// ── Goals ─────────────────────────────────────────────────────
export const goalsApi = {
  list:     () => api.get<APIResponse>("/goals"),
  add:      (data: any) => api.post<APIResponse>("/goals", data),
  update:   (id: number, currentValue: number) => api.patch<APIResponse>(`/goals/${id}?current_value=${currentValue}`),
  progress: () => api.get<APIResponse>("/goals/progress"),
};

// ── Market ────────────────────────────────────────────────────
export const marketApi = {
  overview: () => api.get<APIResponse>("/market/overview"),
  news:     () => api.get<APIResponse>("/market/news"),
  summary:  () => api.get<APIResponse>("/market/summary"),
  economicNews: () => api.get<APIResponse>("/market/economic-news"),
  feedstock: () => api.get<APIResponse>("/market/feedstock"),
  events:   () => api.get<APIResponse>("/market/events"),
  results:  () => api.get<APIResponse>("/market/results"),
  company:  (symbol: string) => api.get<APIResponse>(`/market/company/${symbol}`),
  history:  (symbol: string, range = "3mo") => api.get<APIResponse>(`/market/history/${symbol}?range=${range}`),
  financials: (symbol: string) => api.get<APIResponse>(`/market/financials/${symbol}`),
  ownership:  (symbol: string) => api.get<APIResponse>(`/market/ownership/${symbol}`),
  dividends:  (symbol: string) => api.get<APIResponse>(`/market/dividends/${symbol}`),
};

// ── AI ────────────────────────────────────────────────────────
export const aiApi = {
  status:      () => api.get<APIResponse>("/ai/status"),
  run:         () => api.post<APIResponse>("/ai/run"),
  report:      () => api.get<APIResponse>("/ai/report"),
  evaluation:  () => api.get<APIResponse>("/ai/evaluation"),
  opportunities:() => api.get<APIResponse>("/ai/opportunities"),
  risk:        () => api.get<APIResponse>("/ai/risk"),
  fullReport:  () => api.get<APIResponse>("/ai/full-report"),
  portfolioInsight: () => api.get<APIResponse>("/ai/portfolio-insight"),
};

// ── Notifications ─────────────────────────────────────────────
export const notificationsApi = {
  list:   () => api.get<APIResponse>("/notifications"),
  read:   (id: number) => api.patch<APIResponse>(`/notifications/${id}/read`),
  delete: (id: number) => api.delete<APIResponse>(`/notifications/${id}`),
};

// ── Reports ───────────────────────────────────────────────────
export const reportsApi = {
  list:     () => api.get<APIResponse>("/reports"),
  generate: (type: string) => api.post<APIResponse>(`/reports/generate?report_type=${type}`),
  get:      (id: number) => api.get<APIResponse>(`/reports/${id}`),
  remove:   (id: number) => api.delete<APIResponse>(`/reports/${id}`),
};

// ── Settings ──────────────────────────────────────────────────
export const settingsApi = {
  get:       () => api.get<APIResponse>("/settings"),
  ai:        () => api.get<APIResponse>("/settings/ai"),
  telegram:  () => api.get<APIResponse>("/settings/telegram"),
  providers: () => api.get<APIResponse>("/settings/providers"),
  system:    () => api.get<APIResponse>("/settings/system"),
  integrations: (refresh = false) => api.get<APIResponse>("/settings/integrations" + (refresh ? "?refresh=true" : "")),
};

// ── Health ────────────────────────────────────────────────────
export const healthApi = {
  check: () => api.get<APIResponse>("/health"),
};

export default api;

// ── Notes (Market / Portfolio notebooks) ─────────────────────
export const notesApi = {
  list:   (scope?: string) => api.get<APIResponse>("/notes" + (scope ? `?scope=${scope}` : "")),
  add:    (data: { scope: string; content: string; company_id?: number }) => api.post<APIResponse>("/notes", data),
  remove: (id: number) => api.delete<APIResponse>(`/notes/${id}`),
};

// ── Allocation / Rebalance ───────────────────────────────────
export const allocationApi = {
  get:        () => api.get<APIResponse>("/allocation"),
  setTargets: (items: { company_id: number; target_weight: number }[]) => api.put<APIResponse>("/allocation/targets", { items }),
  rebalance:  () => api.get<APIResponse>("/allocation/rebalance"),
};
