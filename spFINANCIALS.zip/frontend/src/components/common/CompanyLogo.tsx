import React, { useState } from "react";

/**
 * Company logo with graceful fallback chain:
 *  1. logoUrl — verified official logo (Sahmak's reported company website,
 *     resolved through Clearbit; persisted on the company row).
 *  2. Parqet's public logo CDN, best-effort guess by Tadawul symbol.
 *  3. A branded gradient monogram — never a broken image.
 */
export default function CompanyLogo({ symbol, color, size = 40, logoUrl }: { symbol: string; color?: string; size?: number; logoUrl?: string | null }) {
  const [stage, setStage] = useState<0 | 1 | 2>(logoUrl ? 0 : 1);
  const base = (symbol || "").replace(".SR", "").trim();
  const url = stage === 0 ? logoUrl! : `https://assets.parqet.com/logos/symbol/${base}.SR?format=png&size=${size * 2}`;

  if (stage < 2 && base) {
    return (
      <img
        src={url}
        alt={base}
        width={size}
        height={size}
        onError={() => setStage(s => (s === 0 ? 1 : 2))}
        className="rounded-xl object-contain bg-white/90 p-0.5 shrink-0"
        style={{ width: size, height: size }}
        loading="lazy"
      />
    );
  }
  return (
    <div
      className="rounded-xl flex items-center justify-center text-white font-bold shrink-0"
      style={{
        width: size, height: size,
        fontSize: size * 0.3,
        background: `linear-gradient(135deg, ${color || "#2563eb"}, #6d28d9)`,
      }}
    >
      {base.slice(0, 4)}
    </div>
  );
}
