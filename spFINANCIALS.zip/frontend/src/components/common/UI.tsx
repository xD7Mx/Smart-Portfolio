import React from "react";
import clsx from "clsx";
import { TrendingUp, TrendingDown, Minus, MoonStar, Circle } from "lucide-react";

// ── Sharia badge — green (pure) / orange (mixed) / red (non-compliant) crescent ──
export function ShariaBadge({ status, size = 13 }: { status?: string | null; size?: number }) {
  if (status === "COMPLIANT") {
    return <span className="shrink-0 inline-flex" title="نقية — متوافقة شرعياً"><MoonStar size={size} className="text-emerald-400" /></span>;
  }
  if (status === "MIXED") {
    return <span className="shrink-0 inline-flex" title="مختلطة — متوافقة بشرط التطهير"><MoonStar size={size} className="text-amber-500" /></span>;
  }
  if (status === "NON_COMPLIANT") {
    return <span className="shrink-0 inline-flex" title="غير متوافقة شرعياً"><MoonStar size={size} className="text-rose-500" /></span>;
  }
  return null;
}

// ── Sharia indicator — green (نقية) / orange (مختلطة) / red (non) / gray (unknown) ──
export function ShariaStatusIndicator({ status, loading, purification, source }:
  { status?: string | null; loading?: boolean; purification?: number | null; source?: string | null }) {
  const map: Record<string, { icon: any; color: string; bg: string; label: string }> = {
    COMPLIANT:     { icon: MoonStar, color: "#10b981", bg: "rgba(16,185,129,.12)", label: "متوافق شرعياً (نقي)" },
    MIXED:         { icon: MoonStar, color: "#f59e0b", bg: "rgba(245,158,11,.12)",  label: "مختلط — متوافق بشرط التطهير" },
    NON_COMPLIANT: { icon: MoonStar, color: "#f43f5e", bg: "rgba(244,63,94,.12)",  label: "غير متوافق شرعياً" },
  };
  const s = status && map[status] ? map[status]
    : { icon: Circle, color: "#94a3b8", bg: "rgba(148,163,184,.12)", label: loading ? "جارٍ التحقق…" : "التوافق الشرعي غير محدد" };
  const Icon = s.icon;
  const showPurif = (status === "COMPLIANT" || status === "MIXED") && purification != null;
  return (
    <div className="flex items-center gap-2.5 rounded-xl px-3 py-2 flex-wrap" style={{ background: s.bg }}>
      <Icon size={18} style={{ color: s.color }} className={loading ? "animate-pulse" : ""} />
      <span className="text-sm font-bold" style={{ color: s.color }}>{s.label}</span>
      {showPurif && (
        <span className="text-xs font-semibold px-2 py-0.5 rounded-lg mr-1" style={{ color: s.color, background: "rgba(255,255,255,.06)" }}>
          تطهير {purification!.toFixed(2)} ريال/سهم
        </span>
      )}
      {source && <span className="text-[11px] text-slate-500 ms-auto">المصدر: {source}</span>}
    </div>
  );
}

// ── Card ────────────────────────────────────────────────────
interface CardProps {
  children: React.ReactNode;
  className?: string;
  title?: string;
  action?: React.ReactNode;
}

export function Card({ children, className, title, action }: CardProps) {
  return (
    <div className={clsx("card fade-in", className)}>
      {(title || action) && (
        <div className="flex items-center justify-between mb-4">
          {title && <h3 className="font-semibold text-sm text-slate-400 uppercase tracking-wider">{title}</h3>}
          {action}
        </div>
      )}
      {children}
    </div>
  );
}

// ── MetricCard ───────────────────────────────────────────────
interface MetricCardProps {
  label: string;
  value: string | number;
  sub?: string;
  change?: number;
  icon?: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

export function MetricCard({ label, value, sub, change, icon, className, onClick }: MetricCardProps) {
  const isPositive = change !== undefined && change > 0;
  const isNegative = change !== undefined && change < 0;

  return (
    <div
      className={clsx("card cursor-pointer hover:border-blue-500 transition-colors", className)}
      onClick={onClick}
    >
      <div className="flex items-start justify-between">
        <div className="flex-1 min-w-0">
          <p className="text-xs font-medium text-slate-400 uppercase tracking-wider mb-1">{label}</p>
          <p className="text-2xl font-bold truncate">{value}</p>
          {sub && <p className="text-xs text-slate-400 mt-1">{sub}</p>}
        </div>
        {icon && (
          <div className="ml-3 p-2 rounded-lg bg-blue-600/10 text-blue-500 shrink-0">
            {icon}
          </div>
        )}
      </div>

      {change !== undefined && (
        <div className={clsx(
          "flex items-center gap-1 mt-3 text-sm font-medium",
          isPositive ? "text-green-500" : isNegative ? "text-red-500" : "text-slate-400"
        )}>
          {isPositive ? <TrendingUp size={14} /> : isNegative ? <TrendingDown size={14} /> : <Minus size={14} />}
          <span>{change > 0 ? "+" : ""}{change.toFixed(2)}%</span>
        </div>
      )}
    </div>
  );
}

// ── Badge ────────────────────────────────────────────────────
type BadgeVariant = "default" | "success" | "danger" | "warning" | "info" | "neutral";

const BADGE_STYLES: Record<BadgeVariant, string> = {
  default: "bg-slate-700 text-slate-300",
  success: "bg-green-900/40 text-green-400",
  danger:  "bg-red-900/40 text-red-400",
  warning: "bg-amber-900/40 text-amber-400",
  info:    "bg-blue-900/40 text-blue-400",
  neutral: "bg-slate-800 text-slate-400",
};

export function Badge({ label, variant = "default" }: { label: string; variant?: BadgeVariant }) {
  return (
    <span className={clsx("inline-flex items-center px-2 py-0.5 rounded text-xs font-medium", BADGE_STYLES[variant])}>
      {label}
    </span>
  );
}

// ── SkeletonCard ─────────────────────────────────────────────
export function SkeletonCard({ lines = 3 }: { lines?: number }) {
  return (
    <div className="card space-y-3">
      <div className="skeleton h-4 w-24" />
      <div className="skeleton h-8 w-32" />
      {Array.from({ length: lines - 2 }).map((_, i) => (
        <div key={i} className="skeleton h-3 w-full" />
      ))}
    </div>
  );
}

// ── EmptyState ───────────────────────────────────────────────
export function EmptyState({ icon, title, description, action }: {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
}) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      {icon && <div className="mb-4 text-slate-500">{icon}</div>}
      <h3 className="text-base font-semibold text-slate-300 mb-1">{title}</h3>
      {description && <p className="text-sm text-slate-500 mb-4 max-w-xs">{description}</p>}
      {action}
    </div>
  );
}

// ── Button ───────────────────────────────────────────────────
type ButtonVariant = "primary" | "secondary" | "danger" | "ghost";

const BTN_STYLES: Record<ButtonVariant, string> = {
  primary:   "bg-blue-600 hover:bg-blue-700 text-white",
  secondary: "bg-slate-700 hover:bg-slate-600 text-slate-200",
  danger:    "bg-red-600 hover:bg-red-700 text-white",
  ghost:     "text-slate-400 hover:text-slate-200 hover:bg-slate-700",
};

export function Button({ children, variant = "primary", className, size = "md", ...props }: {
  children: React.ReactNode;
  variant?: ButtonVariant;
  className?: string;
  size?: "sm" | "md" | "lg";
  [key: string]: any;
}) {
  const sizes = { sm: "px-3 py-1.5 text-xs", md: "px-4 py-2 text-sm", lg: "px-6 py-2.5 text-base" };
  return (
    <button
      className={clsx(
        "inline-flex items-center gap-2 rounded-lg font-medium transition-colors disabled:opacity-50",
        BTN_STYLES[variant],
        sizes[size],
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}

// ── Progress Bar ─────────────────────────────────────────────
export function ProgressBar({ value, max = 100, color = "blue", label }: {
  value: number;
  max?: number;
  color?: "blue" | "green" | "amber" | "red";
  label?: string;
}) {
  const pct = Math.min((value / max) * 100, 100);
  const colors = { blue: "bg-blue-500", green: "bg-green-500", amber: "bg-amber-500", red: "bg-red-500" };

  return (
    <div>
      {label && (
        <div className="flex justify-between text-xs text-slate-400 mb-1">
          <span>{label}</span>
          <span>{pct.toFixed(1)}%</span>
        </div>
      )}
      <div className="h-2 rounded-full bg-slate-700 overflow-hidden">
        <div
          className={clsx("h-full rounded-full transition-all duration-500", colors[color])}
          style={{ width: `${pct}%` }}
        />
      </div>
    </div>
  );
}
