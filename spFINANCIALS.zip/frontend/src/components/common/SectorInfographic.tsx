import React from "react";

/**
 * Sector-distribution infographic — shared identically by the Dashboard
 * widget and the Portfolio page. Donut on the right (fixed 130-160px, thick
 * ring) holding the sector count; a percentage/progress/name row (or a
 * scrollable list of them) filling the rest on the left. The card's own
 * height is set by its container and never changes with sector count —
 * the row list scrolls internally instead of growing the card.
 */
export const SECTOR_COLORS = ["#3b82f6", "#8b5cf6", "#10b981", "#06b6d4", "#f59e0b", "#f43f5e", "#6366f1", "#14b8a6"];

export interface SectorSlice { name: string; value: number; pct: number }

export function buildSectorData(rows: { sector?: string | null; value: number }[]): SectorSlice[] {
  const map: Record<string, number> = {};
  rows.forEach(({ sector, value }) => {
    const s = sector || "غير مصنف";
    map[s] = (map[s] || 0) + (value || 0);
  });
  const total = Object.values(map).reduce((a, b) => a + b, 0);
  return Object.entries(map)
    .filter(([, v]) => v > 0)
    .map(([name, value]) => ({ name, value, pct: total ? (value / total) * 100 : 0 }))
    .sort((a, b) => b.value - a.value);
}

function Row({ d, color }: { d: SectorSlice; color: string }) {
  return (
    <div className="flex items-center" style={{ gap: 12, height: 28, flexShrink: 0 }}>
      {/* Name + dot — first DOM child renders on the right under RTL */}
      <span className="flex items-center shrink-0 max-w-[38%]" style={{ gap: 8 }}>
        <span className="rounded-full shrink-0" style={{ width: 8, height: 8, background: color }} />
        <span className="text-sm text-slate-300 truncate">{d.name}</span>
      </span>
      {/* Bar — spans all remaining space, edge to edge between the name and the percentage */}
      <div className="flex-1 min-w-0 rounded-full overflow-hidden" style={{ height: 8, background: "rgba(148,163,184,.15)" }}>
        <div className="h-full rounded-full" style={{ width: `${d.pct}%`, background: color }} />
      </div>
      {/* Percentage — last DOM child renders on the far left under RTL */}
      <span className="text-sm font-bold text-white shrink-0 text-end" style={{ width: 50 }}>{d.pct.toFixed(1)}%</span>
    </div>
  );
}

export default function SectorInfographic({ data, size = 140 }: { data: SectorSlice[]; size?: number }) {
  if (!data.length) return null;

  let acc = 0;
  const stops = data.map((d, i) => {
    const from = acc; acc += d.pct;
    return `${SECTOR_COLORS[i % SECTOR_COLORS.length]} ${from}% ${acc}%`;
  }).join(", ");

  const donutSize = Math.max(130, Math.min(160, size));
  const ringThickness = Math.round(donutSize * 0.27);

  return (
    <div className="flex items-center w-full h-full" dir="rtl" style={{ gap: 28 }}>
      {/* Donut — right side (first child under RTL); fixed 130-160px, thick ring, holds the sector count */}
      <div className="relative" style={{ width: donutSize, height: donutSize, flexShrink: 0 }}>
        <div className="w-full h-full rounded-full" style={{ background: `conic-gradient(${stops})` }} />
        <div className="absolute rounded-full flex flex-col items-center justify-center"
          style={{ inset: ringThickness, background: "var(--card)" }}>
          <span className="text-[11px] text-slate-500 leading-none mb-1.5">{data.length === 1 ? "قطاع" : "قطاعات"}</span>
          <span className="text-2xl font-extrabold text-white leading-none">{data.length}</span>
        </div>
      </div>

      {/* Percentage / progress / name — left side; one row if a single sector,
          an internally-scrolling list otherwise (card height never changes) */}
      <div className="flex-1 min-w-0 h-full flex flex-col justify-center overflow-y-auto" style={{ gap: 16 }}>
        {data.length === 1
          ? <Row d={data[0]} color={SECTOR_COLORS[0]} />
          : data.map((d, i) => <Row key={d.name} d={d} color={SECTOR_COLORS[i % SECTOR_COLORS.length]} />)}
      </div>
    </div>
  );
}
