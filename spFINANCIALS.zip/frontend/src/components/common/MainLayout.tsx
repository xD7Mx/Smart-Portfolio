import React, { useState, useEffect } from "react";
import { Outlet, NavLink, useLocation } from "react-router-dom";
import {
  LayoutDashboard, Briefcase, TrendingUp, Brain,
  FileText, Bell, Settings, ChevronLeft, ChevronRight, Shield, Calculator,
  Menu, X, CandlestickChart
} from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { notificationsApi } from "../../services/api";
import { useT } from "../../i18n";
import { useAppStore } from "../../store/appStore";
import Logo from "./Logo";
import NewsTicker from "./NewsTicker";

export const PAGES: Record<string, { to: string; icon: any; key: string }> = {
  dashboard:     { to: "/dashboard",     icon: LayoutDashboard, key: "nav.dashboard" },
  portfolio:     { to: "/portfolio",     icon: Briefcase,        key: "nav.portfolio" },
  market:        { to: "/market",        icon: TrendingUp,       key: "nav.market" },
  chart:         { to: "/chart",         icon: CandlestickChart, key: "nav.chart" },
  governance:    { to: "/governance",    icon: Shield,           key: "nav.governance" },
  ai:            { to: "/ai",            icon: Brain,            key: "nav.ai" },
  calculators:   { to: "/calculators",   icon: Calculator,       key: "nav.calculators" },
  reports:       { to: "/reports",       icon: FileText,         key: "nav.reports" },
  notifications: { to: "/notifications", icon: Bell,             key: "nav.notifications" },
  settings:      { to: "/settings",      icon: Settings,         key: "nav.settings" },
};

export default function MainLayout() {
  const [collapsed, setCollapsed] = useState(false);
  const [drawer, setDrawer] = useState(false); // mobile off-canvas
  const t = useT();
  const location = useLocation();
  const { language, pageOrder, hiddenPages } = useAppStore();
  const isRtl = language === "ar";

  const { data: notifData } = useQuery({
    queryKey: ["notifications"],
    queryFn:  () => notificationsApi.list().then(r => r.data.data),
    refetchInterval: 60000,
  });
  const unread = notifData?.filter((n: any) => n.status === "UNREAD").length ?? 0;

  const navIds = pageOrder.filter(id => PAGES[id] && !hiddenPages.includes(id));

  // close the mobile drawer on navigation
  useEffect(() => { setDrawer(false); }, [location.pathname]);

  const Brand = ({ compact = false }: { compact?: boolean }) => (
    <div className="flex items-center gap-3">
      <Logo size={compact ? 30 : 36} />
      {!compact && (
        <div>
          <p className="text-sm font-extrabold text-white tracking-tight">{t("app.name")}</p>
          <p className="text-[10px] font-semibold" style={{
            background: "linear-gradient(90deg,#60a5fa,#a78bfa)",
            WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent",
          }}>حلّل أكثر… قرّر بنفسك</p>
        </div>
      )}
    </div>
  );

  const NavItems = ({ showLabels }: { showLabels: boolean }) => (
    <>
      {navIds.map(id => {
        const { to, icon: Icon, key } = PAGES[id];
        return (
          <NavLink key={to} to={to} onClick={() => setDrawer(false)}
            className={({ isActive }) => "nav-link" + (isActive ? " nav-active" : "")}>
            <div className="relative shrink-0">
              <Icon size={18} />
              {id === "notifications" && unread > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">
                  {unread > 9 ? "9+" : unread}
                </span>
              )}
            </div>
            {showLabels && <span className="font-medium">{t(key)}</span>}
          </NavLink>
        );
      })}
    </>
  );

  return (
    <div dir={isRtl ? "rtl" : "ltr"} className="flex flex-col h-screen overflow-hidden bg-[#060b18]">
      {/* Top news ticker — spans the whole app like professional finance portals */}
      <NewsTicker />

      <div className="flex flex-1 overflow-hidden">
        {/* Desktop sidebar */}
        <aside className={`hidden md:flex flex-col ${isRtl ? "border-l" : "border-r"} border-[#1a2540] bg-[#080f1e] transition-all duration-200 ${collapsed ? "w-16" : "w-56"}`}>
          <div className="flex items-center gap-3 px-4 py-5 border-b border-[#1a2540]">
            <Brand compact={collapsed} />
          </div>
          <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
            <NavItems showLabels={!collapsed} />
          </nav>
          <button onClick={() => setCollapsed(!collapsed)}
            className="flex items-center justify-center p-3 border-t border-[#1a2540] text-slate-500 hover:text-white hover:bg-[#111c30] transition-all">
            {collapsed
              ? (isRtl ? <ChevronRight size={16} /> : <ChevronLeft size={16} />)
              : (isRtl ? <ChevronLeft size={16} /> : <ChevronRight size={16} />)}
          </button>
        </aside>

        {/* Mobile drawer */}
        {drawer && (
          <div className="md:hidden fixed inset-0 z-50" onClick={() => setDrawer(false)}>
            <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" />
            <aside dir={isRtl ? "rtl" : "ltr"}
              className={`absolute top-0 ${isRtl ? "right-0" : "left-0"} h-full w-64 bg-[#080f1e] ${isRtl ? "border-l" : "border-r"} border-[#1a2540] flex flex-col drawer-in`}
              onClick={e => e.stopPropagation()}>
              <div className="flex items-center justify-between px-4 py-4 border-b border-[#1a2540]">
                <Brand />
                <button onClick={() => setDrawer(false)} className="text-slate-500 hover:text-white p-1"><X size={18} /></button>
              </div>
              <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto"><NavItems showLabels /></nav>
            </aside>
          </div>
        )}

        {/* Main */}
        <main className="flex-1 overflow-y-auto flex flex-col">
          {/* Mobile top bar */}
          <div className="md:hidden sticky top-0 z-30 flex items-center gap-3 px-4 h-14 bg-[#080f1e]/95 backdrop-blur border-b border-[#1a2540]">
            <button onClick={() => setDrawer(true)} className="text-slate-300 hover:text-white p-1"><Menu size={22} /></button>
            <Brand compact />
            <NavLink to="/notifications" className="relative mr-auto ms-auto text-slate-300 hover:text-white p-1">
              <Bell size={20} />
              {unread > 0 && <span className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-red-500 text-white text-[10px] rounded-full flex items-center justify-center">{unread > 9 ? "9+" : unread}</span>}
            </NavLink>
          </div>

          <div className="p-3 sm:p-5 lg:p-6 max-w-[1600px] w-full mx-auto flex-1">
            <Outlet />
            <footer className="sp-footer">حقوق النشر محفوظة لـ D7M ©</footer>
          </div>
        </main>
      </div>
    </div>
  );
}
