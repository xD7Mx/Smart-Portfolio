import React, { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Radio } from "lucide-react";
import { marketApi } from "../../services/api";

// Constant readable speed regardless of how many headlines are loaded —
// previously the animation had a fixed 60s duration no matter the content
// width, so more headlines meant a visually faster (unreadable) scroll.
const PX_PER_SECOND = 70;

/**
 * Top news ticker — a continuously scrolling strip of the latest real
 * headlines, like professional finance portals. Pauses on hover; each
 * headline links to its article. RTL-aware and mobile-friendly.
 */
export default function NewsTicker() {
  const { data: news = [] } = useQuery({
    queryKey: ["market-news"],
    queryFn: () => marketApi.news().then(r => (Array.isArray(r.data.data) ? r.data.data : [])),
    refetchInterval: 5 * 60 * 1000,
  });
  const trackRef = useRef<HTMLDivElement>(null);
  const [duration, setDuration] = useState(60);

  const items = news.slice(0, 15);

  useEffect(() => {
    const el = trackRef.current;
    if (!el) return;
    // The track renders the item list twice back-to-back (for the seamless
    // loop), so half its scrollWidth is the actual one-pass content width.
    const halfWidth = el.scrollWidth / 2;
    if (halfWidth > 0) setDuration(Math.max(20, halfWidth / PX_PER_SECOND));
  }, [items.length, JSON.stringify(items.map((n: any) => n.headline))]);

  if (!news.length) return null;

  const Row = () => (
    <>
      {items.map((n: any, i: number) => {
        const body = (
          <span className="ticker-item">
            <span className="ticker-dot" />
            {n.source && <span className="ticker-src">{n.source}</span>}
            <span className="ticker-txt">{n.headline}</span>
          </span>
        );
        return n.url
          ? <a key={i} href={n.url} target="_blank" rel="noopener noreferrer" className="ticker-link">{body}</a>
          : <span key={i} className="ticker-link">{body}</span>;
      })}
    </>
  );

  return (
    <div className="news-ticker">
      <div className="news-ticker-label">
        <Radio size={13} />
        <span>آخر الأخبار</span>
      </div>
      <div className="news-ticker-viewport">
        <div className="news-ticker-track" ref={trackRef} style={{ animationDuration: `${duration}s` }}>
          <Row /><Row />
        </div>
      </div>
    </div>
  );
}
