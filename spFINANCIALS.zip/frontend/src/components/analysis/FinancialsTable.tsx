import React from "react";
import { useQuery } from "@tanstack/react-query";
import { marketApi } from "../../services/api";

const compact = (n: number) => {
  if (n == null) return "—";
  return n.toLocaleString("en-US", { maximumFractionDigits: 0 });
};

/* Traffic-light dot like the reference report: green good, amber caution, red bad */
function Light({ change, invert = false }: { change: number | null; invert?: boolean }) {
  if (change == null) return <span className="text-slate-500 text-xs">—</span>;
  const good = invert ? change <= 0 : change >= 0;
  const strong = Math.abs(change) >= 5;
  const color = good ? (strong ? "#10b981" : "#22c55e") : (strong ? "#f43f5e" : "#f59e0b");
  return (
    <span className="inline-flex items-center gap-1.5 font-bold text-xs" style={{ color }}>
      <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
      {(change >= 0 ? "+" : "") + change.toFixed(1)}%
    </span>
  );
}

/**
 * Three-year financial statement table (نمو / ربحية / ملاءة / تدفقات) with a
 * YoY change traffic light and an automatic AI verdict — the governance report.
 * Fully auto-filled from the source; no manual entry.
 */
export default function FinancialsTable({ symbol }: { symbol: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["financials", symbol],
    queryFn: () => marketApi.financials(symbol).then(r => r.data.data),
    enabled: !!symbol,
    retry: 0,
  });

  if (isLoading) return <div className="card"><div className="h-40 skeleton" /></div>;
  if (!data || !data.periods) return (
    <div className="card"><div className="py-10 text-center text-slate-500 text-sm">
      لا توجد قوائم مالية متاحة لهذا الرمز حالياً — تُجلب تلقائياً من المصدر عند توفرها
    </div></div>
  );

  const years: number[] = data.years;
  const ch = data.changes || {};
  const P = (field: string) => data.periods.map((p: any) => p[field]);

  const sections: { title: string; rows: { label: string; field: string; invert?: boolean; ratio?: boolean }[] }[] = [
    { title: "النمو", rows: [
      { label: "الإيرادات", field: "revenue" },
      { label: "ربحية السهم", field: "eps", ratio: true },
    ]},
    { title: "الربحية", rows: [
      { label: "صافي الربح", field: "net_income" },
    ]},
    { title: "الملاءة المالية", rows: [
      { label: "حقوق الملكية", field: "equity" },
      { label: "نسبة المديونية", field: "debt_ratio", invert: true, ratio: true },
      { label: "تغطية الفوائد", field: "interest_coverage", ratio: true },
    ]},
    { title: "التدفقات النقدية", rows: [
      { label: "صافي الأنشطة التشغيلية", field: "operating_cash_flow" },
      { label: "التدفق النقدي الحر", field: "free_cash_flow" },
      { label: "النقد نهاية الفترة", field: "ending_cash" },
    ]},
  ];

  return (
    <div className="card overflow-x-auto">
      <table className="w-full text-sm min-w-[520px]">
        <thead>
          <tr className="border-b border-[#1a2540]">
            <th className="th text-start">التغير %</th>
            {years.map(y => <th key={y} className="th text-center">{y}</th>)}
            <th className="th text-start">المؤشر</th>
          </tr>
        </thead>
        <tbody>
          {sections.map(sec => (
            <React.Fragment key={sec.title}>
              <tr><td colSpan={years.length + 2} className="py-2 px-3 text-center text-[13px] font-bold text-blue-300 bg-[#0a1020]">{sec.title}</td></tr>
              {sec.rows.map(row => {
                const vals = P(row.field);
                return (
                  <tr key={row.field} className="border-b border-[#1a2540]/50">
                    <td className="td"><Light change={ch[row.field] ?? null} invert={row.invert} /></td>
                    {vals.map((v: number, i: number) => (
                      <td key={i} className="td text-center font-mono text-slate-200">
                        {v == null ? "—" : row.ratio ? v.toFixed(2) : compact(v)}
                      </td>
                    ))}
                    <td className="td font-semibold text-white">{row.label}</td>
                  </tr>
                );
              })}
            </React.Fragment>
          ))}
        </tbody>
      </table>
      {data.verdict && (
        <div className="mt-3 text-center text-sm font-bold text-emerald-400">إبقاء: {data.verdict}</div>
      )}
      {data.investment_phase === true && (
        <p className="mt-2 text-center text-[11px] text-amber-400">
          🏗️ مرحلة استثمارية محتملة: نفقات رأسمالية مرتفعة نسبةً للإيرادات مع إيرادات ثابتة/نامية — الدين أو انخفاض الربح هنا قد يعكسان توسعاً مموَّلاً لا ضعفاً.
        </p>
      )}
      {years.length < 3 && (
        <p className="mt-3 text-center text-[11px] text-slate-500">
          يعرض هذا الجدول {years.length === 1 ? "سنة مالية واحدة متاحة" : `${years.length} سنوات مالية متاحة`} حالياً — التغطية التاريخية الأعمق تعتمد على ما يوفّره مزود البيانات لهذا الرمز، وتُستكمل تلقائياً كلما توفّرت.
        </p>
      )}
    </div>
  );
}
