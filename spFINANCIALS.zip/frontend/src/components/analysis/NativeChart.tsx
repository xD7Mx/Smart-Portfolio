import React, { useEffect, useRef, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { marketApi } from "../../services/api";

/**
 * Native candlestick chart powered by TradingView's open-source
 * Lightweight-Charts (loaded from CDN) and fed with OUR Yahoo OHLC data — so it
 * works reliably for Saudi (Tadawul) symbols and the TASI index, unlike the
 * free TradingView embed which has no Tadawul data. Indicators (SMA 20/50/200,
 * RSI) are computed locally and togggleable.
 */
let _libPromise: Promise<any> | null = null;
function loadLib(): Promise<any> {
  if ((window as any).LightweightCharts) return Promise.resolve((window as any).LightweightCharts);
  if (_libPromise) return _libPromise;
  _libPromise = new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://unpkg.com/lightweight-charts@4.1.3/dist/lightweight-charts.standalone.production.js";
    s.async = true;
    s.onload = () => resolve((window as any).LightweightCharts);
    s.onerror = reject;
    document.head.appendChild(s);
  });
  return _libPromise;
}

function sma(data: number[], p: number): (number | null)[] {
  const out: (number | null)[] = [];
  let sum = 0;
  for (let i = 0; i < data.length; i++) {
    sum += data[i];
    if (i >= p) sum -= data[i - p];
    out.push(i >= p - 1 ? sum / p : null);
  }
  return out;
}
function rsi(data: number[], p = 14): (number | null)[] {
  const out: (number | null)[] = Array(data.length).fill(null);
  if (data.length < p + 1) return out;
  let g = 0, l = 0;
  for (let i = 1; i <= p; i++) { const d = data[i] - data[i - 1]; g += Math.max(d, 0); l += Math.max(-d, 0); }
  g /= p; l /= p;
  out[p] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  for (let i = p + 1; i < data.length; i++) {
    const d = data[i] - data[i - 1];
    g = (g * (p - 1) + Math.max(d, 0)) / p;
    l = (l * (p - 1) + Math.max(-d, 0)) / p;
    out[i] = l === 0 ? 100 : 100 - 100 / (1 + g / l);
  }
  return out;
}

const RANGES: [string, string][] = [["1mo", "شهر"], ["3mo", "3 أشهر"], ["6mo", "6 أشهر"], ["1y", "سنة"], ["2y", "سنتان"], ["5y", "5 سنوات"]];

export default function NativeChart({ symbol, theme = "dark" }: { symbol: string; theme?: "dark" | "light" }) {
  const el = useRef<HTMLDivElement>(null);
  const [range, setRange] = useState("6mo");
  const [ind, setInd] = useState({ sma20: true, sma50: true, sma200: false, rsi: true });
  const [err, setErr] = useState(false);

  const { data: bars = [], isLoading } = useQuery({
    queryKey: ["ohlc", symbol, range],
    queryFn: () => marketApi.history(symbol, range).then(r => (Array.isArray(r.data?.data) ? r.data.data : [])),
    enabled: !!symbol,
    retry: 0,
  });

  useEffect(() => {
    if (!el.current || !bars.length) return;
    let chart: any, ro: ResizeObserver;
    let cancelled = false;
    loadLib().then((LW) => {
      if (cancelled || !el.current) return;
      el.current.innerHTML = "";
      const light = theme === "light";
      chart = LW.createChart(el.current, {
        autoSize: true,
        layout: { background: { color: "transparent" }, textColor: light ? "#334155" : "#94a3b8", fontFamily: "inherit" },
        grid: { vertLines: { color: light ? "#eef2f7" : "rgba(148,163,184,.08)" }, horzLines: { color: light ? "#eef2f7" : "rgba(148,163,184,.08)" } },
        rightPriceScale: { borderColor: light ? "#e2e8f0" : "#1a2540", scaleMargins: { top: 0.06, bottom: ind.rsi ? 0.28 : 0.14 } },
        timeScale: { borderColor: light ? "#e2e8f0" : "#1a2540", timeVisible: false },
        crosshair: { mode: 0 },
      });
      const candle = chart.addCandlestickSeries({
        upColor: "#10b981", downColor: "#f43f5e", borderVisible: false,
        wickUpColor: "#10b981", wickDownColor: "#f43f5e",
      });
      candle.setData(bars.map((b: any) => ({ time: b.date, open: b.open, high: b.high, low: b.low, close: b.close })));

      // volume
      const vol = chart.addHistogramSeries({ priceScaleId: "", priceFormat: { type: "volume" } });
      vol.priceScale().applyOptions({ scaleMargins: { top: 0.86, bottom: 0 } });
      vol.setData(bars.map((b: any) => ({ time: b.date, value: b.volume, color: b.close >= b.open ? "rgba(16,185,129,.4)" : "rgba(244,63,94,.4)" })));

      const closes = bars.map((b: any) => b.close);
      const addSMA = (period: number, color: string) => {
        const s = chart.addLineSeries({ color, lineWidth: 1.5, priceLineVisible: false, lastValueVisible: false });
        s.setData(sma(closes, period).map((v, i) => v == null ? null : ({ time: bars[i].date, value: v })).filter(Boolean));
      };
      if (ind.sma20) addSMA(20, "#3b82f6");
      if (ind.sma50) addSMA(50, "#f59e0b");
      if (ind.sma200) addSMA(200, "#a78bfa");

      if (ind.rsi) {
        const rs = chart.addLineSeries({ color: "#06b6d4", lineWidth: 1.5, priceScaleId: "rsi", priceLineVisible: false, lastValueVisible: false });
        chart.priceScale("rsi").applyOptions({ scaleMargins: { top: 0.74, bottom: 0.02 }, borderColor: light ? "#e2e8f0" : "#1a2540" });
        rs.setData(rsi(closes).map((v, i) => v == null ? null : ({ time: bars[i].date, value: v })).filter(Boolean));
      }
      chart.timeScale().fitContent();
      ro = new ResizeObserver(() => chart && chart.applyOptions({}));
      ro.observe(el.current);
    }).catch(() => setErr(true));
    return () => { cancelled = true; try { ro && ro.disconnect(); chart && chart.remove(); } catch {} };
  }, [bars, theme, ind, range]);

  const toggle = (k: keyof typeof ind) => setInd(s => ({ ...s, [k]: !s[k] }));

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between flex-wrap gap-2">
        <div className="flex gap-1.5 flex-wrap">
          {RANGES.map(([id, lbl]) => (
            <button key={id} onClick={() => setRange(id)}
              className={"px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-all " +
                (range === id ? "bg-blue-600/20 text-blue-400 border-blue-500/40" : "border-[#1a2540] text-slate-500 hover:text-slate-300")}>
              {lbl}
            </button>
          ))}
        </div>
        <div className="flex gap-1.5 flex-wrap">
          {([["sma20", "SMA20", "#3b82f6"], ["sma50", "SMA50", "#f59e0b"], ["sma200", "SMA200", "#a78bfa"], ["rsi", "RSI", "#06b6d4"]] as const).map(([k, lbl, c]) => (
            <button key={k} onClick={() => toggle(k)}
              className={"px-2.5 py-1 rounded-lg text-[11px] font-bold border transition-all " + (ind[k] ? "text-white" : "text-slate-500")}
              style={ind[k] ? { background: c + "22", borderColor: c + "66" } : { borderColor: "var(--line)" }}>
              {lbl}
            </button>
          ))}
        </div>
      </div>
      {err ? (
        <div className="h-[420px] flex items-center justify-center text-slate-500 text-sm">تعذّر تحميل مكتبة الرسم — تأكد من الاتصال بالإنترنت.</div>
      ) : isLoading ? (
        <div className="h-[420px] skeleton rounded-xl" />
      ) : !bars.length ? (
        <div className="h-[420px] flex items-center justify-center text-slate-500 text-sm">لا توجد بيانات سعرية تاريخية لهذا الرمز حالياً.</div>
      ) : (
        <div ref={el} style={{ height: "62vh", minHeight: 420, width: "100%" }} />
      )}
    </div>
  );
}
