import React from "react";
import { useQuery } from "@tanstack/react-query";
import {
  CheckCircle, XCircle, TrendingUp, TrendingDown, Activity, Landmark, Sparkles
} from "lucide-react";
import { marketApi } from "../../services/api";
import clsx from "clsx";

const fmt = (n: number, d = 2) => (n ?? 0).toLocaleString("en-US", { minimumFractionDigits: d, maximumFractionDigits: d });
const compact = (n: number) => {
  if (n == null) return "—";
  const a = Math.abs(n);
  if (a >= 1e9) return (n / 1e9).toLocaleString("en-US", { maximumFractionDigits: 2 }) + " مليار";
  if (a >= 1e6) return (n / 1e6).toLocaleString("en-US", { maximumFractionDigits: 2 }) + " مليون";
  return n.toLocaleString("en-US", { maximumFractionDigits: 0 });
};

function ScoreRing({ score, size = 96 }: { score: number; size?: number }) {
  const color = score >= 70 ? "#10b981" : score >= 50 ? "#f59e0b" : "#f43f5e";
  return (
    <div className="relative inline-flex items-center justify-center shrink-0" style={{ width: size, height: size }}>
      <svg className="-rotate-90" width={size} height={size} viewBox="0 0 36 36">
        <circle cx="18" cy="18" r="15.9" fill="none" stroke="#1a2540" strokeWidth="3" />
        <circle cx="18" cy="18" r="15.9" fill="none" stroke={color} strokeWidth="3"
          strokeDasharray={`${score} ${100 - score}`} strokeLinecap="round" />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="font-extrabold text-white leading-none" style={{ fontSize: size * 0.24 }}>{score}</span>
        <span className="text-slate-500" style={{ fontSize: size * 0.11 }}>/100</span>
      </div>
    </div>
  );
}

const verdictColor = (v: string) =>
  v === "قوي جداً" ? "#10b981" : v === "قوي" ? "#22c55e" : v === "متوسط" ? "#f59e0b" : "#f43f5e";

/**
 * Full automatic company analysis — fundamentals + financial verdict +
 * technical verdict + strengths/weaknesses + AI score + decision.
 * Fetches on mount (no button); the backend caches 24h.
 */
export default function AnalysisPanel({ symbol, name }: { symbol: string; name?: string }) {
  const { data, isLoading, error } = useQuery({
    queryKey: ["analysis", symbol],
    queryFn: () => marketApi.company(symbol).then(r => r.data.data),
    enabled: !!symbol,
    retry: 0,
  });

  if (isLoading) return (
    <div className="analysis-card space-y-3 animate-pulse">
      <div className="h-6 skeleton w-40" /><div className="h-24 skeleton" />
      <div className="grid grid-cols-3 gap-2">{[...Array(6)].map((_, i) => <div key={i} className="h-14 skeleton" />)}</div>
    </div>
  );
  if (error || !data) return (
    <div className="analysis-card"><div className="py-10 text-center text-slate-500 text-sm">
      لا توجد بيانات تحليل متاحة لهذا الرمز حالياً — تُجلب وتُحلَّل تلقائياً عند توفر المصدر
    </div></div>
  );

  const f = data.fundamentals || {};
  const fin = data.financial || {};
  const tech = data.technical;
  const dec = data.decision || {};
  const up = (data.change_pct ?? 0) >= 0;

  const kpis: [string, string | null][] = [
    ["القيمة السوقية", f.market_cap ? compact(f.market_cap) : null],
    ["الإيرادات", f.revenue ? compact(f.revenue) : null],
    ["صافي الربح", f.net_income ? compact(f.net_income) : null],
    ["ربحية السهم EPS", f.eps != null ? fmt(f.eps) : null],
    ["مكرر الربحية P/E", f.pe_ratio ? fmt(f.pe_ratio) : null],
    ["العائد على الحقوق ROE", f.roe != null ? fmt(f.roe) + "%" : null],
    ["العائد على الأصول ROA", f.roa != null ? fmt(f.roa) + "%" : null],
    ["هامش الربح", f.profit_margin != null ? fmt(f.profit_margin) + "%" : null],
    ["عائد التوزيعات", f.dividend_yield != null ? fmt(f.dividend_yield) + "%" : null],
    ["التدفق النقدي التشغيلي", f.operating_cash_flow ? compact(f.operating_cash_flow) : null],
    ["التدفق النقدي الحر", f.free_cash_flow ? compact(f.free_cash_flow) : null],
    ["الدين لحقوق الملكية", f.debt_to_equity != null ? fmt(f.debt_to_equity) : null],
    ["أعلى 52 أسبوع", f.week52_high != null ? fmt(f.week52_high) : null],
    ["أدنى 52 أسبوع", f.week52_low != null ? fmt(f.week52_low) : null],
    ["تقدير المحللين", f.target_mean_price != null ? fmt(f.target_mean_price) + "" : null],
  ].filter(([, v]) => v != null) as [string, string][];

  return (
    <div className="analysis-card space-y-5">
      {/* Header: score + decision */}
      <div className="flex items-center gap-5 flex-wrap">
        <ScoreRing score={data.ai_score ?? 0} />
        <div className="flex-1 min-w-[200px]">
          <div className="flex items-center gap-2 mb-1">
            <Sparkles size={15} className="text-violet-400" />
            <p className="text-[13px] font-bold text-white">تقييم الذكاء لـ {data.name || name || symbol}</p>
          </div>
          {data.price != null && (
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-2xl font-extrabold font-mono" style={{ color: up ? "#10b981" : "#f43f5e" }}>{fmt(data.price)}</span>
              <span className={up ? "tag-g" : "tag-r"}>{(up ? "+" : "") + (data.change_pct ?? 0).toFixed(2)}%</span>
            </div>
          )}
          {dec.label && (
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-xl font-bold text-sm"
              style={{ background: dec.color + "1e", color: dec.color, border: `1px solid ${dec.color}44` }}>
              قرار الاستثمار: {dec.label}
            </div>
          )}
        </div>
      </div>

      {/* Financial + technical verdicts */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        <div className="rounded-xl p-3.5" style={{ background: "rgba(10,16,32,.6)" }}>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5"><Landmark size={13} /> التحليل المالي</span>
            {fin.verdict && <span className="text-xs font-bold" style={{ color: verdictColor(fin.verdict) }}>{fin.verdict}</span>}
          </div>
          <div className="h-2 rounded-full bg-slate-800"><div className="h-2 rounded-full" style={{ width: `${fin.score ?? 0}%`, background: verdictColor(fin.verdict || "") }} /></div>
          <p className="text-[11px] text-slate-500 mt-1.5">{fin.score ?? 0}/100</p>
        </div>
        <div className="rounded-xl p-3.5" style={{ background: "rgba(10,16,32,.6)" }}>
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5"><Activity size={13} /> التحليل الفني</span>
            {tech?.verdict && <span className="text-xs font-bold" style={{ color: verdictColor(tech.verdict) }}>{tech.verdict} · {tech.trend}</span>}
          </div>
          {tech ? (
            <>
              <div className="h-2 rounded-full bg-slate-800"><div className="h-2 rounded-full" style={{ width: `${tech.score}%`, background: verdictColor(tech.verdict) }} /></div>
              <div className="flex flex-wrap gap-x-3 gap-y-0.5 mt-2 text-[11px] text-slate-400">
                {tech.rsi != null && <span>RSI {tech.rsi}</span>}
                {tech.sma50 != null && <span>SMA50 {tech.sma50}</span>}
                {tech.macd != null && <span>MACD {tech.macd}</span>}
                {tech.support != null && <span>دعم {tech.support}</span>}
                {tech.resistance != null && <span>مقاومة {tech.resistance}</span>}
              </div>
            </>
          ) : <p className="text-[11px] text-slate-500 mt-1">يتطلب تاريخاً سعرياً كافياً</p>}
        </div>
      </div>

      {/* Fundamentals grid */}
      {kpis.length > 0 && (
        <div>
          <p className="text-xs font-bold text-slate-400 mb-2">البيانات المالية</p>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
            {kpis.map(([lbl, v]) => (
              <div key={lbl} className="kpi"><div className="kpi-lbl">{lbl}</div><div className="kpi-val">{v}</div></div>
            ))}
          </div>
        </div>
      )}

      {/* Strengths / weaknesses */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {data.strengths?.length > 0 && (
          <div className="rounded-xl p-3.5" style={{ background: "rgba(10,16,32,.6)" }}>
            <p className="text-emerald-400 font-bold text-xs mb-2 flex items-center gap-1.5"><CheckCircle size={13} /> نقاط القوة</p>
            <ul className="space-y-1">{data.strengths.map((s: string, i: number) => (
              <li key={i} className="text-slate-300 text-xs flex items-start gap-1.5"><span className="text-emerald-500 mt-0.5">✓</span>{s}</li>))}</ul>
          </div>
        )}
        {data.weaknesses?.length > 0 && (
          <div className="rounded-xl p-3.5" style={{ background: "rgba(10,16,32,.6)" }}>
            <p className="text-amber-400 font-bold text-xs mb-2 flex items-center gap-1.5"><XCircle size={13} /> نقاط المخاطرة</p>
            <ul className="space-y-1">{data.weaknesses.map((s: string, i: number) => (
              <li key={i} className="text-slate-300 text-xs flex items-start gap-1.5"><span className="text-amber-500 mt-0.5">⚠</span>{s}</li>))}</ul>
          </div>
        )}
      </div>

      <p className="text-[11px] text-slate-500 flex items-center gap-1"><Landmark size={11} /> التحليل يُبنى تلقائياً لدعم القرار — القرار النهائي يبقى بيدك.</p>
    </div>
  );
}
