import React from "react";
import { useQuery } from "@tanstack/react-query";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { CalendarClock, Coins } from "lucide-react";
import { marketApi } from "../../services/api";

const fmt = (n: number) => (n ?? 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });

/**
 * Company dividend profile — distribution frequency, last-10-years history,
 * and an upcoming/last-distribution note. Real data from Yahoo, cached 24h.
 */
export default function DividendProfile({ symbol }: { symbol: string }) {
  const { data, isLoading } = useQuery({
    queryKey: ["dividend-profile", symbol],
    queryFn: () => marketApi.dividends(symbol).then(r => r.data.data),
    enabled: !!symbol,
    retry: 0,
  });

  if (isLoading) return <div className="card"><div className="h-32 skeleton" /></div>;
  if (!data || (!data.yearly?.length && !data.note)) return (
    <div className="card"><div className="py-8 text-center text-slate-500 text-sm">
      لا توجد بيانات توزيعات معلنة لهذا الرمز حالياً — تُجلب تلقائياً عند توفرها من المصدر
    </div></div>
  );

  const noteColor = data.note?.type === "upcoming" ? "#10b981" : data.note?.type === "today" ? "#f59e0b" : "#64748b";

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Coins size={15} className="text-amber-400" />
          <h3 className="text-[13px] font-bold text-white">ملف التوزيعات</h3>
        </div>
        {data.frequency && <span className="tag-b">التوزيع: {data.frequency}</span>}
      </div>

      {data.note && (
        <div className="flex items-center gap-2 rounded-xl p-3 mb-4 text-sm"
          style={{ background: noteColor + "18", border: `1px solid ${noteColor}44`, color: noteColor }}>
          <CalendarClock size={15} className="shrink-0" />
          <span className="font-semibold">{data.note.text}</span>
        </div>
      )}

      {(data.ex_date || data.pay_date) && (
        <div className="grid grid-cols-2 gap-2 mb-4">
          <div className="kpi"><div className="kpi-lbl">تاريخ الأحقية</div><div className="kpi-val">{data.ex_date || "—"}</div></div>
          <div className="kpi"><div className="kpi-lbl">تاريخ التوزيع</div><div className="kpi-val">{data.pay_date || "—"}</div></div>
        </div>
      )}

      {data.yearly?.length > 0 && (
        <>
          <p className="text-xs font-bold text-slate-400 mb-2">التوزيع السنوي — آخر {data.yearly.length} سنوات (للسهم)</p>
          <div style={{ height: 180 }} dir="ltr">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={data.yearly} margin={{ top: 6, right: 6, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.12)" />
                <XAxis dataKey="year" tick={{ fontSize: 10, fill: "#94a3b8" }} />
                <YAxis tick={{ fontSize: 10, fill: "#64748b" }} width={40} />
                <Tooltip contentStyle={{ background: "var(--pop)", border: "1px solid var(--line)", color: "var(--tip-text)", borderRadius: 10, fontSize: 12 }}
                  formatter={(v: any) => [fmt(v) + "", "التوزيع"]} labelFormatter={(l: any) => `سنة ${l}`} />
                <Bar dataKey="amount" radius={[5, 5, 0, 0]}>
                  {data.yearly.map((_: any, i: number) => <Cell key={i} fill="#f59e0b" />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </>
      )}

      {data.recent?.length > 0 && (
        <div className="mt-4">
          <p className="text-xs font-bold text-slate-400 mb-2">آخر التوزيعات المعلنة</p>
          <div className="flex flex-wrap gap-2">
            {data.recent.map((d: any, i: number) => (
              <span key={i} className="tag-n" style={{ fontSize: 11 }}>{d.date} · {fmt(d.amount)}</span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
