/**
 * Widget registry — every widget is an independent, self-contained unit
 * (own data fetching via react-query, own empty state). Adding/removing/
 * moving/resizing any widget never affects the rest of the system.
 * Doctrine: NO fake data — if a widget has no real data it says so.
 */
import React, { useState } from "react";
import { createPortal } from "react-dom";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  AreaChart, Area,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from "recharts";
import {
  TrendingUp, TrendingDown, Wallet, Target, Activity, Landmark,
  Coins, Building2, Newspaper, CalendarDays, Sparkles, Bell, ArrowUp, ArrowDown, X
} from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { portfolioApi, goalsApi, cashApi, marketApi, aiApi, notificationsApi, notesApi } from "../services/api";
import SectorInfographic, { buildSectorData } from "../components/common/SectorInfographic";
import { lookupCompany } from "../data/saudiCompanies";

const COLORS = ["#3b82f6","#8b5cf6","#10b981","#06b6d4","#f59e0b","#f43f5e","#6366f1"];
const fmt = (n: number) => (n ?? 0).toLocaleString("en-US", { maximumFractionDigits: 0 });
const fmt2 = (n: number) => (n ?? 0).toLocaleString("en-US", { maximumFractionDigits: 2 });
const fmtPct = (n: number) => (n >= 0 ? "+" : "") + (n ?? 0).toFixed(2) + "%";

/* ── Shared data hooks (react-query dedupes across widgets) ── */
function useSummary() {
  return useQuery({ queryKey: ["portfolio-summary"], queryFn: () => portfolioApi.summary().then(r => r.data.data) });
}
function useHoldings() {
  return useQuery({
    queryKey: ["portfolio"],
    queryFn: () => portfolioApi.get().then(r => Array.isArray(r.data?.data) ? r.data.data : []),
  });
}
function useCash() {
  return useQuery({ queryKey: ["cash"], queryFn: () => cashApi.balance().then(r => r.data?.data) });
}
function useOverview() {
  return useQuery({ queryKey: ["market-overview"], queryFn: () => marketApi.overview().then(r => r.data.data), refetchInterval: 5 * 60 * 1000 });
}
function useHealth() {
  return useQuery({ queryKey: ["portfolio-health"], queryFn: () => portfolioApi.health().then(r => r.data.data) });
}

function Empty({ label = "لا توجد بيانات حالياً" }: { label?: string }) {
  return <div className="flex-1 flex items-center justify-center text-slate-500 text-xs py-4">{label}</div>;
}

/* ── Stat widgets ── */
function StatWidget({ label, value, sub, icon: Icon, ic, color, cls = "" }: any) {
  return (
    <div className="h-full flex flex-col justify-center gap-1 px-1">
      <div className={"mc-icon " + ic}><Icon size={14} style={{color}} /></div>
      <div className="mc-lbl">{label}</div>
      <div className={"mc-val " + cls}>{value}</div>
      {sub && <div className="mc-sub">{sub}</div>}
    </div>
  );
}

const MarketValueW = () => { const { data: s } = useSummary(); return <StatWidget label="القيمة السوقية" value={fmt(s?.total_current_value)} sub="" icon={Activity} ic="ic-b" color="#60a5fa" cls="b" />; };
const InvestedW    = () => { const { data: s } = useSummary(); return <StatWidget label="إجمالي المدفوع" value={fmt(s?.total_cost)} sub="" icon={Coins} ic="ic-v" color="#a78bfa" />; };
const UnrealizedW  = () => {
  const { data: s } = useSummary();
  const u = (s?.total_current_value ?? 0) - (s?.total_cost ?? 0);
  const up = u >= 0;
  return <StatWidget label="أرباح غير محققة" value={(up ? "+" : "") + fmt(u)} sub={fmtPct(s?.total_cost ? u / s.total_cost * 100 : 0)} icon={up ? TrendingUp : TrendingDown} ic={up ? "ic-g" : "ic-r"} color={up ? "#10b981" : "#f43f5e"} cls={up ? "g" : "r"} />;
};
/* Small shared modal shell for the widget detail popups below */
function DetailModal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  // Portal to <body>: widgets live inside react-grid-layout items, which are
  // CSS-transformed — a transform creates a new containing block for
  // position:fixed, so without a portal this overlay would be trapped
  // inside the small widget tile instead of covering the screen.
  return createPortal(
    <div className="modal-overlay" onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
      <div className="modal-box fade-in" style={{ maxWidth: 460 }}>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-white text-sm">{title}</h3>
          <button onClick={onClose} className="text-slate-500 hover:text-white p-1"><X size={16} /></button>
        </div>
        {children}
      </div>
    </div>,
    document.body
  );
}

const DividendsW = () => {
  const { data: h = [] } = useHoldings();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const d = h.reduce((a: number, x: any) => a + (x.total_dividends_received || 0), 0);
  const rows = [...h]
    .filter((x: any) => (x.total_dividends_received || 0) > 0)
    .sort((a: any, b: any) => (b.total_dividends_received || 0) - (a.total_dividends_received || 0));
  return (
    <>
      <div className="h-full cursor-pointer" onClick={() => setOpen(true)}>
        <StatWidget label="توزيعات الأرباح" value={"+" + fmt(d)} sub="اضغط للتفاصيل" icon={Landmark} ic="ic-a" color="#f59e0b" />
      </div>
      {open && (
        <DetailModal title="توزيعات الأرباح حسب الشركة" onClose={() => setOpen(false)}>
          {rows.length === 0 ? <Empty label="لا توجد توزيعات مسجلة بعد" /> : (
            <div className="space-y-1.5">
              {rows.map((x: any) => (
                <button key={x.id ?? x.company?.id} onClick={() => { setOpen(false); nav("/portfolio/" + x.company?.id); }}
                  className="w-full flex items-center justify-between gap-2 px-3 py-2.5 rounded-xl hover:bg-[var(--surface-3,_#111c30)] transition-colors text-start">
                  <span className="flex items-center gap-2">
                    <span className="text-white text-sm font-semibold">{x.company?.name_ar || x.company?.name}</span>
                    <span className="tag-b" style={{ fontSize: 10 }}>{x.company?.symbol}</span>
                  </span>
                  <span className="text-sm font-bold profit">+{fmt(x.total_dividends_received)}</span>
                </button>
              ))}
              <div className="flex items-center justify-between px-3 pt-2 mt-2" style={{ borderTop: "1px solid #1a2540" }}>
                <span className="text-xs text-slate-500">الإجمالي</span>
                <span className="text-sm font-extrabold profit">+{fmt(d)}</span>
              </div>
            </div>
          )}
        </DetailModal>
      )}
    </>
  );
};

const LiquidityW = () => {
  const { data: c } = useCash();
  const [open, setOpen] = useState(false);
  const { data: history = [] } = useQuery({
    queryKey: ["cash-history"],
    queryFn: () => cashApi.history().then(r => Array.isArray(r.data?.data) ? r.data.data : []),
    enabled: open,
  });
  return (
    <>
      <div className="h-full cursor-pointer" onClick={() => setOpen(true)}>
        <StatWidget label="السيولة المتاحة" value={fmt(c?.available_cash ?? c?.total_cash ?? 0)} sub="اضغط للتفاصيل" icon={Wallet} ic="ic-b" color="#60a5fa" cls="b" />
      </div>
      {open && (
        <DetailModal title="تفاصيل السيولة" onClose={() => setOpen(false)}>
          <div className="grid grid-cols-2 gap-2 mb-4">
            <div className="stat-row" style={{ display: "block" }}><div className="stat-lbl mb-1">السيولة المتاحة</div><div className="stat-val b" style={{ fontSize: 16 }}>{fmt(c?.available_cash ?? 0)}</div></div>
            <div className="stat-row" style={{ display: "block" }}><div className="stat-lbl mb-1">قيد التنفيذ</div><div className="stat-val" style={{ fontSize: 16 }}>{fmt(c?.pending_cash ?? 0)}</div></div>
            <div className="stat-row" style={{ display: "block" }}><div className="stat-lbl mb-1">إعادة الاستثمار</div><div className="stat-val" style={{ fontSize: 16 }}>{fmt(c?.reinvestment_cash ?? 0)}</div></div>
            <div className="stat-row" style={{ display: "block" }}><div className="stat-lbl mb-1">الإجمالي</div><div className="stat-val" style={{ fontSize: 16 }}>{fmt(c?.total_cash ?? 0)}</div></div>
          </div>
          <p className="text-xs font-bold text-slate-400 mb-2">آخر الحركات</p>
          {history.length === 0 ? <Empty label="لا توجد حركات سيولة مسجلة بعد" /> : (
            <div className="space-y-1 max-h-64 overflow-auto">
              {history.map((h: any, i: number) => (
                <div key={i} className="flex items-center justify-between gap-2 px-3 py-2 rounded-xl" style={{ background: "var(--surface-2, #0a1020)" }}>
                  <div>
                    <div className="text-xs text-white font-semibold">{h.label}{h.company ? ` — ${h.company}` : ""}</div>
                    <div className="text-[11px] text-slate-500">{h.date ? new Date(h.date).toLocaleDateString("en-GB") : "—"}</div>
                  </div>
                  <span className={"text-sm font-bold " + (h.amount >= 0 ? "profit" : "loss")}>{h.amount >= 0 ? "+" : ""}{fmt(h.amount)}</span>
                </div>
              ))}
            </div>
          )}
        </DetailModal>
      )}
    </>
  );
};
const CompaniesW = () => { const { data: h = [] } = useHoldings(); return <StatWidget label="عدد الشركات" value={String(h.length)} sub="شركات" icon={Building2} ic="ic-v" color="#a78bfa" />; };

/* ── Wealth banner ── */
function WealthW() {
  const { data: s } = useSummary();
  const { data: c } = useCash();
  const { data: h = [] } = useHoldings();
  const mv = s?.total_current_value ?? 0, inv = s?.total_cost ?? 0;
  const u = mv - inv, up = u >= 0;
  const cash = c?.available_cash ?? c?.total_cash ?? 0;

  const compliantValue = h.reduce((a: number, x: any) => a + (x.company?.sharia_status === "COMPLIANT" ? (x.current_value || 0) : 0), 0);
  const compliancePct = mv > 0 ? Math.round(compliantValue / mv * 100) : null;

  return (
    <div className="wealth h-full" style={{padding: "16px 24px"}}>
      <div>
        <div className="wealth-lbl">إجمالي الثروة</div>
        <div className="wealth-val" style={{fontSize: 28}}>{fmt(mv + cash)}</div>
        <div className={"wealth-ch" + (up ? "" : " neg")}>
          {up ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
          {(up ? "+" : "")}{fmt(u)} أرباح غير محققة
        </div>
        <div className="wealth-badges">
          <span className="wb wb-b">{h.length} شركات</span>
          {compliancePct != null && <span className="wb wb-g">{compliancePct}% متوافقة شرعياً</span>}
        </div>
      </div>
      <div className="text-start">
        <div className="roi-lbl">العائد الكلي</div>
        <div className={"roi-val" + (up ? "" : " neg")} style={{fontSize: 24}}>{fmtPct(inv ? u / inv * 100 : 0)}</div>
      </div>
    </div>
  );
}

/* ── Portfolio Health — verdict from company financial/technical analysis,
   NOT from paper profit/loss. Diverging bar centred on 50. ── */
/* Portfolio evaluation bar — lives in the AI page, below the companies table.
   No verdict/decision text on purpose: just the score and a visual bar that
   starts at the centre and leans toward green or red. Based purely on the
   held companies' financial/technical analysis, never on paper P&L. */
export function PortfolioHealthW() {
  const { data: h } = useHealth();

  if (!h || h.verdict === "NO_DATA") {
    return (
      <div className="flex flex-col">
        <Empty label={h?.label || "لا توجد بيانات تحليل كافية بعد"} />
      </div>
    );
  }

  const score = h.health_score as number;
  const good = score >= 50;
  const color = good ? "#10b981" : "#f43f5e";

  // Diverging bar: track centred at 50; fill grows from the midpoint toward the score.
  const dev = Math.max(-50, Math.min(50, score - 50));  // -50..+50
  const fillPct = Math.abs(dev) / 50 * 50;               // 0..50 (% of half-track)
  const fromLeft = dev >= 0 ? 50 : 50 - fillPct;

  return (
    <div className="flex flex-col">
      <div className="flex items-baseline gap-2 mb-4">
        <span className="text-2xl font-extrabold" style={{color}}>{score.toFixed(0)}</span>
        <span className="text-xs text-slate-500">/ 100 — بناءً على التحليل المالي والفني للشركات المختارة</span>
      </div>

      {/* Diverging visual bar — starts at the middle, leans toward green or red */}
      <div className="relative h-3 rounded-full overflow-hidden mb-2" style={{
        background: "linear-gradient(90deg, rgba(244,63,94,.16), rgba(148,163,184,.1) 50%, rgba(16,185,129,.16))",
      }}>
        <div className="absolute inset-y-0 rounded-full transition-all" style={{
          left: fromLeft + "%",
          width: fillPct + "%",
          background: color,
        }} />
        {/* centre tick */}
        <div className="absolute inset-y-0" style={{left: "50%", width: 2, background: "rgba(255,255,255,.35)"}} />
      </div>

      <p className="text-[11px] text-slate-500">
        مبني على {h.companies_scored} من {h.companies_total} شركة تم تحليلها ({h.coverage_pct}% تغطية)
      </p>
    </div>
  );
}

/* ── Tickers ── */
function TickerW({ id, label, prefix = "" }: { id: "tasi" | "brent" | "gold"; label: string; prefix?: string }) {
  const { data: o } = useOverview();
  const d = o?.[id];
  const up = (d?.change_pct ?? 0) >= 0;
  const colors: any = { tasi: "#34d399", brent: "#fbbf24", gold: "#fde047" };
  return (
    <div className="h-full flex flex-col justify-center px-1">
      <p className="ticker-lbl" style={{color: colors[id], marginBottom: 4}}>{label}</p>
      {d?.price ? (
        <>
          <p className="font-extrabold text-white text-xl leading-tight">{prefix}{fmt2(d.price)}</p>
          <p className="text-xs mt-0.5" style={{color: up ? "#34d399" : "#f87171"}}>{up ? "▲" : "▼"} {(up ? "+" : "")}{fmt2(d.change_pct)}%</p>
        </>
      ) : <Empty />}
    </div>
  );
}

/* ── Charts ── */
function PerfW() {
  // Real daily snapshots recorded automatically by the backend — never fabricated.
  const { data: hist = [] } = useQuery({
    queryKey: ["portfolio-history"],
    queryFn: () => portfolioApi.history().then(r => Array.isArray(r.data?.data) ? r.data.data : []),
  });
  const points = hist.filter((p: any) => (p.market_value || 0) > 0 || (p.invested_amount || 0) > 0);
  return (
    <div className="h-full flex flex-col">
      <p className="text-[13px] font-bold text-white mb-1">أداء المحفظة</p>
      {points.length >= 2 ? (
        <div className="flex-1 min-h-0" dir="ltr">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={points} margin={{ top: 6, right: 6, left: 0, bottom: 0 }}>
              <defs>
                <linearGradient id="perfMv" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#3b82f6" stopOpacity={0.35} />
                  <stop offset="100%" stopColor="#3b82f6" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(148,163,184,.12)" />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#64748b" }} tickFormatter={(d: string) => d.slice(5)} />
              <YAxis tick={{ fontSize: 10, fill: "#64748b" }} width={44} tickFormatter={(v: number) => fmt(v)} />
              <Tooltip
                contentStyle={{ background: "var(--pop)", border: "1px solid var(--line)", color: "var(--tip-text)", borderRadius: 10, fontSize: 12 }}
                formatter={(v: any, name: any) => [fmt2(v) + "", name === "market_value" ? "القيمة السوقية" : "المدفوع"]}
              />
              <Area type="monotone" dataKey="market_value" stroke="#3b82f6" strokeWidth={2} fill="url(#perfMv)" name="market_value" />
              <Area type="monotone" dataKey="invested_amount" stroke="#a78bfa" strokeWidth={1.5} strokeDasharray="4 3" fill="none" name="invested_amount" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      ) : points.length === 1 ? (
        <Empty label={`سُجلت أول لقطة (${points[0].date}) — يكتمل الرسم تلقائياً مع الأيام القادمة`} />
      ) : (
        <Empty label="لا توجد بيانات تاريخية بعد — تُبنى تلقائياً مع مرور الأيام" />
      )}
    </div>
  );
}

function SectorsW() {
  const { data: h = [] } = useHoldings();
  const data = buildSectorData(h.map((x: any) => ({ sector: x.company?.sector, value: x.current_value || 0 })));

  return (
    <div className="h-full flex flex-col">
      <p className="text-[13px] font-bold text-white mb-4 shrink-0">توزيع القطاعات</p>
      {data.length ? (
        <div className="flex-1 min-h-0">
          <SectorInfographic data={data} size={140} />
        </div>
      ) : <Empty />}
    </div>
  );
}

/* ── Goals / Summary ── */
function GoalsW() {
  const { data: goals = [] } = useQuery({
    queryKey: ["goals-progress"],
    queryFn: () => goalsApi.progress().then(r => Array.isArray(r.data?.data) ? r.data.data : []),
  });
  const grads = ["linear-gradient(90deg,#3b82f6,#6366f1)","linear-gradient(90deg,#8b5cf6,#d946ef)","linear-gradient(90deg,#10b981,#06b6d4)","linear-gradient(90deg,#f59e0b,#f43f5e)"];
  return (
    <div className="h-full flex flex-col overflow-auto">
      <p className="text-[13px] font-bold text-white mb-2 flex items-center gap-1.5"><Target size={13} className="text-emerald-400" /> الأهداف الاستثمارية</p>
      {goals.length ? goals.slice(0, 4).map((g: any, i: number) => {
        const pct = Math.min(100, ((g.current_value || 0) / (g.target_value || 1)) * 100);
        return (
          <div key={g.id} className="mb-2.5">
            <div className="flex justify-between text-xs mb-1">
              <span className="text-white font-semibold">{g.name}</span>
              <span className="font-bold" style={{color: COLORS[i % 4]}}>{pct.toFixed(0)}%</span>
            </div>
            <div className="h-1.5 bg-[#1a2540] rounded-full overflow-hidden">
              <div className="h-full rounded-full" style={{width: pct + "%", background: grads[i % 4]}} />
            </div>
          </div>
        );
      }) : <Empty />}
    </div>
  );
}

function SummaryW() {
  const { data: s } = useSummary();
  const { data: c } = useCash();
  const { data: h = [] } = useHoldings();
  const mv = s?.total_current_value ?? 0, inv = s?.total_cost ?? 0, u = mv - inv;
  const div = h.reduce((a: number, x: any) => a + (x.total_dividends_received || 0), 0);
  return (
    <div className="h-full flex flex-col overflow-auto">
      <p className="text-[13px] font-bold text-white mb-1">ملخص المحفظة</p>
      <div className="stat-row"><span className="stat-lbl">القيمة السوقية</span><span className="stat-val">{fmt(mv)}</span></div>
      <div className="stat-row"><span className="stat-lbl">المبلغ المستثمر</span><span className="stat-val">{fmt(inv)}</span></div>
      <div className="stat-row"><span className="stat-lbl">أرباح غير محققة</span><span className={"stat-val " + (u >= 0 ? "g" : "r")}>{(u >= 0 ? "+" : "")}{fmt(u)}</span></div>
      <div className="stat-row"><span className="stat-lbl">إجمالي التوزيعات</span><span className="stat-val g">+{fmt(div)}</span></div>
      <div className="stat-row"><span className="stat-lbl">السيولة</span><span className="stat-val">{fmt(c?.available_cash ?? 0)}</span></div>
    </div>
  );
}

/* ── Movers ── */
function MoverW({ dir }: { dir: 1 | -1 }) {
  const { data: h = [] } = useHoldings();
  const sorted = [...h].filter((x: any) => x.company).sort((a: any, b: any) => dir * ((b.unrealized_profit_pct || 0) - (a.unrealized_profit_pct || 0)));
  const top = sorted[0];
  const up = dir === 1;
  return (
    <div className="h-full flex flex-col justify-center px-1">
      <p className="mc-lbl flex items-center gap-1">{up ? <ArrowUp size={12} className="text-emerald-400" /> : <ArrowDown size={12} className="text-rose-400" />}{up ? "أكثر شركة ارتفاعاً" : "أكثر شركة انخفاضاً"}</p>
      {top ? (
        <>
          <p className="text-white font-bold text-sm mt-1">{top.company.name_ar || top.company.name} <span className="text-slate-500 text-xs">{top.company.symbol}</span></p>
          <p className="text-sm font-bold mt-0.5" style={{color: (top.unrealized_profit_pct || 0) >= 0 ? "#10b981" : "#f43f5e"}}>{fmtPct(top.unrealized_profit_pct || 0)}</p>
        </>
      ) : <Empty />}
    </div>
  );
}

/* ── News / Calendar / AI / Notifications ── */
function NewsW() {
  const { data: news = [] } = useQuery({ queryKey: ["market-news"], queryFn: () => marketApi.news().then(r => Array.isArray(r.data.data) ? r.data.data : []) });
  return (
    <div className="h-full flex flex-col overflow-hidden">
      <p className="text-[13px] font-bold text-white mb-2 flex items-center gap-1.5"><Newspaper size={13} className="text-amber-400" /> الأخبار {news.some((n: any) => n.source === "AI") && <span className="tag-v" style={{fontSize:10}}>AI</span>}</p>
      <div className="flex-1 overflow-auto space-y-2">
        {news.length ? news.map((n: any, i: number) => {
          const inner = (<div>
            <p className="text-[13px] font-semibold text-white leading-snug">{n.headline}</p>
            {(n.source || n.company) && <p className="text-[11px] text-slate-500 mt-1">{[n.source, n.company].filter(Boolean).join(" · ")}</p>}
          </div>);
          return n.url
            ? <a key={n.id ?? i} href={n.url} target="_blank" rel="noopener noreferrer" className="news-item hover:opacity-90 cursor-pointer" style={{borderColor: COLORS[i % 4], padding: 10}}>{inner}</a>
            : <div key={n.id ?? i} className="news-item" style={{borderColor: COLORS[i % 4], padding: 10}}>{inner}</div>;
        }) : <Empty />}
      </div>
    </div>
  );
}

function CalendarW() {
  const { data: events = [] } = useQuery({ queryKey: ["market-events"], queryFn: () => marketApi.events().then(r => Array.isArray(r.data.data) ? r.data.data : []) });
  return (
    <div className="h-full flex flex-col overflow-hidden">
      <p className="text-[13px] font-bold text-white mb-2 flex items-center gap-1.5"><CalendarDays size={13} className="text-purple-400" /> مفكرة الأسابيع القادمة {events.some((e: any) => e.source === "AI") && <span className="tag-v" style={{fontSize:10}}>AI</span>}</p>
      <div className="flex-1 overflow-auto space-y-2">
        {events.length ? events.map((e: any, i: number) => (
          <div key={e.id ?? i} className="flex items-start gap-2.5 p-2 bg-[#0a1020] rounded-lg">
            <div className="w-1.5 h-1.5 rounded-full mt-1.5 shrink-0" style={{background: COLORS[i % 4]}} />
            <div className="min-w-0">
              <p className="text-white text-xs font-semibold">{e.type}</p>
              <p className="text-slate-500 text-[11px]">{(lookupCompany(e.symbol)?.name_ar || e.company_name) ? `${lookupCompany(e.symbol)?.name_ar || e.company_name} (${e.symbol})` : e.symbol} · {e.date ? new Date(e.date).toLocaleDateString("en-GB") : "—"}</p>
            </div>
          </div>
        )) : <Empty />}
      </div>
    </div>
  );
}

function AiSummaryW() {
  const { data } = useQuery({ queryKey: ["ai-evaluation"], queryFn: () => aiApi.evaluation().then(r => r.data.data) });
  return (
    <div className="h-full flex flex-col overflow-hidden">
      <p className="text-[13px] font-bold text-white mb-2 flex items-center gap-1.5"><Sparkles size={13} className="text-amber-400" /> آخر تحليل AI <span className="tag-a ms-auto" style={{fontSize:10}}>دعم القرار فقط</span></p>
      <p className="text-xs text-slate-300 leading-relaxed overflow-auto">{data?.executive_summary || "لا يوجد تحليل بعد"}</p>
    </div>
  );
}

function EconomicNewsW() {
  const { data: news = [] } = useQuery({ queryKey: ["economic-news"], queryFn: () => marketApi.economicNews().then(r => Array.isArray(r.data.data) ? r.data.data : []) });
  const tone = (i: string) => i === "إيجابي" ? "#10b981" : i === "سلبي" ? "#f43f5e" : "#64748b";
  return (
    <div className="h-full flex flex-col overflow-hidden">
      <p className="text-[13px] font-bold text-white mb-2 flex items-center gap-1.5"><Newspaper size={13} className="text-amber-400" /> الأخبار الاقتصادية {news.some((n: any) => n.source === "AI") && <span className="tag-v ms-auto" style={{fontSize:10}}>AI</span>}</p>
      <div className="flex-1 overflow-auto space-y-2">
        {news.length ? news.map((n: any, i: number) => (
          <div key={n.id ?? i} className="news-item" style={{ borderColor: tone(n.impact) }}>
            <div className="flex-1">
              <div className="flex items-center gap-1.5 mb-0.5">
                {n.category && <span className="tag-n" style={{ fontSize: 9, padding: "1px 6px" }}>{n.category}</span>}
                {n.impact && <span style={{ fontSize: 10, color: tone(n.impact) }}>● {n.impact}</span>}
              </div>
              <p className="text-xs font-semibold text-white">{n.headline}</p>
            </div>
          </div>
        )) : <Empty />}
      </div>
    </div>
  );
}

function FeedstockW() {
  const { data } = useQuery({ queryKey: ["feedstock"], queryFn: () => marketApi.feedstock().then(r => r.data.data) });
  const items = data?.items ?? [];
  return (
    <div className="h-full flex flex-col overflow-hidden">
      <p className="text-[13px] font-bold text-white mb-2 flex items-center gap-1.5"><Coins size={13} className="text-orange-400" /> أسعار اللقيم</p>
      <div className="flex-1 overflow-auto space-y-1.5">
        {items.map((it: any, i: number) => (
          <div key={i} className="stat-row">
            <span className="stat-lbl">{it.name}</span>
            <span className="stat-val" dir="ltr">{it.price} <span className="text-slate-500 text-[10px]">{it.unit}</span></span>
          </div>
        ))}
      </div>
      {data?.note && <p className="text-[10px] text-slate-600 mt-1.5">{data.note}</p>}
    </div>
  );
}

function NotifsW() {
  const { data: notifs = [] } = useQuery({ queryKey: ["notifications"], queryFn: () => notificationsApi.list().then(r => Array.isArray(r.data.data) ? r.data.data : []) });
  return (
    <div className="h-full flex flex-col overflow-hidden">
      <p className="text-[13px] font-bold text-white mb-2 flex items-center gap-1.5"><Bell size={13} className="text-blue-400" /> التنبيهات</p>
      <div className="flex-1 overflow-auto space-y-2">
        {notifs.length ? notifs.slice(0, 6).map((n: any) => (
          <div key={n.id} className="notif" style={{borderColor: "#3b82f6", padding: 10}}>
            <div><p className="notif-title" style={{fontSize:12}}>{n.title}</p><p className="notif-msg" style={{fontSize:11}}>{n.message}</p></div>
          </div>
        )) : <Empty label="لا توجد تنبيهات حالياً" />}
      </div>
    </div>
  );
}

/* ── Notes: Market notebook + Portfolio notebook ── */
function NotesW({ scope, title }: { scope: "MARKET" | "PORTFOLIO"; title: string }) {
  const qc = useQueryClient();
  const [text, setText] = React.useState("");
  const [companyId, setCompanyId] = React.useState<number | "">("");
  const { data: holdings = [] } = useHoldings();
  const { data: notes = [] } = useQuery({
    queryKey: ["notes", scope],
    queryFn: () => notesApi.list(scope).then(r => Array.isArray(r.data.data) ? r.data.data : []),
  });
  const addM = useMutation({
    mutationFn: () => notesApi.add({
      scope, content: text,
      ...(scope === "PORTFOLIO" ? { company_id: Number(companyId) } : {}),
    }).then(r => r.data),
    onSuccess: () => { setText(""); qc.invalidateQueries({ queryKey: ["notes", scope] }); },
  });
  const delM = useMutation({
    mutationFn: (id: number) => notesApi.remove(id).then(r => r.data),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["notes", scope] }),
  });
  const canAdd = text.trim().length > 0 && (scope === "MARKET" || companyId !== "");

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <p className="text-[13px] font-bold text-white mb-2">{title}</p>
      <div className="flex gap-1.5 mb-2">
        {scope === "PORTFOLIO" && (
          <select className="input" style={{width: 110, padding: "6px 8px", fontSize: 11}}
            value={companyId} onChange={e => setCompanyId(e.target.value ? Number(e.target.value) : "")}>
            <option value="">الشركة…</option>
            {holdings.filter((h: any) => h.company).map((h: any) => (
              <option key={h.company.id} value={h.company.id}>{h.company.name_ar || h.company.name}</option>
            ))}
          </select>
        )}
        <input className="input" style={{padding: "6px 10px", fontSize: 12}} placeholder="أضف ملاحظة…"
          value={text} onChange={e => setText(e.target.value)}
          onKeyDown={e => e.key === "Enter" && canAdd && addM.mutate()} />
        <button className="btn-primary" style={{padding: "6px 12px"}} disabled={!canAdd || addM.isPending} onClick={() => addM.mutate()}>+</button>
      </div>
      <div className="flex-1 overflow-auto space-y-1.5">
        {notes.length ? notes.map((n: any) => (
          <div key={n.id} className="flex items-start gap-2 p-2 bg-[#0a1020] rounded-lg group">
            <div className="flex-1 min-w-0">
              {n.company && <span className="tag-b me-1" style={{fontSize: 9, padding: "1px 6px"}}>{n.company.symbol} {n.company.name}</span>}
              <span className="text-slate-300 text-xs">{n.content}</span>
            </div>
            <button className="text-slate-700 hover:text-red-400 opacity-0 group-hover:opacity-100 shrink-0" onClick={() => delM.mutate(n.id)}>×</button>
          </div>
        )) : <Empty label="لا توجد ملاحظات بعد" />}
      </div>
    </div>
  );
}

/* ── Registry ─────────────────────────────────────────────── */
export interface WidgetDef {
  id: string;
  title: string;
  component: React.ComponentType;
  defaultSize: { w: number; h: number; minW?: number; minH?: number };
}

export const WIDGETS: WidgetDef[] = [
  { id: "wealth",      title: "بانر الثروة",          component: WealthW,      defaultSize: { w: 12, h: 2, minW: 6, minH: 2 } },
  { id: "marketValue", title: "القيمة السوقية",       component: MarketValueW, defaultSize: { w: 2, h: 1 } },
  { id: "invested",    title: "إجمالي المدفوع",       component: InvestedW,    defaultSize: { w: 2, h: 1 } },
  { id: "unrealized",  title: "أرباح غير محققة",      component: UnrealizedW,  defaultSize: { w: 2, h: 1 } },
  { id: "dividends",   title: "توزيعات الأرباح",      component: DividendsW,   defaultSize: { w: 2, h: 1 } },
  { id: "liquidity",   title: "السيولة المتاحة",      component: LiquidityW,   defaultSize: { w: 2, h: 1 } },
  { id: "companies",   title: "عدد الشركات",          component: CompaniesW,   defaultSize: { w: 2, h: 1 } },
  { id: "tasi",        title: "تداول TASI",           component: () => <TickerW id="tasi" label="تداول TASI" />,  defaultSize: { w: 4, h: 1 } },
  { id: "brent",       title: "نفط برنت",             component: () => <TickerW id="brent" label="نفط برنت" prefix="" />, defaultSize: { w: 4, h: 1 } },
  { id: "gold",        title: "الذهب",                component: () => <TickerW id="gold" label="الذهب" prefix="" />,    defaultSize: { w: 4, h: 1 } },
  { id: "perf",        title: "أداء المحفظة",         component: PerfW,        defaultSize: { w: 6, h: 3, minW: 4, minH: 3 } },
  { id: "sectors",     title: "توزيع القطاعات",       component: SectorsW,     defaultSize: { w: 6, h: 3, minW: 4, minH: 3 } },
  { id: "goals",       title: "الأهداف الاستثمارية",  component: GoalsW,       defaultSize: { w: 6, h: 3, minW: 3, minH: 2 } },
  { id: "summary",     title: "ملخص المحفظة",         component: SummaryW,     defaultSize: { w: 6, h: 3, minW: 3, minH: 2 } },
  { id: "topGainer",   title: "أكثر شركة ارتفاعاً",   component: () => <MoverW dir={1} />,  defaultSize: { w: 3, h: 1 } },
  { id: "topLoser",    title: "أكثر شركة انخفاضاً",   component: () => <MoverW dir={-1} />, defaultSize: { w: 3, h: 1 } },
  { id: "news",        title: "الأخبار",              component: NewsW,        defaultSize: { w: 6, h: 4, minW: 4, minH: 3 } },
  { id: "economicNews",title: "الأخبار الاقتصادية",   component: EconomicNewsW, defaultSize: { w: 6, h: 4, minW: 4, minH: 3 } },
  { id: "feedstock",   title: "أسعار اللقيم",         component: FeedstockW,   defaultSize: { w: 4, h: 3, minW: 3, minH: 2 } },
  { id: "calendar",    title: "مفكرة الأسابيع القادمة", component: CalendarW,  defaultSize: { w: 5, h: 4, minW: 3, minH: 3 } },
  { id: "aiSummary",   title: "آخر تحليل AI",         component: AiSummaryW,   defaultSize: { w: 6, h: 2, minW: 4, minH: 2 } },
  { id: "notifs",      title: "التنبيهات",            component: NotifsW,      defaultSize: { w: 6, h: 3, minW: 4, minH: 2 } },
  { id: "marketNotes",    title: "مفكرة السوق",     component: () => <NotesW scope="MARKET" title="مفكرة السوق" />,       defaultSize: { w: 6, h: 3, minW: 4, minH: 2 } },
  { id: "portfolioNotes", title: "مفكرة المحفظة",   component: () => <NotesW scope="PORTFOLIO" title="مفكرة المحفظة" />, defaultSize: { w: 6, h: 3, minW: 4, minH: 2 } },
];

export const WIDGET_MAP: Record<string, WidgetDef> = Object.fromEntries(WIDGETS.map(w => [w.id, w]));
