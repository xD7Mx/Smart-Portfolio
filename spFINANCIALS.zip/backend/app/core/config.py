"""
Core application settings loaded from environment variables.
All sensitive values come from .env — never hardcoded.
"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # Application
    APP_NAME: str = "Smart Portfolio"
    APP_VERSION: str = "1.0.0"
    APP_ENV: str = "production"
    SECRET_KEY: str = "change_this"
    DEBUG: bool = False

    # Database
    DATABASE_URL: str = "postgresql://sp_user:password@db:5432/smart_portfolio"

    # AI
    AI_PROVIDER: str = "gemini"
    AI_MODEL: str = "gemini-3.5-flash"
    AI_API_KEY: Optional[str] = None
    AI_TEMPERATURE: float = 0.3
    AI_MAX_TOKENS: int = 4096
    AI_MEMORY_ENABLED: bool = True
    AI_ANALYSIS_SCHEDULE: str = "daily"

    # Market Data
    PRIMARY_MARKET_PROVIDER: str = "yahoo_finance"
    SECONDARY_MARKET_PROVIDER: str = "sahmak"
    YAHOO_FINANCE_ENABLED: bool = True
    SAHMAK_API_KEY: Optional[str] = None
    SAHMAK_BASE_URL: str = "https://app.sahmk.sa/api/v1"

    # Per-provider daily request caps (free-tier safe; override in .env)
    YAHOO_DAILY_LIMIT: int = 500
    SAHMAK_DAILY_LIMIT: int = 90     # free plan is 100/day — 10 kept as safety buffer
    GEMINI_DAILY_LIMIT: int = 1450  # free tier is 1500/day — 50 kept as safety buffer
    MARKET_UPDATE_INTERVAL_MINUTES: int = 15
    DAILY_API_LIMIT: int = 500

    # Telegram
    TELEGRAM_ENABLED: bool = False
    TELEGRAM_BOT_TOKEN: Optional[str] = None
    TELEGRAM_CHAT_ID: Optional[str] = None
    TELEGRAM_BOT_USERNAME: Optional[str] = None

    # Portfolio
    DEFAULT_CURRENCY: str = "SAR"
    DEFAULT_INSTALLMENTS: int = 5
    PORTFOLIO_MODE: str = "BUILD"

    # Backup
    BACKUP_ENABLED: bool = True
    BACKUP_FREQUENCY: str = "daily"
    BACKUP_RETENTION_DAYS: int = 30
    BACKUP_LOCATION: str = "/app/backups"

    # Security
    JWT_SECRET: str = "change_this_jwt_secret"
    JWT_EXPIRE_MINUTES: int = 1440

    # Scheduler
    SCHEDULER_ENABLED: bool = True

    class Config:
        env_file = ".env"
        case_sensitive = True


settings = Settings()
