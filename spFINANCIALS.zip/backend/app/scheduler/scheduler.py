"""
Smart Portfolio Scheduler
===========================
Manages all background jobs:
- Market price updates
- AI analysis
- Daily/weekly reports
- Backup
- Log cleanup
"""

from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from loguru import logger
from app.core.config import settings

_scheduler = AsyncIOScheduler()


# ─── Job Functions ────────────────────────────────────────────

async def job_update_market_prices():
    logger.info("📊 Scheduler: Updating market prices...")
    # TODO: Call MarketDataService.update_all_prices()


async def job_run_ai_analysis():
    """Daily automatic analysis — company scores + sharia, no button needed."""
    logger.info("🤖 Scheduler: Running automatic company analysis...")
    try:
        from app.core.database import AsyncSessionLocal
        from app.services.scores import refresh_company_scores
        from app.services.content_engine import warm_ai
        async with AsyncSessionLocal() as db:
            await refresh_company_scores(db)
            await warm_ai(db)  # Gemini artefacts regenerate automatically
    except Exception as e:
        logger.error(f"Automatic analysis failed: {e}")


async def job_generate_daily_report():
    """Refresh & persist market content (news/events/notifications) daily."""
    logger.info("📋 Scheduler: Refreshing market content...")
    try:
        from app.core.database import AsyncSessionLocal
        from app.services.content_engine import refresh_all
        async with AsyncSessionLocal() as db:
            await refresh_all(db)
    except Exception as e:
        logger.error(f"Content refresh failed: {e}")


async def job_backup():
    logger.info("💾 Scheduler: Running backup...")
    # TODO: Call BackupService.create()


async def job_cleanup_logs():
    logger.info("🧹 Scheduler: Cleaning old logs...")
    # TODO: Rotate logs older than 30 days


async def job_daily_snapshot():
    """Record the daily portfolio snapshot after Tadawul close."""
    logger.info("📸 Scheduler: Taking daily portfolio snapshot...")
    try:
        from app.core.database import AsyncSessionLocal
        from app.services.snapshots import take_snapshot
        async with AsyncSessionLocal() as db:
            await take_snapshot(db)
    except Exception as e:
        logger.error(f"Daily snapshot failed: {e}")


# ─── Scheduler Control ────────────────────────────────────────

def start_scheduler():
    if not settings.SCHEDULER_ENABLED:
        logger.info("⚠️ Scheduler is disabled.")
        return

    # Market price updates — every 15 min on weekdays 9:00–16:00
    _scheduler.add_job(
        job_update_market_prices,
        CronTrigger(minute="*/15", hour="9-16", day_of_week="mon-fri"),
        id="market_prices",
        replace_existing=True,
    )

    # AI analysis — weekdays at 18:00
    _scheduler.add_job(
        job_run_ai_analysis,
        CronTrigger(hour=18, day_of_week="mon-fri"),
        id="ai_analysis",
        replace_existing=True,
    )

    # Daily report — weekdays at 20:00
    _scheduler.add_job(
        job_generate_daily_report,
        CronTrigger(hour=20, day_of_week="mon-fri"),
        id="daily_report",
        replace_existing=True,
    )

    # Backup — daily at 02:00
    _scheduler.add_job(
        job_backup,
        CronTrigger(hour=2),
        id="backup",
        replace_existing=True,
    )

    # Log cleanup — weekly on Sunday at 03:00
    _scheduler.add_job(
        job_cleanup_logs,
        CronTrigger(hour=3, day_of_week="sun"),
        id="log_cleanup",
        replace_existing=True,
    )

    # Daily portfolio snapshot — 15:30 (after Tadawul close, container-local time)
    _scheduler.add_job(
        job_daily_snapshot,
        CronTrigger(hour=15, minute=30),
        id="daily_snapshot",
        replace_existing=True,
    )

    _scheduler.start()
    logger.info("✅ Scheduler started with 6 jobs.")


def stop_scheduler():
    if _scheduler.running:
        _scheduler.shutdown(wait=False)
        logger.info("🛑 Scheduler stopped.")


def get_scheduler():
    return _scheduler
