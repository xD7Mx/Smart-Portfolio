"""
Automatic company scoring — no manual "run analysis" button.

Runs at startup and on the daily scheduler: for every active company it
computes a finance score and a technical score and persists them, plus
sharia status and a logo from the Sahmak monthly library when available.
All inputs come through the cached provider layer, so a full pass costs
at most one call per company per cache window — quota-safe by
construction.

The finance score is derived from the SAME multi-year financial
statements shown on the company's governance page (get_financials) —
not a separate single-snapshot heuristic — so the score the AI assigns
is always explainable by the numbers the investor is actually looking
at, and reflects the company's balance-sheet safety from real risk, not
its share-price mood. See `_finance_score_from_periods` for the six
signals it weighs.
"""

from loguru import logger
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.portfolio import Company


def _clamp(v, lo=0, hi=100):
    return max(lo, min(hi, v))


# Heavy reinvestment threshold: capex at or above 8% of revenue is a
# capital-intensive spend, not routine maintenance — a reasonable general
# heuristic, not an industry-specific benchmark.
INVESTMENT_CAPEX_RATIO = 0.08


def is_investment_phase(periods: list) -> bool | None:
    """True when the company is plausibly funding real growth (heavy capex
    while revenue holds or grows) rather than distress-borrowing or a demand
    decline. Used to avoid unfairly penalizing rising debt or a profit dip
    that's really reinvestment, not weakness — but this is inferred from
    real capex/revenue data, never assumed. Returns None when there isn't
    enough data (capex or a prior year) to judge either way."""
    if not periods:
        return None
    latest = periods[-1]
    prev = periods[-2] if len(periods) >= 2 else None
    revenue = latest.get("revenue")
    capex = latest.get("capex")
    if not revenue or revenue <= 0 or capex is None or not prev or prev.get("revenue") is None:
        return None
    capex_ratio = abs(capex) / revenue
    revenue_holding = latest["revenue"] >= prev["revenue"]
    return capex_ratio >= INVESTMENT_CAPEX_RATIO and revenue_holding


def _finance_score_from_periods(periods: list) -> int | None:
    """Weighs six real, multi-year signals — every one traceable back to a
    row the investor sees in the financial statements table:

      revenue growth (20%)     — compound annual growth rate across every
                                  available year (falls back to a simple
                                  YoY change when only two years exist).
      earnings quality (20%)   — operating cash flow vs. net income,
                                  averaged across every year both are
                                  known; below 1 means profit isn't backed
                                  by cash ("paper profit").
      FCF margin (15%)         — free cash flow as a share of revenue,
                                  averaged across available years: cash the
                                  business actually generates after
                                  reinvestment, independent of accounting
                                  profit.
      ROE (20%)                — latest year's net income / equity.
      debt trend (15%)         — latest debt ratio, penalized further if it
                                  rose vs. the prior year.
      interest coverage (10%)  — latest EBIT / interest expense: the
                                  margin of safety before debt service
                                  becomes a real risk.

    Any signal whose inputs are missing is simply left out and the
    remaining signals are re-weighted — never a guessed number for a
    signal we can't actually compute. Returns None only if not a single
    signal could be computed (i.e. periods carries no usable figures)."""
    if not periods:
        return None
    latest = periods[-1]
    prev = periods[-2] if len(periods) >= 2 else None
    first = periods[0]
    signals: list[tuple[float, float]] = []

    if len(periods) >= 3 and first.get("revenue") and latest.get("revenue") and first["revenue"] > 0:
        n = len(periods) - 1
        cagr_pct = ((latest["revenue"] / first["revenue"]) ** (1 / n) - 1) * 100
        signals.append((_clamp(round(50 + cagr_pct * 2)), 0.20))
    elif prev and prev.get("revenue") and latest.get("revenue") is not None:
        growth_pct = (latest["revenue"] - prev["revenue"]) / abs(prev["revenue"]) * 100
        signals.append((_clamp(round(50 + growth_pct * 2)), 0.20))

    quality_ratios = [
        p["operating_cash_flow"] / p["net_income"]
        for p in periods
        if p.get("net_income") and p.get("operating_cash_flow") is not None and p["net_income"] != 0
    ]
    if quality_ratios:
        avg_ratio = sum(quality_ratios) / len(quality_ratios)
        signals.append((_clamp(round(50 + (avg_ratio - 1) * 40)), 0.20))

    fcf_margins = [
        p["free_cash_flow"] / p["revenue"] * 100
        for p in periods
        if p.get("revenue") and p["revenue"] > 0 and p.get("free_cash_flow") is not None
    ]
    if fcf_margins:
        avg_margin = sum(fcf_margins) / len(fcf_margins)
        signals.append((_clamp(round(50 + avg_margin * 2.5)), 0.15))

    if latest.get("net_income") is not None and latest.get("equity"):
        roe_pct = latest["net_income"] / latest["equity"] * 100
        signals.append((_clamp(round(40 + roe_pct * 2)), 0.20))

    if latest.get("debt_ratio") is not None:
        debt_score = _clamp(round(100 - latest["debt_ratio"] * 100))
        if prev and prev.get("debt_ratio") is not None:
            delta = latest["debt_ratio"] - prev["debt_ratio"]
            # Debt-funded expansion (heavy capex, revenue still holding) is a
            # materially different risk than debt taken on to cover a
            # shrinking business — so a rising ratio is penalized less
            # harshly when it looks investment-driven, not eliminated.
            penalty_factor = 0.4 if (delta > 0 and is_investment_phase(periods)) else 1.0
            debt_score = _clamp(round(debt_score - delta * 100 * penalty_factor))
        signals.append((debt_score, 0.15))

    if latest.get("interest_coverage") is not None:
        signals.append((_clamp(round(40 + latest["interest_coverage"] * 4)), 0.10))

    if not signals:
        return None
    total_w = sum(w for _, w in signals)
    return round(sum(s * w for s, w in signals) / total_w)


async def refresh_company_scores(db: AsyncSession) -> int:
    from app.services.market_data import market_service
    from app.services import sahmak_library
    from app.api.v1.endpoints.holdings import yahoo_symbol

    companies = (
        await db.execute(select(Company).where(Company.status != "ARCHIVED"))
    ).scalars().all()
    updated = 0
    for c in companies:
        try:
            sym = yahoo_symbol(c.symbol)
            price = await market_service.get_price(sym)
            financials = await market_service.get_financials(sym)

            finance = _finance_score_from_periods((financials or {}).get("periods") or [])
            if finance is not None:
                c.finance_score = finance
            if price:
                chg = price.get("change_pct") or 0
                c.technical_score = _clamp(round(55 + chg * 6))

            sharia = await sahmak_library.sharia_status(c.symbol)
            if sharia:
                c.sharia_status = sharia

            # Logo: resolved once per company from Sahmak's verified company
            # website, then never re-fetched (a logo doesn't change).
            if not c.logo_url:
                logo = await sahmak_library.company_logo_url(c.symbol)
                if logo:
                    c.logo_url = logo

            if finance is not None or price:
                updated += 1
        except Exception as e:
            logger.warning(f"score refresh failed for {c.symbol}: {e}")
    if updated:
        await db.commit()
        logger.info(f"Company scores refreshed for {updated} companies.")
    return updated
