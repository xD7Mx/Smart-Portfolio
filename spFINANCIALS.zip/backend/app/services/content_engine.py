"""
Content engine — makes the app never show an empty screen.

Uses Gemini to the fullest and PERSISTS the results to the database so they
stay stable (news/events don't vanish when the cache expires or a new event
happens). Runs on startup (if empty) and daily via the scheduler.

Persisted artefacts:
  • MarketNews    — company + macro economic news
  • MarketEvent   — forward calendar (earnings, dividends, meetings)
  • Notification  — portfolio-derived alerts (movers, target hit, dividends)
"""

from datetime import date, datetime, timezone, timedelta
from loguru import logger
from sqlalchemy import select, func
from sqlalchemy.ext.asyncio import AsyncSession

from app.models.market import (
    MarketNews, MarketEvent, MarketEventType, Notification,
    NotificationPriority,
)
from app.models.portfolio import Holding, Company
from app.services import cache


async def _portfolio_symbols(db: AsyncSession) -> list[str]:
    rows = await db.execute(select(Company.symbol).where(Company.status != "ARCHIVED"))
    return [r[0] for r in rows.all()]


async def _portfolio_names(db: AsyncSession) -> list[str]:
    rows = await db.execute(select(Company.company_name).where(Company.status != "ARCHIVED"))
    return [r[0] for r in rows.all() if r[0]]


async def _portfolio_symbol_names(db: AsyncSession) -> list[tuple[str, str]]:
    rows = await db.execute(select(Company.symbol, Company.company_name).where(Company.status != "ARCHIVED"))
    return [(r[0], r[1]) for r in rows.all() if r[1]]


async def refresh_news(db: AsyncSession, force: bool = False) -> int:
    """Fetch REAL current headlines from Yahoo (per symbol + macro), store new
    ones and keep the old — the feed stays live and never wipes. Falls back to
    a Gemini digest only if the real fetch returns nothing.

    Runs at most hourly unless forced, so it stays current without churn."""
    last = cache.get("news:refresh:ts")
    if last and not force:
        return 0
    cache.set("news:refresh:ts", datetime.now(timezone.utc).isoformat(), 60 * 60)

    # 1) real Arabic news (Google News RSS): market-wide + per-company + economic
    from app.services.news_fetcher import fetch_market_news, fetch_economic_news
    names = await _portfolio_names(db)
    real = (await fetch_market_news(names)) + (await fetch_economic_news())
    added = 0
    for it in real:
        headline = it.get("headline")
        if not headline:
            continue
        dup = (await db.execute(select(MarketNews.id).where(MarketNews.headline == headline))).scalar_one_or_none()
        if dup:
            continue
        db.add(MarketNews(
            provider=it.get("source") or "Google News",
            company_symbol=it.get("company"),
            headline=headline[:500],
            url=(it.get("url") or "")[:1000] or None,
            category=it.get("category"),
            importance="MEDIUM",
            published_at=it.get("published"),
        ))
        added += 1

    # 2) Gemini digest only if we still have nothing at all
    have_any = (await db.execute(select(func.count()).select_from(MarketNews))).scalar() or 0
    if not real and (have_any + added) == 0:
        from app.services.ai_content import market_news, economic_news
        symbols = await _portfolio_symbols(db)
        items = (await market_news(symbols)) + (await economic_news())
        for it in items:
            headline = it.get("headline")
            if not headline:
                continue
            dup = (await db.execute(select(MarketNews.id).where(MarketNews.headline == headline))).scalar_one_or_none()
            if dup:
                continue
            db.add(MarketNews(
                provider="AI", company_symbol=it.get("company") or it.get("symbol"),
                headline=headline[:500], category=it.get("category") or it.get("impact") or "أسواق",
                importance="MEDIUM", published_at=datetime.now(timezone.utc),
            ))
            added += 1

    if added:
        await db.commit()
        logger.info(f"Stored {added} news items (Google-News real-first).")
    return added


_EVENT_MAP = {
    "توزيع": MarketEventType.DIVIDEND, "توزيعات": MarketEventType.DIVIDEND,
    "نتائج": MarketEventType.RESULTS, "أرباح": MarketEventType.RESULTS,
    "جمعية": MarketEventType.OTHER, "اجتماع": MarketEventType.OTHER,
    "منحة": MarketEventType.BONUS, "تجزئة": MarketEventType.SPLIT,
}


def _event_type(text: str) -> MarketEventType:
    for k, v in _EVENT_MAP.items():
        if k in (text or ""):
            return v
    return MarketEventType.OTHER


async def refresh_events(db: AsyncSession, force: bool = False) -> int:
    """Forward calendar of corporate actions. Real-first: free Google News
    RSS announcements (dividends/rights issues/bonus shares/splits/AGMs) per
    portfolio company — never dependent solely on Gemini. Falls back to a
    Gemini-generated calendar only if the real fetch returns nothing."""
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    existing = (await db.execute(
        select(func.count()).select_from(MarketEvent).where(MarketEvent.created_at >= today_start)
    )).scalar() or 0
    if existing and not force:
        return 0

    added = 0

    # 1) Real announcements via free RSS.
    from app.services.news_fetcher import fetch_corporate_events
    pairs = await _portfolio_symbol_names(db)
    real = await fetch_corporate_events(pairs)
    for it in real:
        headline = it.get("headline")
        if not headline:
            continue
        edate = it.get("published")
        desc = headline[:300]
        dup = (await db.execute(select(MarketEvent.id).where(MarketEvent.description == desc))).scalar_one_or_none()
        if dup:
            continue
        db.add(MarketEvent(
            company_symbol=it.get("symbol"),
            event_type=_event_type(headline),
            description=desc,
            event_date=edate,
        ))
        added += 1

    # 2) Gemini forward calendar only if we still have nothing at all.
    have_any = (await db.execute(select(func.count()).select_from(MarketEvent))).scalar() or 0
    if not real and (have_any + added) == 0:
        from app.services.ai_content import upcoming_events
        symbols = await _portfolio_symbols(db)
        items = await upcoming_events(symbols)
        for it in items:
            etype = it.get("type", "")
            dstr = it.get("date")
            try:
                edate = datetime.fromisoformat(dstr).replace(tzinfo=timezone.utc) if dstr else None
            except Exception:
                edate = None
            desc = f"{etype} — {it.get('company_name') or it.get('symbol') or ''}".strip(" —")
            dup = (await db.execute(select(MarketEvent.id).where(MarketEvent.description == desc, MarketEvent.event_date == edate))).scalar_one_or_none()
            if dup:
                continue
            db.add(MarketEvent(
                company_symbol=it.get("symbol"),
                event_type=_event_type(etype),
                description=desc,
                event_date=edate,
            ))
            added += 1

    if added:
        await db.commit()
        logger.info(f"Stored {added} calendar events.")
    return added


async def generate_notifications(db: AsyncSession) -> int:
    """Derive real alerts from the current portfolio so the bell is never empty:
    big daily movers and analyst-target proximity. One batch per day."""
    today_start = datetime.now(timezone.utc).replace(hour=0, minute=0, second=0, microsecond=0)
    existing = (await db.execute(
        select(func.count()).select_from(Notification).where(Notification.created_at >= today_start)
    )).scalar() or 0
    if existing:
        return 0

    from sqlalchemy.orm import selectinload
    from app.services.market_data import market_service
    from app.api.v1.endpoints.holdings import yahoo_symbol, refresh_holdings_prices

    result = await db.execute(select(Holding).options(selectinload(Holding.company)))
    holdings = [h for h in result.scalars().all() if h.company and h.company.status != "ARCHIVED" and float(h.quantity or 0) > 0]
    await refresh_holdings_prices(db, holdings)

    added = 0
    for h in holdings:
        pnl_pct = float(h.unrealized_profit_pct or 0)
        name = h.company.company_name
        if pnl_pct >= 10:
            db.add(Notification(category="PORTFOLIO", priority=NotificationPriority.MEDIUM,
                title=f"{name}: مكسب غير محقق قوي",
                message=f"مركزك في {name} ({h.company.symbol}) رابح بنسبة {pnl_pct:.1f}% — قد يستحق مراجعة."))
            added += 1
        elif pnl_pct <= -8:
            db.add(Notification(category="PORTFOLIO", priority=NotificationPriority.HIGH,
                title=f"{name}: تراجع ملحوظ",
                message=f"مركزك في {name} ({h.company.symbol}) متراجع بنسبة {pnl_pct:.1f}% — راجع أطروحتك الاستثمارية."))
            added += 1
        # analyst target proximity
        info = await market_service.get_company_info(yahoo_symbol(h.company.symbol)) or {}
        tgt = info.get("target_mean_price")
        lp = float(h.last_price or 0)
        if tgt and lp:
            upside = (tgt / lp - 1) * 100
            if upside >= 15:
                db.add(Notification(category="MARKET", priority=NotificationPriority.LOW,
                    title=f"{name}: فرصة محتملة",
                    message=f"متوسط تقدير المحللين {tgt:.2f} أعلى من السعر الحالي بنحو {upside:.0f}%."))
                added += 1
    if added:
        await db.commit()
        logger.info(f"Generated {added} notifications.")
    return added


async def warm_ai(db: AsyncSession) -> None:
    """Proactively generate every Gemini artefact (evaluation, risk, full
    report, market brief) so the AI works automatically — the user never has
    to open a page to trigger it. Each call is internally cached (6-24h), so
    this costs a handful of Gemini requests per day, fully automatic."""
    from app.core.config import settings
    if not settings.AI_API_KEY:
        return
    try:
        from app.api.v1.endpoints.ai import _portfolio_snapshot
        from app.services.ai_content import (
            portfolio_evaluation, portfolio_risk, portfolio_report, market_brief,
        )
        holdings, cash = await _portfolio_snapshot(db)
        if holdings:
            await portfolio_evaluation(holdings, cash)
            await portfolio_risk(holdings, cash)
            await portfolio_report(holdings, cash)

        from app.services.market_data import market_service
        import asyncio as _aio
        tasi, brent, gold = await _aio.gather(
            market_service.get_price("^TASI.SR"),
            market_service.get_price("BZ=F"),
            market_service.get_price("GC=F"),
        )
        rows = (await db.execute(
            select(MarketNews).order_by(MarketNews.published_at.desc().nullslast()).limit(6)
        )).scalars().all()
        await market_brief(tasi, brent, gold, [n.headline for n in rows])
        logger.info("AI artefacts warmed (evaluation/risk/report/brief).")
    except Exception as e:
        logger.warning(f"AI warm-up partial failure: {e}")


async def refresh_all(db: AsyncSession) -> None:
    """Run everything — safe to call on startup and daily."""
    try:
        await refresh_news(db)
        await refresh_events(db)
        await generate_notifications(db)
        await warm_ai(db)
    except Exception as e:
        logger.warning(f"content refresh partial failure: {e}")
