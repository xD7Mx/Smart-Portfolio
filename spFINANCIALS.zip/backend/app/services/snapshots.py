"""
Daily portfolio snapshots — real performance history that accumulates
day by day. One row per calendar day (upsert on re-run).
"""

import logging
from datetime import date

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.models.portfolio import Holding, PortfolioSnapshot
from app.models.transaction import Cash

logger = logging.getLogger(__name__)


async def take_snapshot(db: AsyncSession) -> PortfolioSnapshot:
    """Compute today's portfolio totals (with fresh cached prices) and
    upsert the daily snapshot row."""
    result = await db.execute(select(Holding).options(selectinload(Holding.company)))
    holdings = result.scalars().all()

    from app.api.v1.endpoints.holdings import refresh_holdings_prices
    await refresh_holdings_prices(db, holdings)

    market_value = sum(float(h.market_value or 0) for h in holdings)
    invested = sum(float(h.invested_amount or 0) for h in holdings)
    unrealized = market_value - invested

    cash_row = (await db.execute(select(Cash).limit(1))).scalar_one_or_none()
    cash = float(cash_row.available_cash or 0) if cash_row else 0.0

    today = date.today()
    snap = (
        await db.execute(
            select(PortfolioSnapshot).where(PortfolioSnapshot.snapshot_date == today)
        )
    ).scalar_one_or_none()
    if not snap:
        snap = PortfolioSnapshot(snapshot_date=today)
        db.add(snap)

    snap.market_value = market_value
    snap.invested_amount = invested
    snap.cash_balance = cash
    snap.unrealized_profit = unrealized
    await db.commit()
    logger.info("Snapshot %s: mv=%.2f invested=%.2f cash=%.2f", today, market_value, invested, cash)
    return snap


async def snapshot_if_missing_today(db: AsyncSession) -> None:
    """Startup guard: take a snapshot only if there is none for today."""
    exists = (
        await db.execute(
            select(PortfolioSnapshot.id).where(PortfolioSnapshot.snapshot_date == date.today())
        )
    ).scalar_one_or_none()
    if exists is None:
        await take_snapshot(db)
