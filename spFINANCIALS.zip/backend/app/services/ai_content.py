"""
AI-generated market content (news digest + upcoming-events calendar).

There is no paid news feed connected, so Gemini generates an Arabic digest of the
Saudi market and a forward-looking calendar. Results are cached (12h news / 24h
events) so this costs a handful of Gemini calls per day, not per page view.
Items are flagged source="AI" so the UI can label them as AI-generated.
"""

import json
import httpx
from datetime import date
from loguru import logger
from app.core.config import settings
from app.services import cache

NEWS_TTL = 12 * 60 * 60     # twice a day is plenty for a digest
EVENTS_TTL = 24 * 60 * 60   # calendar changes slowly


def _extract_json(text: str):
    """Gemini often wraps JSON in ```json fences — strip them robustly."""
    t = text.strip()
    if t.startswith("```"):
        parts = t.split("```")
        t = parts[1] if len(parts) > 1 else t
        if t.lstrip().startswith("json"):
            t = t.lstrip()[4:]
    start = t.find("[")
    end = t.rfind("]")
    if start != -1 and end != -1:
        t = t[start:end + 1]
    return json.loads(t)


async def _generate(prompt: str, cache_key: str, ttl: int) -> list:
    cached = cache.get(cache_key)
    if cached is not None:
        return cached
    if not settings.AI_API_KEY:
        return []
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{settings.AI_MODEL}:generateContent?key={settings.AI_API_KEY}"
    )
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.4, "maxOutputTokens": 2048},
    }
    try:
        async with httpx.AsyncClient(timeout=40) as client:
            r = await client.post(url, json=body)
        if r.status_code != 200:
            logger.warning(f"AI content: HTTP {r.status_code} — {r.text[:150]}")
            return []
        text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
        items = _extract_json(text)
        if isinstance(items, list) and items:
            for i, it in enumerate(items):
                it.setdefault("id", i + 1)
                it["source"] = "AI"
            cache.set(cache_key, items, ttl)
            return items
    except Exception as e:
        logger.warning(f"AI content generation failed: {e}")
    return []


async def market_news(symbols: list[str]) -> list:
    today = date.today().isoformat()
    focus = "، مع تركيز خاص على: " + "، ".join(symbols[:10]) if symbols else ""
    prompt = f"""أنت محرر مالي سعودي. التاريخ اليوم {today}.
اكتب موجزاً من 6 عناوين إخبارية واقعية النبرة عن سوق الأسهم السعودية (تداول){focus}.
غطِّ: أداء مؤشر تاسي، قطاع الطاقة، قطاع البنوك، وأخبار شركات كبرى.
أعد النتيجة بصيغة JSON فقط بدون أي شرح، مصفوفة من عناصر بهذا الشكل:
[{{"headline": "العنوان بالعربية", "company": "رمز الشركة أو TASI", "published": "{today}"}}]"""
    return await _generate(prompt, f"ai:news:{today}", NEWS_TTL)


async def market_brief(tasi: dict | None, brent: dict | None, gold: dict | None, headlines: list[str]) -> str | None:
    """A short Arabic brief about the Saudi market environment (TASI) up to the
    last close — NOT about the user's portfolio. Cached 6h."""
    today = date.today().isoformat()
    key = f"ai:brief:{today}"
    cached = cache.get(key)
    if cached is not None:
        return cached
    if not settings.AI_API_KEY:
        return None
    def line(name, d):
        if not d:
            return f"{name}: غير متاح"
        return f"{name}: {d.get('price')} ({d.get('change_pct', 0):+.2f}%)"
    ctx = "؛ ".join([line("مؤشر تاسي", tasi), line("برنت", brent), line("الذهب", gold)])
    news = ("\nأبرز العناوين:\n- " + "\n- ".join(headlines[:6])) if headlines else ""
    prompt = f"""أنت محلل أسواق سعودي. التاريخ {today}.
اكتب فقرة موجزة (3-4 جمل) عن بيئة السوق السعودي (تاسي) حتى آخر إغلاق، مستندة إلى هذه المعطيات:
{ctx}{news}
ركّز على حالة المؤشر وأثر النفط والعوامل العامة على السوق. لا تذكر محفظة المستخدم. أعد نصاً عربياً فقط بدون عناوين."""
    body = {"contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"temperature": 0.4, "maxOutputTokens": 512}}
    url = (f"https://generativelanguage.googleapis.com/v1beta/models/{settings.AI_MODEL}:generateContent?key={settings.AI_API_KEY}")
    try:
        async with httpx.AsyncClient(timeout=40) as client:
            r = await client.post(url, json=body)
        if r.status_code == 200:
            text = r.json()["candidates"][0]["content"]["parts"][0]["text"].strip()
            if text:
                cache.set(key, text, 6 * 60 * 60)
                return text
    except Exception as e:
        logger.warning(f"market_brief failed: {e}")
    return None


async def economic_news() -> list:
    """Macro news moving the Saudi market — rates, Fed, OPEC, foreign flows,
    IPOs, key indicators. Cached 12h (a few Gemini calls a day, not per view)."""
    today = date.today().isoformat()
    prompt = f"""أنت محرر اقتصادي متخصص في السوق السعودي. التاريخ اليوم {today}.
اكتب 6 عناوين إخبارية اقتصادية كلية مؤثرة على سوق الأسهم السعودية، تغطي:
قرارات الفائدة، اجتماعات الفيدرالي، أخبار أوبك والنفط، تدفقات الصناديق الأجنبية،
تغيّر نسب الملكية الأجنبية، الاكتتابات الجديدة، والمؤشرات الاقتصادية المهمة.
أعد النتيجة بصيغة JSON فقط بدون شرح، مصفوفة بهذا الشكل:
[{{"headline": "العنوان بالعربية", "category": "الفئة (فائدة/نفط/صناديق/اكتتاب/مؤشرات)", "impact": "إيجابي أو سلبي أو محايد", "published": "{today}"}}]"""
    return await _generate(prompt, f"ai:econ:{today}", NEWS_TTL)


async def upcoming_events(symbols: list[str]) -> list:
    today = date.today().isoformat()
    focus = "ركّز على هذه الشركات إن أمكن: " + "، ".join(symbols[:10]) if symbols else ""
    prompt = f"""أنت محرر مفكرة مالية للسوق السعودي. التاريخ اليوم {today}.
اكتب 6 مواعيد متوقعة للأسابيع الأربعة القادمة في سوق الأسهم السعودية:
(نتائج مالية ربعية، توزيعات أرباح، اجتماعات جمعيات عمومية، إفصاحات هيئة السوق). {focus}
أعد النتيجة بصيغة JSON فقط بدون أي شرح، مصفوفة بهذا الشكل:
[{{"type": "نوع الحدث", "symbol": "رمز الشركة أو السوق", "company_name": "اسم الشركة بالعربية", "date": "YYYY-MM-DD"}}]"""
    return await _generate(prompt, f"ai:events:{today}", EVENTS_TTL)


ANALYSIS_TTL = 24 * 60 * 60  # portfolio analysis refreshes daily


def _extract_json_obj(text: str):
    t = text.strip()
    if t.startswith("```"):
        parts = t.split("```")
        t = parts[1] if len(parts) > 1 else t
        if t.lstrip().startswith("json"):
            t = t.lstrip()[4:]
    start = t.find("{")
    end = t.rfind("}")
    if start != -1 and end != -1:
        t = t[start:end + 1]
    return json.loads(t)


async def _generate_obj(prompt: str, cache_key: str, ttl: int) -> dict | None:
    cached = cache.get(cache_key)
    if cached is not None:
        return cached
    if not settings.AI_API_KEY:
        return None
    url = (
        f"https://generativelanguage.googleapis.com/v1beta/models/"
        f"{settings.AI_MODEL}:generateContent?key={settings.AI_API_KEY}"
    )
    body = {
        "contents": [{"parts": [{"text": prompt}]}],
        "generationConfig": {"temperature": 0.3, "maxOutputTokens": 2048},
    }
    try:
        async with httpx.AsyncClient(timeout=40) as client:
            r = await client.post(url, json=body)
        if r.status_code != 200:
            logger.warning(f"AI analysis: HTTP {r.status_code} — {r.text[:150]}")
            return None
        text = r.json()["candidates"][0]["content"]["parts"][0]["text"]
        obj = _extract_json_obj(text)
        if isinstance(obj, dict) and obj:
            obj["source"] = "AI"
            cache.set(cache_key, obj, ttl)
            return obj
    except Exception as e:
        logger.warning(f"AI analysis generation failed: {e}")
    return None


def _portfolio_context(holdings: list[dict], cash: float) -> str:
    lines = [
        f"- {h['name']} ({h['symbol']}): {h['qty']:.0f} سهم، متوسط تكلفة {h['avg']:.2f}، "
        f"قيمة سوقية {h['mv']:.0f}، ربح/خسارة {h['pnl']:+.0f}، قطاع {h['sector'] or 'غير محدد'}"
        for h in holdings
    ]
    return "مكونات المحفظة:\n" + "\n".join(lines) + f"\nالسيولة النقدية المتاحة: {cash:.0f}"


async def portfolio_evaluation(holdings: list[dict], cash: float) -> dict | None:
    """Diversification/risk/performance scores + Arabic summary. Cached 24h."""
    if not holdings:
        return None
    ctx = _portfolio_context(holdings, cash)
    key = f"ai:eval:{date.today().isoformat()}:{len(holdings)}"
    prompt = f"""أنت مستشار محافظ استثمارية سعودي. حلّل المحفظة التالية:
{ctx}
أعد النتيجة بصيغة JSON فقط بدون أي شرح، كائن بهذا الشكل بالضبط:
{{"diversification_score": 0-100, "risk_score": 0-100, "performance_score": 0-100, "overall_score": 0-100,
"summary": "ملخص عربي من 3 جمل عن حالة المحفظة"}}"""
    return await _generate_obj(prompt, key, ANALYSIS_TTL)


async def portfolio_risk(holdings: list[dict], cash: float) -> dict | None:
    """Risk level + concrete Arabic risk items. Cached 24h."""
    if not holdings:
        return None
    ctx = _portfolio_context(holdings, cash)
    key = f"ai:risk:{date.today().isoformat()}:{len(holdings)}"
    prompt = f"""أنت محلل مخاطر مالية للسوق السعودي. حلّل مخاطر هذه المحفظة:
{ctx}
أعد النتيجة بصيغة JSON فقط بدون أي شرح، كائن بهذا الشكل بالضبط:
{{"overall_risk_level": "LOW أو MEDIUM أو HIGH",
"summary": "ملخص عربي من جملتين",
"risks": [{{"description": "وصف الخطر بالعربية"}}]}}
اذكر 3 إلى 5 مخاطر ملموسة (تركّز، قطاع واحد، سيولة، تقلب...)."""
    return await _generate_obj(prompt, key, ANALYSIS_TTL)


async def portfolio_report(holdings: list[dict], cash: float) -> dict | None:
    """Comprehensive Arabic portfolio report. Cached 24h."""
    if not holdings:
        return None
    ctx = _portfolio_context(holdings, cash)
    key = f"ai:report:{date.today().isoformat()}:{len(holdings)}"
    prompt = f"""أنت خبير استثمار سعودي. اكتب تقريراً شاملاً عن هذه المحفظة:
{ctx}
أعد النتيجة بصيغة JSON فقط بدون أي شرح، كائن بهذا الشكل:
{{"content": "تقرير عربي منسق من 5 فقرات: نظرة عامة، التوزيع القطاعي، الأداء، التوصيات العامة، خلاصة. افصل الفقرات بسطر فارغ. اختم بعبارة أن القرار النهائي بيد المستثمر"}}"""
    return await _generate_obj(prompt, key, ANALYSIS_TTL)
