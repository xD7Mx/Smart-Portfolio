"""
Market Data Integration Layer — Smart Portfolio
==================================================
Adapter pattern: isolates external providers from the rest of the system.
Provider can be swapped from Settings without touching any other code.

Supported providers:
- Yahoo Finance (primary)
- Sahmak (secondary / Saudi market)
"""

from typing import Optional, List
import yfinance as yf
import httpx
from loguru import logger
from app.core.config import settings


# ─── Unified Price Model ──────────────────────────────────────

class PriceData:
    def __init__(self, symbol: str, price: float, change: float, change_pct: float, volume: float = 0):
        self.symbol = symbol
        self.price = price
        self.change = change
        self.change_pct = change_pct
        self.volume = volume

    def to_dict(self):
        return {
            "symbol": self.symbol,
            "price": self.price,
            "change": self.change,
            "change_pct": self.change_pct,
            "volume": self.volume,
        }


# ─── Yahoo Finance Adapter ────────────────────────────────────

class YahooFinanceAdapter:
    """
    Wraps yfinance to provide a consistent interface.
    """
    name = "yahoo_finance"

    async def get_price(self, symbol: str) -> Optional[PriceData]:
        from app.services.usage_tracker import record, can_call
        from app.services import cache

        # Serve from cache if fetched within the last 15 min — no provider call at all.
        ck = f"price:yahoo:{symbol}"
        cached = cache.get(ck)
        if cached is not None:
            return cached

        if not can_call("yahoo"):
            logger.warning("Yahoo: daily quota reached — skipping call to stay within free tier.")
            return None
        try:
            record("yahoo")
            # Direct call to Yahoo's public chart API — far more reliable than the
            # yfinance library. Falls back to query2 when query1 rate-limits (429).
            result = None
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
            async with httpx.AsyncClient(timeout=10, headers=headers) as client:
                for host in ("query1", "query2"):
                    try:
                        r = await client.get(
                            f"https://{host}.finance.yahoo.com/v8/finance/chart/{symbol}?range=1d&interval=1d"
                        )
                        if r.status_code == 200:
                            result = r.json().get("chart", {}).get("result")
                            if result:
                                break
                    except Exception:
                        continue
            if not result:
                return None
            meta = result[0].get("meta", {})
            price = meta.get("regularMarketPrice")
            prev = meta.get("chartPreviousClose") or meta.get("previousClose")
            if price is None:
                return None
            price = float(price)
            prev = float(prev) if prev else price
            change = price - prev
            change_pct = (change / prev * 100) if prev else 0
            data = PriceData(symbol, price, change, change_pct)
            cache.set(ck, data, cache.PRICE_TTL)
            return data
        except Exception as e:
            logger.warning(f"YahooFinance: failed for {symbol}: {e}")
            return None

    async def get_prices(self, symbols: List[str]) -> dict:
        results = {}
        for symbol in symbols:
            data = await self.get_price(symbol)
            if data:
                results[symbol] = data.to_dict()
        return results

    async def get_history(self, symbol: str, range_: str = "3mo") -> Optional[list]:
        """Daily close history for charts — cached 24h (one provider call per
        symbol per day at most)."""
        from app.services.usage_tracker import record, can_call
        from app.services import cache
        ck = f"hist:yahoo:{symbol}:{range_}"
        cached = cache.get(ck)
        if cached is not None:
            return cached
        if not can_call("yahoo"):
            return None
        try:
            record("yahoo")
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
            result = None
            async with httpx.AsyncClient(timeout=12, headers=headers) as client:
                for host in ("query1", "query2"):
                    try:
                        r = await client.get(
                            f"https://{host}.finance.yahoo.com/v8/finance/chart/{symbol}?range={range_}&interval=1d"
                        )
                        if r.status_code == 200:
                            result = r.json().get("chart", {}).get("result")
                            if result:
                                break
                    except Exception:
                        continue
            if not result:
                return None
            res = result[0]
            ts = res.get("timestamp") or []
            q = (res.get("indicators", {}).get("quote") or [{}])[0]
            closes = q.get("close") or []
            opens = q.get("open") or []
            highs = q.get("high") or []
            lows = q.get("low") or []
            vols = q.get("volume") or []
            from datetime import datetime, timezone
            def g(arr, i):
                v = arr[i] if i < len(arr) else None
                return round(float(v), 3) if v is not None else None
            points = []
            for i, t in enumerate(ts):
                c = g(closes, i)
                if c is None:
                    continue
                points.append({
                    "date": datetime.fromtimestamp(t, tz=timezone.utc).date().isoformat(),
                    "time": int(t),
                    "open": g(opens, i) if g(opens, i) is not None else c,
                    "high": g(highs, i) if g(highs, i) is not None else c,
                    "low": g(lows, i) if g(lows, i) is not None else c,
                    "close": c,
                    "volume": int(vols[i]) if i < len(vols) and vols[i] is not None else 0,
                })
            if points:
                cache.set(ck, points, cache.HISTORY_TTL)
            return points or None
        except Exception as e:
            logger.warning(f"YahooFinance history failed for {symbol}: {e}")
            return None

    # Yahoo quoteSummary now needs a cookie + crumb pair; we fetch it once and
    # reuse it (cached ~1h). This unlocks the full fundamentals + statements.
    async def _crumb(self):
        from app.services import cache
        c = cache.get("yahoo:crumb")
        if c is not None:
            return c
        try:
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
            async with httpx.AsyncClient(timeout=10, headers=headers, follow_redirects=True) as client:
                await client.get("https://fc.yahoo.com")  # sets consent cookies
                r = await client.get("https://query2.finance.yahoo.com/v1/test/getcrumb")
                if r.status_code == 200 and r.text and "<" not in r.text:
                    pair = (r.text.strip(), dict(client.cookies))
                    cache.set("yahoo:crumb", pair, 60 * 60)
                    return pair
        except Exception as e:
            logger.debug(f"Yahoo crumb fetch failed: {e}")
        return None

    async def _quote_summary(self, symbol: str, modules: str):
        """Raw quoteSummary result dict for the given modules (query1→query2)."""
        crumb = await self._crumb()
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        cookies = crumb[1] if crumb else {}
        params = f"modules={modules}&formatted=false"
        if crumb:
            params += f"&crumb={crumb[0]}"
        async with httpx.AsyncClient(timeout=14, headers=headers, cookies=cookies, follow_redirects=True) as client:
            for host in ("query1", "query2"):
                try:
                    r = await client.get(
                        f"https://{host}.finance.yahoo.com/v10/finance/quoteSummary/{symbol}?{params}"
                    )
                    if r.status_code == 200:
                        result = (r.json().get("quoteSummary", {}).get("result") or [None])[0]
                        if result:
                            return result
                except Exception:
                    continue
        return None

    async def get_dividends(self, symbol: str) -> Optional[dict]:
        """Dividend history (up to 10y) + inferred frequency + next ex/pay date.
        Cached 24h."""
        from app.services import cache
        from app.services.usage_tracker import record, can_call
        ck = f"div:yahoo:{symbol}"
        cached = cache.get(ck)
        if cached is not None:
            return cached
        if not can_call("yahoo"):
            return None
        from datetime import datetime, timezone
        history = []
        try:
            record("yahoo")
            headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
            async with httpx.AsyncClient(timeout=12, headers=headers, follow_redirects=True) as client:
                res = None
                for host in ("query1", "query2"):
                    try:
                        r = await client.get(f"https://{host}.finance.yahoo.com/v8/finance/chart/{symbol}?range=10y&interval=1mo&events=div")
                        if r.status_code == 200:
                            res = (r.json().get("chart", {}).get("result") or [None])[0]
                            if res:
                                break
                    except Exception:
                        continue
            if res:
                divs = (res.get("events", {}) or {}).get("dividends", {}) or {}
                for _, d in divs.items():
                    ts = d.get("date"); amt = d.get("amount")
                    if ts and amt:
                        dt = datetime.fromtimestamp(ts, tz=timezone.utc)
                        history.append({"date": dt.date().isoformat(), "year": dt.year, "amount": round(float(amt), 4)})
                history.sort(key=lambda x: x["date"])
        except Exception as e:
            logger.warning(f"Yahoo dividends failed for {symbol}: {e}")

        # frequency + next dates from quoteSummary
        ex_date = pay_date = None
        try:
            sq = await self._quote_summary(symbol, "summaryDetail,calendarEvents")
            if sq:
                sd = sq.get("summaryDetail", {})
                ce = sq.get("calendarEvents", {})
                def dt(v):
                    if isinstance(v, dict):
                        v = v.get("raw")
                    if isinstance(v, (int, float)):
                        return datetime.fromtimestamp(v, tz=timezone.utc).date().isoformat()
                    return None
                ex_date = dt(sd.get("exDividendDate"))
                pay_date = dt(ce.get("dividendDate"))
        except Exception:
            pass

        # infer frequency from per-year counts over the last 5 years
        from collections import Counter
        recent_years = [h["year"] for h in history if h["year"] >= (datetime.now().year - 5)]
        per_year = Counter(recent_years)
        counts = sorted(per_year.values())
        freq = None
        if counts:
            med = counts[len(counts) // 2]
            freq = {4: "ربع سنوي", 2: "نصف سنوي", 1: "سنوي", 3: "ثلاث مرات سنوياً"}.get(med, "غير منتظم")

        out = {"symbol": symbol, "history": history[-40:], "frequency": freq,
               "ex_date": ex_date, "pay_date": pay_date}
        if history or ex_date:
            cache.set(ck, out, 24 * 60 * 60)
        return out

    async def get_company_info(self, symbol: str) -> Optional[dict]:
        from app.services import cache
        from app.services.usage_tracker import record, can_call
        # Fundamentals barely change — cached for 30 days, so this hits the provider
        # at most once a month per company (matches how often the data actually updates).
        ck = f"fund:yahoo:{symbol}"
        cached = cache.get(ck)
        if cached is not None:
            return cached
        if not can_call("yahoo"):
            return None

        def _num(d, *path):
            cur = d
            for p in path:
                if not isinstance(cur, dict):
                    return None
                cur = cur.get(p)
            if isinstance(cur, dict):
                cur = cur.get("raw")
            return cur if isinstance(cur, (int, float)) else None

        try:
            record("yahoo")
            modules = ("financialData,defaultKeyStatistics,summaryDetail,price,"
                       "assetProfile,earnings")
            res = await self._quote_summary(symbol, modules)
            data = None
            if res:
                fd = res.get("financialData", {})
                ks = res.get("defaultKeyStatistics", {})
                sd = res.get("summaryDetail", {})
                pr = res.get("price", {})
                ap = res.get("assetProfile", {})
                pct = lambda v: round(v * 100, 2) if isinstance(v, (int, float)) else None
                data = {
                    "symbol": symbol,
                    "name": pr.get("longName") or pr.get("shortName"),
                    "sector": ap.get("sector"),
                    "industry": ap.get("industry"),
                    "market_cap": _num(pr, "marketCap") or _num(sd, "marketCap"),
                    "revenue": _num(fd, "totalRevenue"),
                    "net_income": _num(ks, "netIncomeToCommon"),
                    "ebitda": _num(fd, "ebitda"),
                    "eps": _num(ks, "trailingEps"),
                    "forward_eps": _num(ks, "forwardEps"),
                    "book_value": _num(ks, "bookValue"),
                    "price_to_book": _num(ks, "priceToBook"),
                    "operating_cash_flow": _num(fd, "operatingCashflow"),
                    "free_cash_flow": _num(fd, "freeCashflow"),
                    "total_cash": _num(fd, "totalCash"),
                    "total_debt": _num(fd, "totalDebt"),
                    "debt_to_equity": _num(fd, "debtToEquity"),
                    "gross_margin": pct(_num(fd, "grossMargins")),
                    "operating_margin": pct(_num(fd, "operatingMargins")),
                    "profit_margin": pct(_num(fd, "profitMargins")),
                    "roe": pct(_num(fd, "returnOnEquity")),
                    "roa": pct(_num(fd, "returnOnAssets")),
                    "revenue_growth": pct(_num(fd, "revenueGrowth")),
                    "earnings_growth": pct(_num(fd, "earningsGrowth")),
                    "pe_ratio": _num(sd, "trailingPE"),
                    "forward_pe": _num(sd, "forwardPE"),
                    "dividend_yield": pct(_num(sd, "dividendYield")),
                    "dividend_per_share": _num(sd, "dividendRate"),
                    "payout_ratio": pct(_num(sd, "payoutRatio")),
                    "beta": _num(sd, "beta"),
                    "week52_low": _num(sd, "fiftyTwoWeekLow"),
                    "week52_high": _num(sd, "fiftyTwoWeekHigh"),
                    "avg_volume": _num(sd, "averageVolume") or _num(sd, "averageDailyVolume3Month"),
                    "target_mean_price": _num(fd, "targetMeanPrice"),
                    "recommendation": fd.get("recommendationKey"),
                    "current_price": _num(fd, "currentPrice"),
                }

            # Fallback to yfinance if quoteSummary was blocked.
            if not data or not data.get("name"):
                def _fetch():
                    info = yf.Ticker(symbol).info
                    pctm = lambda k: round(info.get(k, 0) * 100, 2) if info.get(k) else None
                    return {
                        "symbol": symbol, "name": info.get("longName") or info.get("shortName"),
                        "sector": info.get("sector"), "industry": info.get("industry"),
                        "market_cap": info.get("marketCap"), "revenue": info.get("totalRevenue"),
                        "net_income": info.get("netIncomeToCommon"), "ebitda": info.get("ebitda"),
                        "eps": info.get("trailingEps"), "forward_eps": info.get("forwardEps"),
                        "book_value": info.get("bookValue"), "price_to_book": info.get("priceToBook"),
                        "operating_cash_flow": info.get("operatingCashflow"),
                        "free_cash_flow": info.get("freeCashflow"),
                        "total_cash": info.get("totalCash"), "total_debt": info.get("totalDebt"),
                        "debt_to_equity": info.get("debtToEquity"),
                        "gross_margin": pctm("grossMargins"), "operating_margin": pctm("operatingMargins"),
                        "profit_margin": pctm("profitMargins"), "roe": pctm("returnOnEquity"),
                        "roa": pctm("returnOnAssets"), "revenue_growth": pctm("revenueGrowth"),
                        "earnings_growth": pctm("earningsGrowth"), "pe_ratio": info.get("trailingPE"),
                        "forward_pe": info.get("forwardPE"), "dividend_yield": pctm("dividendYield"),
                        "dividend_per_share": info.get("dividendRate"), "payout_ratio": pctm("payoutRatio"),
                        "beta": info.get("beta"), "week52_low": info.get("fiftyTwoWeekLow"),
                        "week52_high": info.get("fiftyTwoWeekHigh"),
                        "avg_volume": info.get("averageVolume"),
                        "target_mean_price": info.get("targetMeanPrice"),
                        "recommendation": info.get("recommendationKey"),
                        "current_price": info.get("currentPrice"),
                    }
                import asyncio
                data = await asyncio.wait_for(asyncio.to_thread(_fetch), timeout=12)

            if data and data.get("name"):
                cache.set(ck, data, cache.FUNDAMENTALS_TTL)
                return data
        except Exception as e:
            logger.warning(f"YahooFinance company info failed for {symbol}: {e}")
        return None

    # Real endpoint (used internally by Yahoo's own site and by yfinance for
    # multi-year statements) that carries much deeper annual history than the
    # quoteSummary "incomeStatementHistory" module, which Yahoo has trimmed to
    # 1-2 periods for most Tadawul tickers. Each "type" comes back as its own
    # item in the result list; merged here by asOfDate (year).
    async def _fundamentals_timeseries(self, symbol: str, years: int = 4) -> list:
        import time
        types = [
            "annualTotalRevenue", "annualNetIncomeCommonStockholders", "annualNetIncome",
            "annualDilutedEPS", "annualBasicEPS",
            "annualStockholdersEquity", "annualTotalLiabilitiesNetMinorityInterest", "annualTotalAssets",
            "annualOperatingCashFlow", "annualCashAndCashEquivalents", "annualEndCashPosition",
            "annualCapitalExpenditure", "annualFreeCashFlow",
            "annualEBIT", "annualInterestExpense",
        ]
        crumb = await self._crumb()
        headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
        cookies = crumb[1] if crumb else {}
        period2 = int(time.time())
        period1 = period2 - years * 366 * 24 * 60 * 60
        params = {
            "symbol": symbol,
            "type": ",".join(types),
            "period1": period1,
            "period2": period2,
        }
        if crumb:
            params["crumb"] = crumb[0]
        by_year: dict[int, dict] = {}
        async with httpx.AsyncClient(timeout=14, headers=headers, cookies=cookies, follow_redirects=True) as client:
            for host in ("query2", "query1"):
                try:
                    r = await client.get(
                        f"https://{host}.finance.yahoo.com/ws/fundamentals-timeseries/v1/finance/timeseries/{symbol}",
                        params=params,
                    )
                    if r.status_code != 200:
                        continue
                    results = ((r.json().get("timeseries") or {}).get("result")) or []
                    if not results:
                        continue
                    for item in results:
                        for key, rows in item.items():
                            if key in ("meta",) or not isinstance(rows, list):
                                continue
                            for row in rows:
                                if not isinstance(row, dict):
                                    continue
                                date = row.get("asOfDate")
                                val = row.get("reportedValue")
                                val = val.get("raw") if isinstance(val, dict) else val
                                if not date or not isinstance(val, (int, float)):
                                    continue
                                year = int(str(date)[:4])
                                by_year.setdefault(year, {})[key] = val
                    if by_year:
                        break
                except Exception as e:
                    logger.debug(f"fundamentals-timeseries failed for {symbol} via {host}: {e}")
                    continue

        out = []
        for year, d in by_year.items():
            revenue = d.get("annualTotalRevenue")
            net_income = d.get("annualNetIncomeCommonStockholders") or d.get("annualNetIncome")
            equity = d.get("annualStockholdersEquity")
            total_liab = d.get("annualTotalLiabilitiesNetMinorityInterest")
            total_assets = d.get("annualTotalAssets")
            op_cf = d.get("annualOperatingCashFlow")
            capex = d.get("annualCapitalExpenditure")
            # FCF: prefer Yahoo's own reported figure; else derive from cash
            # generated by operations minus what was reinvested in capex
            # (capex is reported as a negative outflow, hence the addition).
            fcf = d.get("annualFreeCashFlow")
            if fcf is None and op_cf is not None and capex is not None:
                fcf = op_cf + capex
            ebit = d.get("annualEBIT")
            interest_expense = d.get("annualInterestExpense")
            out.append({
                "year": year,
                "revenue": revenue,
                "net_income": net_income,
                "eps": d.get("annualDilutedEPS") or d.get("annualBasicEPS"),
                "equity": equity,
                "debt_ratio": round(total_liab / total_assets, 2) if total_liab and total_assets else None,
                "operating_cash_flow": op_cf,
                "ending_cash": d.get("annualCashAndCashEquivalents") or d.get("annualEndCashPosition"),
                "capex": capex,
                "free_cash_flow": fcf,
                "interest_coverage": round(ebit / interest_expense, 2) if ebit and interest_expense else None,
            })
        out.sort(key=lambda p: p["year"])
        return out

    async def get_financials(self, symbol: str) -> Optional[dict]:
        """Multi-year income/balance/cashflow rows for the governance report —
        this IS the basis the AI score is derived from, so real multi-year
        depth matters here, not just the latest snapshot.

        Tries the deeper fundamentals-timeseries endpoint first (the same one
        Yahoo's own site and yfinance use for 3+ years of history); falls
        back to the shallower quoteSummary statement modules only if that
        returns nothing. Sahmak supplements any still-missing years when its
        plan includes /financials/ — merged by year, never overwriting a
        year Yahoo already has. Cached 30 days (statements only change
        quarterly)."""
        from app.services import cache
        from app.services.usage_tracker import record, can_call
        ck = f"stmt:{symbol}"
        cached = cache.get(ck)
        if cached is not None:
            return cached
        if not can_call("yahoo"):
            return None

        def _raw(d, *path):
            cur = d
            for p in path:
                if not isinstance(cur, dict):
                    return None
                cur = cur.get(p)
            if isinstance(cur, dict):
                cur = cur.get("raw")
            return cur if isinstance(cur, (int, float)) else None

        try:
            record("yahoo")
            deep_periods = await self._fundamentals_timeseries(symbol)
            if len(deep_periods) >= 2:
                for p in deep_periods:
                    p.setdefault("source", "yahoo")
                try:
                    from app.services import sahmak_library
                    have_years = {p["year"] for p in deep_periods}
                    extra = await sahmak_library.financial_periods(symbol)
                    for p in extra or []:
                        if p.get("year") and p["year"] not in have_years:
                            p.setdefault("source", "sahmak")
                            deep_periods.append(p)
                            have_years.add(p["year"])
                except Exception as e:
                    logger.debug(f"Sahmak financials supplement skipped for {symbol}: {e}")
                deep_periods.sort(key=lambda p: p["year"])
                out = {"symbol": symbol, "periods": deep_periods}
                cache.set(ck, out, cache.FUNDAMENTALS_TTL)
                return out

            res = await self._quote_summary(
                symbol,
                "incomeStatementHistory,balanceSheetHistory,cashflowStatementHistory,defaultKeyStatistics",
            )
            if not res:
                return None
            inc = res.get("incomeStatementHistory", {}).get("incomeStatementHistory", []) or []
            bal = res.get("balanceSheetHistory", {}).get("balanceSheetStatements", []) or []
            cf = res.get("cashflowStatementHistory", {}).get("cashflowStatements", []) or []

            def year(stmt):
                d = stmt.get("endDate", {})
                raw = d.get("raw") if isinstance(d, dict) else None
                if raw:
                    from datetime import datetime, timezone
                    return datetime.fromtimestamp(raw, tz=timezone.utc).year
                return None

            periods = []
            n = min(3, max(len(inc), len(bal), len(cf)))
            for i in range(n):
                inc_i = inc[i] if i < len(inc) else {}
                bal_i = bal[i] if i < len(bal) else {}
                cf_i = cf[i] if i < len(cf) else {}
                revenue = _raw(inc_i, "totalRevenue")
                net_income = _raw(inc_i, "netIncome")
                equity = _raw(bal_i, "totalStockholderEquity")
                total_liab = _raw(bal_i, "totalLiab")
                total_assets = _raw(bal_i, "totalAssets")
                op_cf = _raw(cf_i, "totalCashFromOperatingActivities")
                # EPS per statement period — present on some Tadawul symbols'
                # incomeStatementHistory, absent on others; left honestly None
                # rather than approximated from current shares outstanding.
                eps = _raw(inc_i, "dilutedEPS") or _raw(inc_i, "basicEPS")
                # Cash & equivalents at period end — a real balance-sheet line
                # (not derived), confirmed present as "cash" on Yahoo's
                # balanceSheetHistory statements.
                ending_cash = _raw(bal_i, "cash")
                capex = _raw(cf_i, "capitalExpenditures")
                fcf = (op_cf + capex) if (op_cf is not None and capex is not None) else None
                ebit = _raw(inc_i, "ebit")
                interest_expense = _raw(inc_i, "interestExpense")
                periods.append({
                    "year": year(inc_i) or year(bal_i) or year(cf_i),
                    "revenue": revenue,
                    "net_income": net_income,
                    "eps": eps,
                    "equity": equity,
                    "debt_ratio": round(total_liab / total_assets, 2) if total_liab and total_assets else None,
                    "operating_cash_flow": op_cf,
                    "ending_cash": ending_cash,
                    "capex": capex,
                    "free_cash_flow": fcf,
                    "interest_coverage": round(ebit / interest_expense, 2) if ebit and interest_expense else None,
                })
            periods = [p for p in periods if p["year"]]
            periods.sort(key=lambda p: p["year"])

            # Supplement the latest period when balance/cashflow modules were
            # empty (common for Tadawul symbols): derive from financialData +
            # defaultKeyStatistics so cells aren't blank.
            if periods and any(periods[-1].get(k) is None for k in ("equity", "debt_ratio", "operating_cash_flow", "eps", "ending_cash")):
                try:
                    sup = await self._quote_summary(symbol, "financialData,defaultKeyStatistics,price")
                    if sup:
                        fd = sup.get("financialData", {})
                        ks = sup.get("defaultKeyStatistics", {})
                        pr = sup.get("price", {})
                        last = periods[-1]
                        book = _raw(ks, "bookValue")
                        shares = _raw(ks, "sharesOutstanding") or _raw(pr, "sharesOutstanding")
                        total_debt = _raw(fd, "totalDebt")
                        if last.get("equity") is None and book and shares:
                            last["equity"] = round(book * shares)
                        if last.get("operating_cash_flow") is None:
                            last["operating_cash_flow"] = _raw(fd, "operatingCashflow")
                        if last.get("debt_ratio") is None and total_debt and last.get("equity"):
                            eq = last["equity"]
                            last["debt_ratio"] = round(total_debt / (total_debt + eq), 2) if (total_debt + eq) else None
                        if last.get("eps") is None:
                            last["eps"] = _raw(ks, "trailingEps")
                        if last.get("ending_cash") is None:
                            last["ending_cash"] = _raw(fd, "totalCash")
                except Exception:
                    pass

            for p in periods:
                p.setdefault("source", "yahoo")

            # Supplement missing earlier years from Sahmak, if a key is
            # configured — never touches a year Yahoo already covers.
            try:
                from app.services import sahmak_library
                have_years = {p["year"] for p in periods}
                extra = await sahmak_library.financial_periods(symbol)
                for p in extra or []:
                    if p.get("year") and p["year"] not in have_years:
                        p.setdefault("source", "sahmak")
                        periods.append(p)
                        have_years.add(p["year"])
            except Exception as e:
                logger.debug(f"Sahmak financials supplement skipped for {symbol}: {e}")

            periods.sort(key=lambda p: p["year"])

            if periods:
                out = {"symbol": symbol, "periods": periods}
                cache.set(ck, out, cache.FUNDAMENTALS_TTL)
                return out
        except Exception as e:
            logger.warning(f"YahooFinance financials failed for {symbol}: {e}")
        return None

    async def get_ownership(self, symbol: str) -> Optional[dict]:
        """Major-holders breakdown (insiders / institutions / public float)."""
        from app.services import cache
        from app.services.usage_tracker import record, can_call
        ck = f"own:yahoo:{symbol}"
        cached = cache.get(ck)
        if cached is not None:
            return cached
        if not can_call("yahoo"):
            return None
        try:
            record("yahoo")
            res = await self._quote_summary(symbol, "majorHoldersBreakdown")
            mh = (res or {}).get("majorHoldersBreakdown", {})
            def pct(k):
                v = mh.get(k)
                if isinstance(v, dict):
                    v = v.get("raw")
                return round(v * 100, 1) if isinstance(v, (int, float)) else None
            insiders = pct("insidersPercentHeld")
            institutions = pct("institutionsPercentHeld")
            if insiders is None and institutions is None:
                return None
            public = None
            if insiders is not None and institutions is not None:
                public = round(max(0.0, 100 - insiders - institutions), 1)
            out = {"insiders": insiders, "institutions": institutions, "public": public}
            cache.set(ck, out, cache.FUNDAMENTALS_TTL)
            return out
        except Exception as e:
            logger.warning(f"YahooFinance ownership failed for {symbol}: {e}")
        return None


# ─── Sahmak Adapter ───────────────────────────────────────────

class SahmakAdapter:
    """
    Adapter for the Sahmak Saudi market data provider.
    """
    name = "sahmak"

    def __init__(self):
        self.api_key = settings.SAHMAK_API_KEY
        self.BASE_URL = getattr(settings, "SAHMAK_BASE_URL", "https://sahmk.sa").rstrip("/")

    async def get_price(self, symbol: str) -> Optional[PriceData]:
        if not self.api_key:
            logger.warning("Sahmak: No API key configured.")
            return None
        from app.services.usage_tracker import record, can_call
        if not can_call("sahmak"):
            logger.warning("Sahmak: daily quota reached — skipping call to stay within free tier.")
            return None
        try:
            record("sahmak")
            base = symbol.replace(".SR", "")
            # Official Sahmk API: GET /quote/{symbol}/ (Free plan), X-API-Key auth.
            async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
                resp = await client.get(
                    f"{self.BASE_URL}/quote/{base}/",
                    headers={"X-API-Key": self.api_key, "Accept": "application/json"},
                )
                if resp.status_code == 200 and "json" in resp.headers.get("content-type", ""):
                    d = resp.json()
                    d = d.get("data", d)
                    price = d.get("price") or d.get("close") or d.get("last")
                    if price:
                        return PriceData(
                            symbol=symbol,
                            price=float(price),
                            change=float(d.get("change", 0) or 0),
                            change_pct=float(d.get("change_percent", d.get("change_pct", 0)) or 0),
                        )
        except Exception as e:
            logger.warning(f"Sahmak: failed for {symbol}: {e}")
        return None

    async def get_prices(self, symbols: List[str]) -> dict:
        results = {}
        for symbol in symbols:
            data = await self.get_price(symbol)
            if data:
                results[symbol] = data.to_dict()
        return results

    async def get_sharia_status(self, symbol: str) -> Optional[str]:
        """Best-effort Sharia lookup via GET /company/{symbol}/. Sahmk's public
        docs don't list a sharia field, so this reads it only if present in the
        (plan-dependent) company payload; otherwise returns None. The AI lookup
        is the primary source — this is a fallback only."""
        if not self.api_key:
            return None
        from app.services.usage_tracker import record, can_call
        if not can_call("sahmak"):
            logger.warning("Sahmak: daily quota reached — skipping Sharia lookup.")
            return None
        try:
            record("sahmak")
            base = symbol.replace(".SR", "")
            async with httpx.AsyncClient(timeout=10, follow_redirects=True) as client:
                resp = await client.get(
                    f"{self.BASE_URL}/company/{base}/",
                    headers={"X-API-Key": self.api_key, "Accept": "application/json"},
                )
                if resp.status_code == 200 and "json" in resp.headers.get("content-type", ""):
                    d = resp.json()
                    d = d.get("data", d) if isinstance(d, dict) else d
                    for key in ("sharia_compliant", "is_sharia_compliant", "shariah_compliant", "compliance_status", "sharia_status"):
                        if isinstance(d, dict) and key in d:
                            val = d[key]
                            if isinstance(val, bool):
                                return "COMPLIANT" if val else "NON_COMPLIANT"
                            if isinstance(val, str):
                                v = val.strip().lower()
                                if v in ("compliant", "yes", "true", "متوافق", "متوافقة"):
                                    return "COMPLIANT"
                                if v in ("non_compliant", "no", "false", "غير متوافق", "غير متوافقة"):
                                    return "NON_COMPLIANT"
        except Exception as e:
            logger.warning(f"Sahmak: sharia lookup failed for {symbol}: {e}")
        return None


# ─── Market Data Service (Router) ────────────────────────────

class MarketDataService:
    """
    Central market data service.
    Routes requests to the configured primary provider
    and falls back to secondary if needed.
    """

    def __init__(self):
        self.primary = self._create_adapter(settings.PRIMARY_MARKET_PROVIDER)
        self.secondary = self._create_adapter(settings.SECONDARY_MARKET_PROVIDER)

    def _create_adapter(self, name: str):
        if name == "yahoo_finance":
            return YahooFinanceAdapter()
        elif name == "sahmak":
            return SahmakAdapter()
        return YahooFinanceAdapter()

    async def get_price(self, symbol: str) -> Optional[dict]:
        from app.services.usage_tracker import remaining_fraction
        base = symbol.replace(".SR", "")
        saudi = base.isdigit()

        # Quota synergy: for Saudi tickers both providers can answer, so route
        # to whichever has more of its daily budget left. A provider under a
        # 15% reserve is only used when the other is fully spent — no single
        # key ever dies while the others sit idle.
        providers = [self.primary, self.secondary]
        if saudi:
            def budget(p):
                frac = remaining_fraction("sahmak" if isinstance(p, SahmakAdapter) else "yahoo")
                return (frac >= 0.15, frac)  # reserve floor first, then remaining share
            providers = sorted(providers, key=budget, reverse=True)
        else:
            # Sahmak only knows Saudi tickers; never burn its quota on
            # commodities/indices (BZ=F, GC=F, ^TASI...) it can't answer.
            providers = [p for p in providers if not isinstance(p, SahmakAdapter)]

        for p in providers:
            arg = base if (saudi and isinstance(p, SahmakAdapter)) else symbol
            data = await p.get_price(arg)
            if data:
                return data.to_dict()
        return None

    async def get_prices(self, symbols: List[str]) -> dict:
        return await self.primary.get_prices(symbols)

    def _yahoo(self):
        return self.primary if isinstance(self.primary, YahooFinanceAdapter) else YahooFinanceAdapter()

    async def get_company_info(self, symbol: str) -> Optional[dict]:
        if hasattr(self.primary, "get_company_info"):
            return await self.primary.get_company_info(symbol)
        return None

    async def get_history(self, symbol: str, range_: str = "3mo") -> Optional[list]:
        return await self._yahoo().get_history(symbol, range_)

    async def get_financials(self, symbol: str) -> Optional[dict]:
        return await self._yahoo().get_financials(symbol)

    async def get_ownership(self, symbol: str) -> Optional[dict]:
        return await self._yahoo().get_ownership(symbol)

    async def get_dividends(self, symbol: str) -> Optional[dict]:
        return await self._yahoo().get_dividends(symbol)


market_service = MarketDataService()
