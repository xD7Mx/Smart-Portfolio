"""
Rule-based portfolio analytics — computed entirely from the real holdings,
so the evaluation / risk / report screens are NEVER empty (they don't depend
on Gemini). Gemini is layered on top as an optional narrative when available.

Inputs: holdings = [{name, symbol, qty, avg, mv, pnl, pnl_pct, sector,
                     safety, valuation, upside}], cash.
"""

from typing import Optional


def _concentration(holdings: list[dict]):
    total = sum(h["mv"] for h in holdings) or 1
    weights = [(h, h["mv"] / total * 100) for h in holdings]
    weights.sort(key=lambda x: x[1], reverse=True)
    hhi = sum((w / 100) ** 2 for _, w in weights)  # 0..1
    top = weights[0] if weights else (None, 0)
    return weights, hhi, top, total


def _sector_weights(holdings: list[dict], total: float):
    sec: dict[str, float] = {}
    for h in holdings:
        s = h.get("sector") or "غير مصنّف"
        sec[s] = sec.get(s, 0) + h["mv"]
    return sorted(((s, v / (total or 1) * 100) for s, v in sec.items()), key=lambda x: x[1], reverse=True)


def evaluate(holdings: list[dict], cash: float) -> dict:
    holdings = [h for h in holdings if h.get("mv", 0) > 0]
    if not holdings:
        return {
            "diversification_score": 0, "risk_score": 0, "performance_score": 0,
            "overall_score": 0,
            "summary": "المحفظة فارغة — أضف شركات لتبدأ رؤية التقييم.",
            "source": "rule",
        }
    weights, hhi, top, total = _concentration(holdings)
    sectors = _sector_weights(holdings, total)
    n = len(holdings)

    # Diversification: more names + more sectors + lower concentration
    div = min(100, round((min(n, 12) / 12) * 55 + (1 - hhi) * 30 + (min(len(sectors), 6) / 6) * 15))
    # Performance: portfolio ROI
    invested = sum(h.get("avg", 0) * h.get("qty", 0) for h in holdings) or sum(h["mv"] for h in holdings)
    roi = ((total - invested) / invested * 100) if invested else 0
    perf = max(0, min(100, round(55 + roi)))
    # Risk score (higher = safer): penalise concentration + drawdowns
    losers = [h for h in holdings if h.get("pnl_pct", 0) <= -8]
    risk_score = max(0, min(100, round(80 - top[1] * 0.4 - len(losers) * 6 - (hhi * 40))))
    overall = round(div * 0.35 + perf * 0.3 + risk_score * 0.35)

    parts = [
        f"تضم المحفظة {n} شركة عبر {len(sectors)} قطاع.",
        f"أكبر مركز هو {top[0]['name']} بوزن {top[1]:.0f}% من المحفظة" + (" — تركيز مرتفع يستدعي الانتباه." if top[1] > 35 else "."),
        (f"العائد الإجمالي الحالي {roi:+.1f}%." if invested else ""),
        ("يوجد " + str(len(losers)) + " مركز متراجع بأكثر من 8%." if losers else "لا توجد مراكز متراجعة بشكل حاد."),
    ]
    return {
        "diversification_score": div,
        "risk_score": risk_score,
        "performance_score": perf,
        "overall_score": overall,
        "executive_summary": " ".join(p for p in parts if p),
        "summary": " ".join(p for p in parts if p),
        "source": "rule",
    }


def risk(holdings: list[dict], cash: float) -> dict:
    holdings = [h for h in holdings if h.get("mv", 0) > 0]
    if not holdings:
        return {"overall_risk_level": "UNKNOWN", "summary": "المحفظة فارغة.", "risks": [], "source": "rule"}
    weights, hhi, top, total = _concentration(holdings)
    sectors = _sector_weights(holdings, total)
    risks: list[dict] = []

    if top[1] >= 40:
        risks.append({"description": f"تركّز مرتفع جداً في {top[0]['name']} ({top[1]:.0f}% من المحفظة) — أي هبوط فيه يؤثر بقوة على المحفظة."})
    elif top[1] >= 25:
        risks.append({"description": f"تركّز ملحوظ في {top[0]['name']} ({top[1]:.0f}%) — فكّر في توزيع أوسع."})
    if sectors and sectors[0][1] >= 50:
        risks.append({"description": f"تركّز قطاعي: {sectors[0][1]:.0f}% من المحفظة في قطاع {sectors[0][0]} — مخاطرة قطاعية."})
    for h in holdings:
        if h.get("pnl_pct", 0) <= -12:
            risks.append({"description": f"{h['name']} متراجع {h['pnl_pct']:.0f}% — راجع أطروحتك الاستثمارية فيه."})
    for h in holdings:
        if h.get("safety") is not None and h["safety"] < 45:
            risks.append({"description": f"{h['name']}: درجة سلامة مالية ضعيفة — يتطلب مراقبة أوثق."})
    for h in holdings:
        if h.get("valuation") and "أعلى" in h["valuation"]:
            risks.append({"description": f"{h['name']}: مقيّم أعلى من قيمته العادلة حسب تقدير المحللين."})
    if len(holdings) < 4:
        risks.append({"description": f"عدد الشركات قليل ({len(holdings)}) — التنويع محدود ويزيد التقلب."})
    if (cash or 0) <= 0:
        risks.append({"description": "لا توجد سيولة نقدية — يقيّد اقتناص الفرص أو الشراء عند التصحيح."})

    # de-dupe & cap
    seen = set(); uniq = []
    for rr in risks:
        if rr["description"] not in seen:
            seen.add(rr["description"]); uniq.append(rr)
    uniq = uniq[:8] or [{"description": "لا توجد مخاطر بنيوية ظاهرة من البيانات الحالية — المحفظة متوازنة نسبياً."}]

    hi = sum(1 for r in uniq if any(k in r["description"] for k in ("مرتفع جداً", "متراجع", "ضعيفة")))
    level = "HIGH" if (top[1] >= 40 or hi >= 3) else "MEDIUM" if (top[1] >= 25 or hi >= 1) else "LOW"
    label = {"HIGH": "عالٍ", "MEDIUM": "متوسط", "LOW": "منخفض"}[level]
    summary = f"مستوى المخاطر العام: {label}. أبرز عامل هو {'التركّز' if top[1] >= 25 else 'تقلب المراكز' if hi else 'محدودية التنويع' if len(holdings) < 4 else 'مخاطر السوق العامة'}."
    return {"overall_risk_level": level, "summary": summary, "risks": uniq, "source": "rule"}


def report(holdings: list[dict], cash: float, metrics: dict) -> dict:
    holdings = [h for h in holdings if h.get("mv", 0) > 0]
    if not holdings:
        return {"content": "المحفظة فارغة حالياً — أضف شركات ليُبنى التقرير تلقائياً.", "source": "rule"}
    ev = evaluate(holdings, cash)
    rk = risk(holdings, cash)
    weights, hhi, top, total = _concentration(holdings)
    sectors = _sector_weights(holdings, total)
    mv = metrics.get("market_value", total)
    roi = metrics.get("roi_pct", 0)

    lines = []
    lines.append("نظرة عامة:")
    lines.append(f"القيمة السوقية للمحفظة {mv:,.0f} موزّعة على {len(holdings)} شركة و{len(sectors)} قطاع، والسيولة النقدية {cash:,.0f}.")
    lines.append("")
    lines.append("التوزيع القطاعي:")
    lines.append("، ".join(f"{s} {w:.0f}%" for s, w in sectors[:6]))
    lines.append("")
    lines.append("الأداء:")
    lines.append(f"العائد الإجمالي {roi:+.1f}%. درجة الأداء {ev['performance_score']}/100 والتنويع {ev['diversification_score']}/100.")
    lines.append("")
    lines.append("أبرز المخاطر:")
    for r in rk["risks"][:4]:
        lines.append("• " + r["description"])
    lines.append("")
    lines.append("خلاصة:")
    lines.append(ev["summary"] + " " + rk["summary"])
    lines.append("القرار النهائي يبقى بيد المستثمر — هذه قراءة آلية لدعم القرار لا توصية مُلزِمة.")
    return {"content": "\n".join(lines), "overall_score": ev["overall_score"], "source": "rule"}
