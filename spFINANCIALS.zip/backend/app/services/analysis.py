"""
Automatic company analysis engine.

Given a symbol it gathers price + full fundamentals + price history (all through
the cached provider layer), then computes — with no button and no user input —:
  • a financial score + Arabic verdict (قوي جداً / قوي / متوسط / ضعيف) with reasons
  • a technical score + verdict (from technical.py)
  • strengths / weaknesses derived from the real fundamentals
  • a combined AI score /100
  • an investment decision (شراء / تجميع / احتفاظ / تقليل / بيع)

Everything is rule-based, so it always produces a result whenever data exists —
Gemini is used only for an optional Arabic narrative on top. The whole analysis
is cached 24h so a page open costs no extra provider calls after the first.
"""

from typing import Optional
from app.services import cache

ANALYSIS_TTL = 24 * 60 * 60


def _financial(info: dict) -> dict:
    """Financial score/verdict from fundamentals."""
    score = 50
    reasons: list[str] = []
    strengths: list[str] = []
    weaknesses: list[str] = []

    roe = info.get("roe")
    margin = info.get("profit_margin")
    pe = info.get("pe_ratio")
    dy = info.get("dividend_yield")
    de = info.get("debt_to_equity")
    rev_growth = info.get("revenue_growth")
    fcf = info.get("free_cash_flow")

    if roe is not None:
        if roe >= 20:
            score += 14; strengths.append(f"عائد ممتاز على حقوق الملكية {roe:.0f}%")
        elif roe >= 12:
            score += 7; strengths.append(f"عائد جيد على حقوق الملكية {roe:.0f}%")
        elif roe < 6:
            score -= 8; weaknesses.append(f"عائد ضعيف على حقوق الملكية {roe:.0f}%")
    if margin is not None:
        if margin >= 20:
            score += 12; strengths.append(f"هامش ربح مرتفع {margin:.0f}%")
        elif margin >= 10:
            score += 5
        elif margin < 5:
            score -= 8; weaknesses.append(f"هامش ربح منخفض {margin:.0f}%")
    if pe is not None and pe > 0:
        if pe <= 15:
            score += 8; strengths.append(f"تقييم جذاب (مكرر ربحية {pe:.1f})")
        elif pe >= 30:
            score -= 8; weaknesses.append(f"مكرر ربحية مرتفع {pe:.1f}")
    if dy is not None and dy >= 3:
        score += 6; strengths.append(f"عائد توزيعات جيد {dy:.1f}%")
    if de is not None:
        if de >= 200:
            score -= 10; weaknesses.append("مديونية مرتفعة نسبةً لحقوق الملكية")
        elif de <= 50:
            score += 5; strengths.append("مديونية منخفضة")
    if rev_growth is not None:
        if rev_growth >= 10:
            score += 8; strengths.append(f"نمو إيرادات قوي {rev_growth:.0f}%")
        elif rev_growth < 0:
            score -= 6; weaknesses.append(f"تراجع الإيرادات {rev_growth:.0f}%")
    if fcf is not None and fcf > 0:
        score += 4; strengths.append("تدفق نقدي حر موجب")
    elif fcf is not None and fcf < 0:
        score -= 4; weaknesses.append("تدفق نقدي حر سالب")

    score = max(0, min(100, round(score)))
    verdict = ("قوي جداً" if score >= 80 else "قوي" if score >= 65
               else "متوسط" if score >= 45 else "ضعيف")
    return {"score": score, "verdict": verdict, "strengths": strengths, "weaknesses": weaknesses}


def _decision(overall: int, fin: dict, tech: Optional[dict]) -> dict:
    """Map the combined picture to a five-level investment decision."""
    tech_trend_up = bool(tech and tech.get("trend") == "صاعد")
    if overall >= 78 and tech_trend_up:
        label, color = "شراء", "#10b981"
    elif overall >= 65:
        label, color = "تجميع", "#22c55e"
    elif overall >= 48:
        label, color = "احتفاظ", "#f59e0b"
    elif overall >= 35:
        label, color = "تقليل", "#f97316"
    else:
        label, color = "بيع", "#f43f5e"
    return {"label": label, "color": color}


async def analyze_company(symbol: str, name: str | None = None) -> Optional[dict]:
    ck = f"analysis:{symbol}"
    cached = cache.get(ck)
    if cached is not None:
        return cached

    from app.services.market_data import market_service
    from app.services import technical

    price = await market_service.get_price(symbol)
    info = await market_service.get_company_info(symbol) or {}
    history = await market_service.get_history(symbol, "1y")

    if not price and not info and not history:
        return None

    fin = _financial(info)
    tech = technical.analyze(history) if history else None

    chg = (price or {}).get("change_pct", 0) or 0
    if chg > 0:
        fin["strengths"].append(f"زخم سعري إيجابي اليوم +{chg:.2f}%")
    elif chg < 0:
        fin["weaknesses"].append(f"ضغط سعري اليوم {chg:.2f}%")

    # Combined AI score: financial 60% + technical 40% (or 100% financial if no history)
    if tech:
        overall = round(fin["score"] * 0.6 + tech["score"] * 0.4)
    else:
        overall = fin["score"]
    decision = _decision(overall, fin, tech)

    strengths = fin["strengths"][:6] or ["بيانات مالية متاحة للتحليل"]
    weaknesses = fin["weaknesses"][:6]

    result = {
        "symbol": symbol,
        "name": name or info.get("name") or symbol,
        "sector": info.get("sector"),
        "industry": info.get("industry"),
        "price": (price or {}).get("price"),
        "change": (price or {}).get("change"),
        "change_pct": chg,
        "fundamentals": info,
        "financial": {"score": fin["score"], "verdict": fin["verdict"]},
        "technical": tech,
        "strengths": strengths,
        "weaknesses": weaknesses,
        "ai_score": overall,
        "score": overall,
        "decision": decision,
    }
    cache.set(ck, result, ANALYSIS_TTL)
    return result
