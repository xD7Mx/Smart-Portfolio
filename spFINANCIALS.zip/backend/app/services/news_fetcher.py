"""
Real market news via Google News RSS — free, keyless, returns actual current
Arabic headlines for any query with a real article link, publisher and time.
Far more reliable for the Saudi market than English financial APIs.

Used by content_engine to fetch + persist news that stays live (new items
appended, old kept). A 1h cache avoids hammering the feed.
"""

import html
import httpx
from datetime import datetime, timezone
from email.utils import parsedate_to_datetime
from xml.etree import ElementTree as ET
from loguru import logger
from app.services import cache

NEWS_CACHE_TTL = 60 * 60  # 1h

# Market-wide Arabic queries (up to last close of the Saudi market).
MARKET_QUERIES = ["مؤشر تاسي", "السوق السعودي تداول", "نتائج الشركات السعودية"]
ECONOMIC_QUERIES = ["أوبك النفط أسعار", "الفيدرالي الأمريكي الفائدة", "الاقتصاد السعودي", "الاكتتابات السعودية"]


async def _fetch_google_news(client: httpx.AsyncClient, query: str, count: int = 6) -> list:
    """Parse one Google News RSS query into normalized items."""
    url = "https://news.google.com/rss/search"
    params = {"q": query, "hl": "ar", "gl": "SA", "ceid": "SA:ar"}
    try:
        r = await client.get(url, params=params)
        if r.status_code != 200:
            return []
        root = ET.fromstring(r.content)
        items = []
        for it in list(root.iterfind(".//item"))[:count]:
            title = it.findtext("title") or ""
            link = it.findtext("link") or ""
            pub = it.findtext("pubDate")
            source_el = it.find("{*}source")
            source = source_el.text if source_el is not None else None
            # Google appends " - Source" to titles; strip it.
            if title and source and title.endswith(f" - {source}"):
                title = title[: -(len(source) + 3)]
            try:
                published = parsedate_to_datetime(pub) if pub else datetime.now(timezone.utc)
                if published.tzinfo is None:
                    published = published.replace(tzinfo=timezone.utc)
            except Exception:
                published = datetime.now(timezone.utc)
            items.append({
                "headline": html.unescape(title).strip(),
                "url": link.strip() or None,
                "source": source,
                "published": published,
            })
        return items
    except Exception as e:
        logger.debug(f"Google News '{query}' failed: {e}")
        return []


async def _collect(queries: list[str], category: str) -> list[dict]:
    seen: set = set()
    out: list[dict] = []
    headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
    async with httpx.AsyncClient(timeout=12, headers=headers, follow_redirects=True) as client:
        for q in queries:
            for it in await _fetch_google_news(client, q):
                h = it["headline"]
                if not h or h in seen:
                    continue
                seen.add(h)
                it["category"] = category
                out.append(it)
    out.sort(key=lambda x: x["published"], reverse=True)
    return out


async def fetch_market_news(company_names: list[str] | None = None) -> list[dict]:
    """Market-wide + per-company real Arabic news. Cached 1h."""
    key = "news:gnews:market"
    cached = cache.get(key)
    if cached is not None:
        return cached
    queries = list(MARKET_QUERIES)
    for name in (company_names or [])[:8]:
        if name:
            queries.append(f"سهم {name} السعودية")
    items = await _collect(queries, "أسواق")
    if items:
        cache.set(key, items, NEWS_CACHE_TTL)
    return items


async def fetch_economic_news() -> list[dict]:
    """Macro economic real Arabic news. Cached 1h."""
    key = "news:gnews:econ"
    cached = cache.get(key)
    if cached is not None:
        return cached
    items = await _collect(ECONOMIC_QUERIES, "اقتصاد")
    if items:
        cache.set(key, items, NEWS_CACHE_TTL)
    return items


async def fetch_corporate_events(companies: list[tuple[str, str]]) -> list[dict]:
    """Real corporate-action announcements (dividends/rights issues/bonus
    shares/splits/AGMs) per portfolio company via the same free Google News
    RSS — a free source that supports the Saudi market, so the calendar is
    never solely dependent on Gemini. Each item is the real announcement
    headline + link + publish date; `companies` is a list of (symbol, name).
    Cached 2h per symbol set."""
    key = f"events:gnews:{len(companies)}"
    cached = cache.get(key)
    if cached is not None:
        return cached
    queries = []
    for symbol, name in companies[:10]:
        if name:
            queries.append(f"{name} توزيعات أرباح OR أحقية OR منحة أسهم OR تجزئة OR الجمعية العامة")
    if not queries:
        return []
    items = await _collect(queries, "شركات")
    # Tag each item with the company it was queried for, matched by name
    # substring in the headline (best effort — Google News doesn't echo the query back).
    by_name = {name: symbol for symbol, name in companies if name}
    for it in items:
        it["symbol"] = next((sym for name, sym in by_name.items() if name and name in it["headline"]), None)
    if items:
        cache.set(key, items, 2 * 60 * 60)
    return items
