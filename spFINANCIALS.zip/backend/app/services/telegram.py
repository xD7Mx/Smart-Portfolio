"""
Telegram Notification Service — Smart Portfolio
=================================================
Sends formatted messages to the investor's Telegram chat.
All calls go through this service — no direct API calls elsewhere.
"""

import httpx
from loguru import logger
from app.core.config import settings


class TelegramService:
    """
    Telegram Bot API wrapper.
    Handles: send message, send report, test connection, retry on failure.
    """

    BASE_URL = "https://api.telegram.org/bot{token}/{method}"

    def __init__(self):
        self.token = settings.TELEGRAM_BOT_TOKEN
        self.chat_id = settings.TELEGRAM_CHAT_ID
        self.enabled = settings.TELEGRAM_ENABLED

    async def send_message(self, text: str, parse_mode: str = "HTML") -> bool:
        if not self.enabled:
            return False
        if not self.token or not self.chat_id:
            logger.warning("Telegram: not configured.")
            return False
        try:
            url = self.BASE_URL.format(token=self.token, method="sendMessage")
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(url, json={
                    "chat_id": self.chat_id,
                    "text": text,
                    "parse_mode": parse_mode,
                })
                if resp.status_code == 200:
                    logger.info("📨 Telegram: message sent.")
                    return True
                else:
                    logger.warning(f"Telegram: send failed [{resp.status_code}]")
                    return False
        except Exception as e:
            logger.error(f"Telegram error: {e}")
            return False

    async def test_connection(self) -> dict:
        if not self.token:
            return {"success": False, "message": "No token configured."}
        try:
            url = self.BASE_URL.format(token=self.token, method="getMe")
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(url)
                if resp.status_code == 200:
                    data = resp.json()
                    return {"success": True, "bot": data.get("result", {}).get("username")}
                return {"success": False, "message": f"HTTP {resp.status_code}"}
        except Exception as e:
            return {"success": False, "message": str(e)}

    async def send_notification(self, title: str, message: str, priority: str = "INFO") -> bool:
        icons = {"CRITICAL": "🚨", "HIGH": "⚠️", "MEDIUM": "📌", "LOW": "ℹ️", "INFO": "💬"}
        icon = icons.get(priority, "💬")
        text = f"{icon} <b>{title}</b>\n\n{message}\n\n<i>Smart Portfolio</i>"
        return await self.send_message(text)

    async def send_portfolio_summary(self, summary: dict) -> bool:
        text = (
            "📊 <b>Portfolio Summary</b>\n\n"
            f"💰 Invested: {summary.get('total_invested', 0):,.2f}\n"
            f"📈 Market Value: {summary.get('market_value', 0):,.2f}\n"
            f"💹 ROI: {summary.get('roi_pct', 0):.2f}%\n"
            f"🎯 Goal: {summary.get('goal_pct', 0):.1f}%\n\n"
            "<i>حلّل أكثر... قرّر بنفسك.</i>"
        )
        return await self.send_message(text)


telegram_service = TelegramService()
