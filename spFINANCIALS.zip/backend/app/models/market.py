"""
Goal, Allocation, Market events, AI results, Notifications,
Reports, Settings, Audit logs, Scheduler, API usage, Backup models.
"""

from sqlalchemy import (
    Column, String, Numeric, Enum, DateTime, Text,
    Integer, ForeignKey, Boolean, JSON
)
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum

from app.core.database import Base


# ─── Goals ────────────────────────────────────────────────────

class GoalStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    ACHIEVED = "ACHIEVED"
    PAUSED = "PAUSED"


class Goal(Base):
    __tablename__ = "goals"

    id = Column(Integer, primary_key=True, index=True)
    portfolio_id = Column(Integer, ForeignKey("portfolio.id"), default=1)
    goal_name = Column(String(200), nullable=False)
    target_value = Column(Numeric(18, 6), nullable=False)
    current_value = Column(Numeric(18, 6), default=0)
    completion_percentage = Column(Numeric(10, 4), default=0)
    deadline = Column(DateTime(timezone=True))
    status = Column(Enum(GoalStatus), default=GoalStatus.ACTIVE)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())

    portfolio = relationship("Portfolio", back_populates="goals")


# ─── Allocation ────────────────────────────────────────────────

class Allocation(Base):
    __tablename__ = "allocation"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=False, unique=True)
    target_weight = Column(Numeric(10, 4), default=0)
    current_weight = Column(Numeric(10, 4), default=0)
    deviation = Column(Numeric(10, 4), default=0)
    rebalance_required = Column(Boolean, default=False)
    last_reviewed = Column(DateTime(timezone=True))
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())

    company = relationship("Company", back_populates="allocation")


# ─── Market ────────────────────────────────────────────────────

class MarketEventType(str, enum.Enum):
    DIVIDEND = "DIVIDEND"
    RIGHTS_ISSUE = "RIGHTS_ISSUE"
    SPLIT = "SPLIT"
    BONUS = "BONUS"
    RESULTS = "RESULTS"
    MERGER = "MERGER"
    ACQUISITION = "ACQUISITION"
    OTHER = "OTHER"


class MarketNews(Base):
    __tablename__ = "market_news"

    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String(50))
    company_symbol = Column(String(20), index=True)
    headline = Column(String(500), nullable=False)
    summary = Column(Text)
    url = Column(String(1000))
    category = Column(String(50))
    importance = Column(String(20), default="MEDIUM")
    published_at = Column(DateTime(timezone=True), index=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class MarketEvent(Base):
    __tablename__ = "market_events"

    id = Column(Integer, primary_key=True, index=True)
    company_symbol = Column(String(20), index=True)
    event_type = Column(Enum(MarketEventType), nullable=False)
    description = Column(Text)
    event_date = Column(DateTime(timezone=True), index=True)
    value = Column(Numeric(18, 6))
    created_at = Column(DateTime(timezone=True), server_default=func.now())


# ─── AI Results ───────────────────────────────────────────────

class AIResult(Base):
    __tablename__ = "ai_results"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id"), nullable=True)
    agent_name = Column(String(100), nullable=False, index=True)
    target_module = Column(String(100))
    confidence = Column(Numeric(5, 2), default=0)
    summary = Column(Text)
    recommendation = Column(Text)
    evidence = Column(JSON)
    score = Column(Numeric(5, 2))
    generated_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)

    company = relationship("Company", back_populates="ai_results")


# ─── Notifications ─────────────────────────────────────────────

class NotificationPriority(str, enum.Enum):
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    INFO = "INFO"


class NotificationStatus(str, enum.Enum):
    UNREAD = "UNREAD"
    READ = "READ"
    ARCHIVED = "ARCHIVED"


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    category = Column(String(50), nullable=False)
    priority = Column(Enum(NotificationPriority), default=NotificationPriority.INFO)
    title = Column(String(300), nullable=False)
    message = Column(Text, nullable=False)
    channel = Column(String(50), default="IN_APP")
    status = Column(Enum(NotificationStatus), default=NotificationStatus.UNREAD, index=True)
    extra_data = Column(JSON)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    read_at = Column(DateTime(timezone=True))


# ─── Reports ──────────────────────────────────────────────────

class ReportType(str, enum.Enum):
    DAILY = "DAILY"
    WEEKLY = "WEEKLY"
    MONTHLY = "MONTHLY"
    QUARTERLY = "QUARTERLY"
    ANNUAL = "ANNUAL"
    CUSTOM = "CUSTOM"


class Report(Base):
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True, index=True)
    report_type = Column(Enum(ReportType), nullable=False, index=True)
    report_period = Column(String(50))
    period_start = Column(DateTime(timezone=True))
    period_end = Column(DateTime(timezone=True))
    file_path = Column(String(500))
    checksum = Column(String(64))
    summary = Column(JSON)
    generated_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)


# ─── Settings ─────────────────────────────────────────────────

class Settings(Base):
    __tablename__ = "settings"

    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(200), unique=True, nullable=False, index=True)
    value = Column(Text)
    category = Column(String(100), index=True)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())


# ─── Audit Log ────────────────────────────────────────────────

class AuditLog(Base):
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    module = Column(String(100), nullable=False, index=True)
    action = Column(String(100), nullable=False)
    entity = Column(String(100))
    entity_id = Column(Integer)
    old_value = Column(JSON)
    new_value = Column(JSON)
    performed_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)


# ─── Scheduler ────────────────────────────────────────────────

class SchedulerJob(Base):
    __tablename__ = "scheduler_jobs"

    id = Column(Integer, primary_key=True, index=True)
    job_name = Column(String(100), unique=True, nullable=False)
    frequency = Column(String(100))
    last_run = Column(DateTime(timezone=True))
    next_run = Column(DateTime(timezone=True))
    status = Column(String(50), default="ACTIVE")
    last_error = Column(Text)


# ─── API Usage ────────────────────────────────────────────────

class APIUsage(Base):
    __tablename__ = "api_usage"

    id = Column(Integer, primary_key=True, index=True)
    provider = Column(String(100), nullable=False, index=True)
    endpoint = Column(String(200))
    requests_today = Column(Integer, default=0)
    daily_limit = Column(Integer, default=500)
    remaining = Column(Integer, default=500)
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())


# ─── Backup ───────────────────────────────────────────────────

class Backup(Base):
    __tablename__ = "backups"

    id = Column(Integer, primary_key=True, index=True)
    backup_name = Column(String(200), nullable=False)
    backup_type = Column(String(50), default="FULL")
    file_size = Column(Integer)
    location = Column(String(500))
    checksum = Column(String(64))
    created_at = Column(DateTime(timezone=True), server_default=func.now(), index=True)
