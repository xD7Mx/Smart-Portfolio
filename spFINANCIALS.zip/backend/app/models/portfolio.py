"""
Portfolio, Company, and Holdings database models.
"""

from sqlalchemy import Column, String, Numeric, Enum, DateTime, Date, Text, Integer, ForeignKey, Boolean
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
import enum

from app.core.database import Base


class PortfolioMode(str, enum.Enum):
    BUILD = "BUILD"
    MANAGEMENT = "MANAGEMENT"


class CompanyStatus(str, enum.Enum):
    ACTIVE = "ACTIVE"
    WATCHLIST = "WATCHLIST"
    ARCHIVED = "ARCHIVED"
    DELISTED = "DELISTED"


class ShariaStatus(str, enum.Enum):
    COMPLIANT = "COMPLIANT"
    NON_COMPLIANT = "NON_COMPLIANT"
    UNDER_REVIEW = "UNDER_REVIEW"
    UNKNOWN = "UNKNOWN"


class Portfolio(Base):
    __tablename__ = "portfolio"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), nullable=False, default="My Portfolio")
    currency = Column(String(10), nullable=False, default="SAR")
    mode = Column(Enum(PortfolioMode), nullable=False, default=PortfolioMode.BUILD)
    target_capital = Column(Numeric(18, 6), default=0)
    target_income = Column(Numeric(18, 6), default=0)
    target_return_pct = Column(Numeric(10, 4), default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())

    goals = relationship("Goal", back_populates="portfolio")
    cash = relationship("Cash", back_populates="portfolio", uselist=False)


class Company(Base):
    __tablename__ = "companies"

    id = Column(Integer, primary_key=True, index=True)
    symbol = Column(String(20), unique=True, nullable=False, index=True)
    company_name = Column(String(200), nullable=False)
    exchange = Column(String(50))
    sector = Column(String(100), index=True)
    industry = Column(String(100))
    currency = Column(String(10), default="SAR")
    status = Column(Enum(CompanyStatus), default=CompanyStatus.ACTIVE)
    sharia_status = Column(Enum(ShariaStatus), default=ShariaStatus.UNKNOWN)
    finance_score = Column(Numeric(5, 2), default=0)
    technical_score = Column(Numeric(5, 2), default=0)
    logo_url = Column(String(500))
    color = Column(String(10), default="#3B82F6")
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())

    holding = relationship("Holding", back_populates="company", uselist=False)
    transactions = relationship("Transaction", back_populates="company")
    installments = relationship("Installment", back_populates="company")
    dividends = relationship("Dividend", back_populates="company")
    bonus_shares = relationship("BonusShare", back_populates="company")
    allocation = relationship("Allocation", back_populates="company", uselist=False)
    ai_results = relationship("AIResult", back_populates="company")


class Holding(Base):
    __tablename__ = "holdings"

    id = Column(Integer, primary_key=True, index=True)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=False)
    quantity = Column(Numeric(18, 6), default=0)
    average_cost = Column(Numeric(18, 6), default=0)
    invested_amount = Column(Numeric(18, 6), default=0)
    market_value = Column(Numeric(18, 6), default=0)
    last_price = Column(Numeric(18, 6), default=0)
    unrealized_profit = Column(Numeric(18, 6), default=0)
    unrealized_profit_pct = Column(Numeric(10, 4), default=0)
    weight = Column(Numeric(10, 4), default=0)
    installment_progress = Column(Integer, default=0)
    total_dividends_received = Column(Numeric(18, 6), default=0)
    total_bonus_shares = Column(Numeric(18, 6), default=0)
    reinvestment_shares = Column(Numeric(18, 6), default=0)
    last_price_update = Column(DateTime(timezone=True))
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now(), server_default=func.now())

    company = relationship("Company", back_populates="holding")


class NoteScope(str, enum.Enum):
    MARKET = "MARKET"
    PORTFOLIO = "PORTFOLIO"


class Note(Base):
    """User notes — MARKET (general) or PORTFOLIO (tied to a company; hidden
    automatically when the company is archived/removed)."""
    __tablename__ = "notes"

    id = Column(Integer, primary_key=True, index=True)
    scope = Column(Enum(NoteScope), nullable=False, default=NoteScope.MARKET)
    company_id = Column(Integer, ForeignKey("companies.id", ondelete="CASCADE"), nullable=True)
    content = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    company = relationship("Company")


class PortfolioSnapshot(Base):
    """Daily portfolio snapshot — one row per day; powers the real
    performance history chart."""
    __tablename__ = "portfolio_snapshots"

    id = Column(Integer, primary_key=True, index=True)
    snapshot_date = Column(Date, nullable=False, unique=True, index=True)
    market_value = Column(Numeric(18, 6), default=0)
    invested_amount = Column(Numeric(18, 6), default=0)
    cash_balance = Column(Numeric(18, 6), default=0)
    unrealized_profit = Column(Numeric(18, 6), default=0)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
