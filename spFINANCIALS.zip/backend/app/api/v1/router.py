"""
Main API Router — registers all v1 endpoints.
"""

from fastapi import APIRouter
from app.api.v1.endpoints import (
    health, portfolio, companies, holdings, transactions, notes,
    installments, cash, dividends, bonus, goals, allocation,
    market, ai, notifications, reports, scheduler, settings, backup
)

api_router = APIRouter()

api_router.include_router(health.router, prefix="/health", tags=["Health"])
api_router.include_router(portfolio.router, prefix="/portfolio", tags=["Portfolio"])
api_router.include_router(companies.router, prefix="/companies", tags=["Companies"])
api_router.include_router(holdings.router, prefix="/holdings", tags=["Holdings"])
api_router.include_router(transactions.router, prefix="/transactions", tags=["Transactions"])
api_router.include_router(installments.router, prefix="/installments", tags=["Installments"])
api_router.include_router(cash.router, prefix="/cash", tags=["Cash"])
api_router.include_router(dividends.router, prefix="/dividends", tags=["Dividends"])
api_router.include_router(bonus.router, prefix="/bonus", tags=["Bonus Shares"])
api_router.include_router(goals.router, prefix="/goals", tags=["Goals"])
api_router.include_router(notes.router, prefix="/notes", tags=["Notes"])
api_router.include_router(allocation.router, prefix="/allocation", tags=["Allocation"])
api_router.include_router(market.router, prefix="/market", tags=["Market"])
api_router.include_router(ai.router, prefix="/ai", tags=["AI"])
api_router.include_router(notifications.router, prefix="/notifications", tags=["Notifications"])
api_router.include_router(reports.router, prefix="/reports", tags=["Reports"])
api_router.include_router(scheduler.router, prefix="/scheduler", tags=["Scheduler"])
api_router.include_router(settings.router, prefix="/settings", tags=["Settings"])
api_router.include_router(backup.router, prefix="/backups", tags=["Backup"])
