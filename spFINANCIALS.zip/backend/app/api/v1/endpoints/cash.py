from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.core.response import success_response
from app.models.transaction import Cash, CashLedger, CashLedgerKind, Transaction, TransactionType
from pydantic import BaseModel

router = APIRouter()

class CashDeposit(BaseModel):
    amount: float
    source: str = "DEPOSIT"

@router.get("")
async def get_cash(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Cash).limit(1))
    cash = result.scalar_one_or_none()
    if not cash:
        return success_response(data={"available_cash": 0, "pending_cash": 0, "reinvestment_cash": 0, "total_cash": 0})
    return success_response(data={
        "available_cash": float(cash.available_cash or 0),
        "pending_cash": float(cash.pending_cash or 0),
        "reinvestment_cash": float(cash.reinvestment_cash or 0),
        "total_cash": float(cash.total_cash or 0),
    })

@router.get("/history")
async def get_cash_history(limit: int = 30, db: AsyncSession = Depends(get_db)):
    """Everything that has moved the liquidity balance: manual deposits/
    withdrawals plus BUY/SELL/DIVIDEND transactions — so the liquidity
    screen shows real detail, not just a number."""
    items = []

    ledger = (await db.execute(
        select(CashLedger).order_by(CashLedger.created_at.desc()).limit(limit)
    )).scalars().all()
    for l in ledger:
        amt = float(l.amount or 0)
        items.append({
            "date": l.created_at.isoformat() if l.created_at else None,
            "type": l.kind,
            "label": "إيداع" if l.kind == CashLedgerKind.DEPOSIT else "سحب",
            "amount": amt if l.kind == CashLedgerKind.DEPOSIT else -amt,
            "company": None,
        })

    txs = (await db.execute(
        select(Transaction).options(selectinload(Transaction.company))
        .where(Transaction.transaction_type.in_([TransactionType.BUY, TransactionType.SELL, TransactionType.DIVIDEND]))
        .order_by(Transaction.executed_at.desc()).limit(limit)
    )).scalars().all()
    labels = {"BUY": "شراء", "SELL": "بيع", "DIVIDEND": "توزيع نقدي"}
    for t in txs:
        amt = float(t.total_amount or 0)
        signed = -amt if t.transaction_type == TransactionType.BUY else amt
        items.append({
            "date": t.executed_at.isoformat() if t.executed_at else None,
            "type": t.transaction_type,
            "label": labels.get(t.transaction_type, t.transaction_type),
            "amount": signed,
            "company": t.company.company_name if t.company else None,
            "symbol": t.company.symbol if t.company else None,
        })

    items.sort(key=lambda x: x["date"] or "", reverse=True)
    return success_response(data=items[:limit])

@router.post("/deposit")
async def deposit_cash(data: CashDeposit, db: AsyncSession = Depends(get_db)):
    from app.api.v1.endpoints.transactions import _get_cash
    cash = await _get_cash(db)
    cash.available_cash = float(cash.available_cash or 0) + data.amount
    cash.total_cash = float(cash.total_cash or 0) + data.amount
    db.add(CashLedger(kind=CashLedgerKind.DEPOSIT, amount=data.amount, note=data.source))
    await db.commit()
    return success_response(message=f"Deposited {data.amount} successfully.")

@router.post("/withdraw")
async def withdraw_cash(data: CashDeposit, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Cash).limit(1))
    cash = result.scalar_one_or_none()
    if not cash or float(cash.available_cash or 0) < data.amount:
        raise HTTPException(422, "Insufficient available cash")
    cash.available_cash = float(cash.available_cash or 0) - data.amount
    cash.total_cash = float(cash.total_cash or 0) - data.amount
    db.add(CashLedger(kind=CashLedgerKind.WITHDRAW, amount=data.amount, note=data.source))
    await db.commit()
    return success_response(message=f"Withdrew {data.amount} successfully.")
