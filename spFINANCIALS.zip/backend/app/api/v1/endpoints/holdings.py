from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from loguru import logger
from app.core.database import get_db
from app.core.response import success_response
from app.models.portfolio import Holding, Company

router = APIRouter()


def yahoo_symbol(symbol: str) -> str:
    """Saudi tickers (pure digits) map to Yahoo as e.g. 2222.SR."""
    s = (symbol or "").strip().upper()
    if s.isdigit() and not s.endswith(".SR"):
        return f"{s}.SR"
    return s


async def refresh_holdings_prices(db: AsyncSession, holdings) -> None:
    """Pull live prices (served from the 15-min cache — no quota abuse) and
    recompute market_value / P&L for each holding, persisting to the DB.
    This is THE link between price providers and the portfolio."""
    from app.services.market_data import market_service
    changed = False
    for h in holdings:
        if not h.company:
            continue
        try:
            p = await market_service.get_price(yahoo_symbol(h.company.symbol))
            if p and p.get("price"):
                qty = float(h.quantity or 0)
                inv = float(h.invested_amount or 0)
                h.last_price = p["price"]
                h.market_value = qty * float(p["price"])
                h.unrealized_profit = float(h.market_value) - inv
                h.unrealized_profit_pct = ((float(h.market_value) - inv) / inv * 100) if inv else 0
                changed = True
        except Exception as e:
            logger.warning(f"price refresh failed for {h.company.symbol}: {e}")
    if changed:
        await db.commit()


def _effective_sharia(company):
    """Maqasid rating is authoritative; fall back to the stored status
    (which AI may have resolved) for symbols Maqasid doesn't cover."""
    from app.services import maqasid
    r = maqasid.rating(company.symbol) if company else None
    if r:
        return r.get("status"), r.get("purification")
    return (company.sharia_status if company else None), None


def _serialize(h: Holding) -> dict:
    qty = float(h.quantity or 0)
    invested = float(h.invested_amount or 0)
    mv = float(h.market_value or 0)
    sharia, purif = _effective_sharia(h.company) if h.company else (None, None)
    return {
        "id": h.id,
        "company_id": h.company_id,
        # both naming conventions, so every page finds what it expects
        "quantity": qty,
        "total_shares": qty,
        "invested_amount": invested,
        "total_cost": invested,
        "market_value": mv,
        "current_value": mv,
        "average_cost": float(h.average_cost or 0),
        "last_price": float(h.last_price or 0),
        "unrealized_profit": float(h.unrealized_profit or 0),
        "unrealized_profit_pct": float(h.unrealized_profit_pct or 0),
        "reinvestment_shares": float(h.reinvestment_shares or 0),
        "total_bonus_shares": float(h.total_bonus_shares or 0),
        "total_dividends_received": float(h.total_dividends_received or 0),
        "company": {
            "id": h.company.id,
            "symbol": h.company.symbol,
            "name": h.company.company_name,
            "name_ar": h.company.company_name,
            "company_name": h.company.company_name,
            "sector": h.company.sector,
            "sharia_status": sharia,
            "purification": purif,
            "finance_score": float(h.company.finance_score or 0),
            "technical_score": float(h.company.technical_score or 0),
            "color": h.company.color,
            "logo_url": h.company.logo_url,
        } if h.company else None,
    }


@router.get("")
async def get_holdings(db: AsyncSession = Depends(get_db)):
    # Self-heal: companies added before holdings auto-creation get a zero row.
    companies = (await db.execute(select(Company).where(Company.status != "ARCHIVED"))).scalars().all()
    have = set((await db.execute(select(Holding.company_id))).scalars().all())
    added = False
    for c in companies:
        if c.id not in have:
            db.add(Holding(company_id=c.id, quantity=0, average_cost=0, invested_amount=0, market_value=0))
            added = True
    if added:
        await db.commit()
    result = await db.execute(select(Holding).options(selectinload(Holding.company)))
    holdings = [h for h in result.scalars().all()
                if h.company and h.company.status != "ARCHIVED"]
    await refresh_holdings_prices(db, holdings)
    return success_response(data=[_serialize(h) for h in holdings])


from pydantic import BaseModel
from typing import Optional


class HoldingUpdate(BaseModel):
    quantity: Optional[float] = None
    average_cost: Optional[float] = None


@router.patch("/{company_id}")
async def update_holding(company_id: int, data: HoldingUpdate, db: AsyncSession = Depends(get_db)):
    """Direct correction of shares / average cost (e.g. migrating an existing
    portfolio in). invested_amount is recomputed as qty × avg_cost."""
    result = await db.execute(
        select(Holding).options(selectinload(Holding.company)).where(Holding.company_id == company_id)
    )
    h = result.scalar_one_or_none()
    if not h:
        h = Holding(company_id=company_id, quantity=0, average_cost=0, invested_amount=0, market_value=0)
        db.add(h)
    if data.quantity is not None:
        h.quantity = data.quantity
    if data.average_cost is not None:
        h.average_cost = data.average_cost
    qty = float(h.quantity or 0)
    avg = float(h.average_cost or 0)
    h.invested_amount = qty * avg
    lp = float(h.last_price or 0)
    h.market_value = qty * lp if lp else h.invested_amount
    inv = float(h.invested_amount or 0)
    h.unrealized_profit = float(h.market_value) - inv
    h.unrealized_profit_pct = ((float(h.market_value) - inv) / inv * 100) if inv else 0
    await db.commit()
    await db.refresh(h, ["company"])
    await refresh_holdings_prices(db, [h])
    return success_response(data=_serialize(h), message="Holding updated.")


@router.get("/{company_id}")
async def get_holding(company_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Holding).options(selectinload(Holding.company)).where(Holding.company_id == company_id)
    )
    h = result.scalar_one_or_none()
    if not h:
        return success_response(data=None, message="No holding found.")
    await refresh_holdings_prices(db, [h])
    return success_response(data=_serialize(h))
