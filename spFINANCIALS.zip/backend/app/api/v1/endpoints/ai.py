from fastapi import APIRouter, Depends, BackgroundTasks
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.response import success_response
from app.models.market import AIResult

router = APIRouter()

@router.get("/status")
async def ai_status():
    from app.core.config import settings
    from app.agents.coordinator import coordinator
    quota = coordinator.quota_status()
    return success_response(data={
        "provider":        settings.AI_PROVIDER,
        "model":           settings.AI_MODEL,
        "key_configured":  bool(settings.AI_API_KEY),
        "quota":           quota,
    })

@router.get("/quota")
async def ai_quota():
    """Real-time Gemini free-tier quota usage."""
    from app.agents.coordinator import coordinator
    return success_response(data=coordinator.quota_status())

@router.post("/run")
async def run_ai_analysis(background_tasks: BackgroundTasks, db: AsyncSession = Depends(get_db)):
    return success_response(message="AI analysis queued. Results will appear shortly.")

@router.get("/report")
async def get_ai_report(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(AIResult).order_by(AIResult.generated_at.desc()).limit(10))
    items = result.scalars().all()
    return success_response(data=[{"agent": r.agent_name, "summary": r.summary, "confidence": float(r.confidence or 0)} for r in items])

async def _portfolio_snapshot(db: AsyncSession):
    """Real holdings + cash context for the AI analysts."""
    from sqlalchemy.orm import selectinload
    from app.models.portfolio import Holding
    from app.models.transaction import Cash
    result = await db.execute(select(Holding).options(selectinload(Holding.company)))
    holdings = [
        {
            "name": h.company.company_name, "symbol": h.company.symbol,
            "qty": float(h.quantity or 0), "avg": float(h.average_cost or 0),
            "mv": float(h.market_value or 0),
            "pnl": float(h.unrealized_profit or 0),
            "pnl_pct": float(h.unrealized_profit_pct or 0),
            "sector": h.company.sector,
        }
        for h in result.scalars().all()
        if h.company and h.company.status != "ARCHIVED" and float(h.quantity or 0) > 0
    ]
    cash_row = (await db.execute(select(Cash).limit(1))).scalar_one_or_none()
    cash = float(cash_row.available_cash or 0) if cash_row else 0.0
    return holdings, cash

@router.get("/evaluation")
async def get_evaluation(db: AsyncSession = Depends(get_db)):
    """Always populated: rule-based scores from the real portfolio, enriched
    with a Gemini narrative when the key is available."""
    from app.services import portfolio_analytics
    from app.services.ai_content import portfolio_evaluation
    holdings, cash = await _portfolio_snapshot(db)
    data = portfolio_analytics.evaluate(holdings, cash)
    try:
        ai = await portfolio_evaluation(holdings, cash)
        if ai and ai.get("summary"):
            data["summary"] = ai["summary"]
            data["executive_summary"] = ai["summary"]
            data["source"] = "AI"
    except Exception:
        pass
    return success_response(data=data)

@router.get("/opportunities")
async def get_opportunities(db: AsyncSession = Depends(get_db)):
    return success_response(data=[], message="فرص مقترحة من تحليل الذكاء الاصطناعي.")

@router.get("/risk")
async def get_risk(db: AsyncSession = Depends(get_db)):
    """Always populated: concrete risks derived from the real portfolio
    (concentration, drawdowns, valuation, safety), Gemini narrative optional."""
    from app.services import portfolio_analytics
    from app.services.ai_content import portfolio_risk
    holdings, cash = await _portfolio_snapshot(db)
    data = portfolio_analytics.risk(holdings, cash)
    try:
        ai = await portfolio_risk(holdings, cash)
        if ai and ai.get("summary"):
            data["summary"] = ai["summary"]
            if ai.get("risks"):
                data["risks"] = ai["risks"] + data["risks"]
            data["source"] = "AI"
    except Exception:
        pass
    return success_response(data=data)

@router.get("/portfolio-insight")
async def get_portfolio_insight(db: AsyncSession = Depends(get_db)):
    """Per-company fair value + safety score (investing.com style) for the
    holdings in the portfolio, plus a Gemini professional-advice summary.
    Never empty when the portfolio has companies."""
    from sqlalchemy.orm import selectinload
    from app.models.portfolio import Holding
    from app.services.analysis import analyze_company
    from app.services.ai_content import portfolio_evaluation

    result = await db.execute(select(Holding).options(selectinload(Holding.company)))
    holdings = [h for h in result.scalars().all()
                if h.company and h.company.status != "ARCHIVED"]

    def yahoo(sym: str) -> str:
        s = (sym or "").strip().upper()
        return f"{s}.SR" if s.isdigit() else s

    companies = []
    for h in holdings:
        a = await analyze_company(yahoo(h.company.symbol), h.company.company_name)
        if not a:
            continue
        f = a.get("fundamentals") or {}
        price = a.get("price")
        fair = f.get("target_mean_price")
        upside = round((fair / price - 1) * 100, 1) if (fair and price) else None
        safety = a["financial"]["score"]
        safety_label = ("ممتازة" if safety >= 80 else "جيدة" if safety >= 65
                        else "متوسطة" if safety >= 45 else "ضعيفة")
        valuation = ("مقيّم بأقل من قيمته" if (upside is not None and upside >= 8)
                     else "مقيّم بأعلى من قيمته" if (upside is not None and upside <= -8)
                     else "قريب من القيمة العادلة" if upside is not None else "غير متاح")
        companies.append({
            "symbol": h.company.symbol,
            "name": h.company.company_name,
            "price": price,
            "fair_value": fair,
            "upside_pct": upside,
            "valuation": valuation,
            "safety_score": safety,
            "safety_label": safety_label,
            "ai_score": a.get("ai_score"),
            "decision": a.get("decision"),
        })

    advice = None
    try:
        from app.api.v1.endpoints.ai import _portfolio_snapshot as _snap
        from app.services import portfolio_analytics
        hs, cash = await _snap(db)
        advice = portfolio_analytics.evaluate(hs, cash).get("summary")  # rule-based, always
        ai = await portfolio_evaluation(hs, cash)
        if ai and ai.get("summary"):
            advice = ai["summary"]
    except Exception:
        advice = None

    return success_response(data={"companies": companies, "advice": advice})


@router.get("/full-report")
async def get_full_report(db: AsyncSession = Depends(get_db)):
    """Always populated comprehensive report — rule-based text from the real
    portfolio, upgraded to a Gemini narrative when available."""
    from app.services import portfolio_analytics
    from app.services.ai_content import portfolio_report
    holdings, cash = await _portfolio_snapshot(db)
    total = sum(h["mv"] for h in holdings)
    invested = sum(h.get("avg", 0) * h.get("qty", 0) for h in holdings)
    roi = ((total - invested) / invested * 100) if invested else 0
    data = portfolio_analytics.report(holdings, cash, {"market_value": total, "roi_pct": roi})
    try:
        ai = await portfolio_report(holdings, cash)
        if ai and ai.get("content"):
            data["content"] = ai["content"]
            data["source"] = "AI"
    except Exception:
        pass
    return success_response(data=data)
