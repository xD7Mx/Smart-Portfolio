"""
Target weights & rebalancing — decision support only, never auto-executes.
Weights are % of investable capital (market value + available cash).
"""
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.core.response import success_response
from app.models.market import Allocation
from app.models.portfolio import Holding
from app.models.transaction import Cash
from pydantic import BaseModel

router = APIRouter()


class TargetItem(BaseModel):
    company_id: int
    target_weight: float  # percent 0-100


class TargetsUpdate(BaseModel):
    items: list[TargetItem]


async def _snapshot(db: AsyncSession):
    result = await db.execute(select(Holding).options(selectinload(Holding.company)))
    holdings = [h for h in result.scalars().all() if h.company and h.company.status != "ARCHIVED"]
    cash_row = (await db.execute(select(Cash).limit(1))).scalar_one_or_none()
    cash = float(cash_row.available_cash or 0) if cash_row else 0.0
    total_mv = sum(float(h.market_value or 0) for h in holdings)
    investable = total_mv + cash
    targets = {a.company_id: float(a.target_weight or 0)
               for a in (await db.execute(select(Allocation))).scalars().all()}
    return holdings, cash, total_mv, investable, targets


@router.get("")
async def get_allocation(db: AsyncSession = Depends(get_db)):
    holdings, cash, total_mv, investable, targets = await _snapshot(db)
    data = []
    for h in holdings:
        mv = float(h.market_value or 0)
        data.append({
            "company_id": h.company_id,
            "symbol": h.company.symbol,
            "name": h.company.company_name,
            "market_value": mv,
            "current_weight": round(mv / investable * 100, 2) if investable else 0,
            "target_weight": targets.get(h.company_id, 0),
            "last_price": float(h.last_price or 0),
        })
    return success_response(data={
        "items": data,
        "total_market_value": total_mv,
        "available_cash": cash,
        "investable": investable,
    })


@router.put("/targets")
async def set_targets(payload: TargetsUpdate, db: AsyncSession = Depends(get_db)):
    for item in payload.items:
        result = await db.execute(select(Allocation).where(Allocation.company_id == item.company_id))
        a = result.scalar_one_or_none()
        if not a:
            a = Allocation(company_id=item.company_id)
            db.add(a)
        a.target_weight = item.target_weight
    await db.commit()
    return success_response(message="Targets saved.")


@router.get("/rebalance")
async def calculate_rebalance(db: AsyncSession = Depends(get_db)):
    """Suggested trades to reach target weights. Advisory only — nothing executes."""
    holdings, cash, total_mv, investable, targets = await _snapshot(db)
    if not investable or not any(targets.values()):
        return success_response(data={"suggestions": [], "message": "لا توجد أوزان مستهدفة بعد"})
    suggestions = []
    for h in holdings:
        target_pct = targets.get(h.company_id, 0)
        mv = float(h.market_value or 0)
        target_value = investable * target_pct / 100
        delta = target_value - mv
        lp = float(h.last_price or 0)
        if abs(delta) < max(1.0, investable * 0.002):  # ignore noise < 0.2%
            action = "HOLD"
        else:
            action = "BUY" if delta > 0 else "SELL"
        suggestions.append({
            "company_id": h.company_id,
            "symbol": h.company.symbol,
            "name": h.company.company_name,
            "current_weight": round(mv / investable * 100, 2),
            "target_weight": target_pct,
            "delta_value": round(delta, 2),
            "est_shares": round(abs(delta) / lp, 2) if lp else None,
            "action": action,
        })
    return success_response(data={
        "suggestions": suggestions,
        "investable": investable,
        "note": "اقتراحات فقط — القرار يبقى بيدك",
    })
