"""
Transaction engine — the investment reference implementation.
Supported: BUY, SELL, DIVIDEND (cash), REINVESTMENT (dividend reinvested),
BONUS (bonus shares), SPLIT (stock split), each updating the Holding and the
Cash balance exactly as a real portfolio would.
"""
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.response import success_response
from app.models.transaction import Transaction, Cash, Dividend, DividendAction
from app.models.portfolio import Holding
from pydantic import BaseModel, model_validator
from datetime import datetime
from typing import Optional

router = APIRouter()


class TransactionCreate(BaseModel):
    company_id: int
    transaction_type: str
    quantity: Optional[float] = None
    shares: Optional[float] = None
    price: Optional[float] = None
    price_per_share: Optional[float] = None
    amount: Optional[float] = None      # DIVIDEND / REINVESTMENT total amount
    factor: Optional[float] = None      # SPLIT factor (e.g. 2 = 1→2 shares)
    fees: float = 0
    notes: Optional[str] = None
    executed_at: Optional[datetime] = None
    transaction_date: Optional[str] = None

    @model_validator(mode="after")
    def resolve_aliases(self):
        self.quantity = self.quantity if self.quantity is not None else self.shares
        self.price = self.price if self.price is not None else self.price_per_share
        if self.executed_at is None:
            self.executed_at = datetime.fromisoformat(self.transaction_date) if self.transaction_date else datetime.utcnow()
        return self


async def _get_cash(db: AsyncSession) -> Cash:
    result = await db.execute(select(Cash).limit(1))
    cash = result.scalar_one_or_none()
    if not cash:
        # Cash FK requires a Portfolio row — bootstrap it on first use
        from app.models.portfolio import Portfolio
        p = (await db.execute(select(Portfolio).limit(1))).scalar_one_or_none()
        if not p:
            p = Portfolio(name="My Portfolio")
            db.add(p)
            await db.flush()
        cash = Cash(portfolio_id=p.id, available_cash=0, total_cash=0)
        db.add(cash)
        await db.flush()
    return cash


def _recalc(h: Holding):
    qty = float(h.quantity or 0)
    inv = float(h.invested_amount or 0)
    lp = float(h.last_price or 0)
    h.average_cost = (inv / qty) if qty else 0
    h.market_value = qty * lp if lp else inv
    mv = float(h.market_value or 0)
    h.unrealized_profit = mv - inv
    h.unrealized_profit_pct = ((mv - inv) / inv * 100) if inv else 0


async def _apply(db: AsyncSession, tx: TransactionCreate) -> float:
    """Apply the transaction to Holding + Cash. Returns total_amount for the record."""
    result = await db.execute(select(Holding).where(Holding.company_id == tx.company_id))
    h = result.scalar_one_or_none()
    if not h:
        h = Holding(company_id=tx.company_id, quantity=0, average_cost=0,
                    invested_amount=0, market_value=0, last_price=tx.price or 0)
        db.add(h)
    cash = await _get_cash(db)
    t = tx.transaction_type
    qty0 = float(h.quantity or 0)
    inv0 = float(h.invested_amount or 0)

    if t == "BUY":
        if not tx.quantity or not tx.price:
            raise HTTPException(422, "quantity and price are required for BUY")
        total = tx.quantity * tx.price + tx.fees
        h.quantity = qty0 + tx.quantity
        h.invested_amount = inv0 + total
        h.last_price = tx.price
        cash.available_cash = float(cash.available_cash or 0) - total
        cash.total_cash = float(cash.total_cash or 0) - total

    elif t == "SELL":
        if not tx.quantity or not tx.price:
            raise HTTPException(422, "quantity and price are required for SELL")
        if tx.quantity > qty0:
            raise HTTPException(422, "Cannot sell more shares than held")
        avg = (inv0 / qty0) if qty0 else 0
        proceeds = tx.quantity * tx.price - tx.fees
        h.quantity = qty0 - tx.quantity
        h.invested_amount = max(0, inv0 - tx.quantity * avg)
        h.last_price = tx.price
        cash.available_cash = float(cash.available_cash or 0) + proceeds
        cash.total_cash = float(cash.total_cash or 0) + proceeds
        total = proceeds

    elif t == "DIVIDEND":
        # Cash dividend: amount directly, or per-share (price) × current shares
        amount = tx.amount if tx.amount else (tx.price or 0) * qty0
        if amount <= 0:
            raise HTTPException(422, "amount (or per-share price) required for DIVIDEND")
        h.total_dividends_received = float(h.total_dividends_received or 0) + amount
        cash.available_cash = float(cash.available_cash or 0) + amount
        cash.total_cash = float(cash.total_cash or 0) + amount
        total = amount
        dps = tx.price if tx.price else (amount / qty0 if qty0 else 0)
        db.add(Dividend(
            company_id=tx.company_id, dividend_per_share=dps, shares_at_time=qty0,
            received_amount=amount, action=DividendAction.CASH, payment_date=tx.executed_at,
        ))

    elif t == "REINVESTMENT":
        # Dividend reinvested into shares at given price
        amount = tx.amount or 0
        if amount <= 0 or not tx.price:
            raise HTTPException(422, "amount and price are required for REINVESTMENT")
        new_shares = amount / tx.price
        h.quantity = qty0 + new_shares
        h.invested_amount = inv0 + amount
        h.reinvestment_shares = float(h.reinvestment_shares or 0) + new_shares
        h.total_dividends_received = float(h.total_dividends_received or 0) + amount
        h.last_price = tx.price
        total = amount
        dps = amount / qty0 if qty0 else 0
        db.add(Dividend(
            company_id=tx.company_id, dividend_per_share=dps, shares_at_time=qty0,
            received_amount=amount, action=DividendAction.REINVEST, reinvested_shares=new_shares,
            payment_date=tx.executed_at,
        ))

    elif t == "BONUS":
        # Bonus shares: quantity increases, cost basis unchanged
        if not tx.quantity:
            raise HTTPException(422, "quantity is required for BONUS")
        h.quantity = qty0 + tx.quantity
        h.total_bonus_shares = float(h.total_bonus_shares or 0) + tx.quantity
        total = 0

    elif t == "SPLIT":
        if not tx.factor or tx.factor <= 0:
            raise HTTPException(422, "factor is required for SPLIT (e.g. 2)")
        h.quantity = qty0 * tx.factor
        if h.last_price:
            h.last_price = float(h.last_price) / tx.factor
        total = 0

    else:
        raise HTTPException(422, f"Unsupported transaction type: {t}")

    _recalc(h)
    return total


@router.get("")
async def get_transactions(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Transaction).order_by(Transaction.executed_at.desc()).limit(100))
    txs = result.scalars().all()
    return success_response(data=[{
        "id": t.id, "company_id": t.company_id, "type": t.transaction_type,
        "quantity": float(t.quantity or 0), "price": float(t.price or 0),
        "total": float(t.total_amount or 0), "notes": t.notes,
        "date": t.executed_at.isoformat() if t.executed_at else None,
    } for t in txs])


@router.post("")
async def add_transaction(data: TransactionCreate, db: AsyncSession = Depends(get_db)):
    total = await _apply(db, data)
    tx = Transaction(
        company_id=data.company_id,
        transaction_type=data.transaction_type,
        quantity=data.quantity or data.factor or 0,
        price=data.price or 0,
        fees=data.fees,
        total_amount=total,
        notes=data.notes,
        executed_at=data.executed_at,
    )
    db.add(tx)
    await db.commit()
    await db.refresh(tx)
    return success_response(data={"id": tx.id}, message="Transaction recorded.")


@router.get("/{tx_id}")
async def get_transaction(tx_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Transaction).where(Transaction.id == tx_id))
    tx = result.scalar_one_or_none()
    if not tx:
        raise HTTPException(status_code=404, detail="Transaction not found.")
    return success_response(data={"id": tx.id, "type": tx.transaction_type, "quantity": float(tx.quantity or 0), "price": float(tx.price or 0)})
