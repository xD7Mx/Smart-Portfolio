from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.core.response import success_response
from app.models.portfolio import Holding, Portfolio, PortfolioSnapshot

router = APIRouter()

async def _get_holdings(db: AsyncSession):
    result = await db.execute(select(Holding).options(selectinload(Holding.company)))
    holdings = result.scalars().all()
    # Refresh from live prices (15-min cache) so the dashboard never shows stale zeros.
    from app.api.v1.endpoints.holdings import refresh_holdings_prices
    await refresh_holdings_prices(db, holdings)
    return holdings

@router.get("")
async def get_portfolio(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Portfolio).limit(1))
    p = result.scalar_one_or_none()
    if not p:
        return success_response(data={"id": 1, "name": "My Portfolio", "mode": "BUILD"})
    return success_response(data={"id": p.id, "name": p.name, "mode": p.mode})

@router.get("/summary")
async def get_portfolio_summary(db: AsyncSession = Depends(get_db)):
    holdings = await _get_holdings(db)
    total_invested = sum(float(h.invested_amount or 0) for h in holdings)
    market_value = sum(float(h.market_value or 0) for h in holdings)
    roi_pct = ((market_value - total_invested) / total_invested * 100) if total_invested else 0
    annual_income = sum(float(h.total_dividends_received or 0) for h in holdings)
    return success_response(data={
        "total_invested": total_invested,
        "total_current_value": market_value,
        "market_value": market_value,
        "total_cost": total_invested,
        "roi_pct": roi_pct,
        "annual_income": annual_income,
    })

@router.get("/health")
async def get_portfolio_health(db: AsyncSession = Depends(get_db)):
    """Portfolio evaluation — based on the actual financial/technical analysis
    of the held companies (market-value-weighted), NOT on paper profit/loss.
    A portfolio can be up in price yet hold weak-fundamental companies, and
    vice versa; the verdict must reflect company quality, not luck of timing.
    """
    holdings = await _get_holdings(db)
    if not holdings:
        return success_response(data={
            "health_score": None, "verdict": "NO_DATA", "label": "لا توجد بيانات",
            "companies_scored": 0, "companies_total": 0, "coverage_pct": 0,
        })

    weighted_sum = 0.0
    weight_total = 0.0
    scored = 0
    for h in holdings:
        mv = float(h.market_value or 0)
        c = h.company
        if mv <= 0 or not c:
            continue
        fin = float(c.finance_score) if c.finance_score is not None else None
        tech = float(c.technical_score) if c.technical_score is not None else None
        parts = [v for v in (fin, tech) if v is not None]
        if not parts:
            continue
        overall = sum(parts) / len(parts)
        weighted_sum += overall * mv
        weight_total += mv
        scored += 1

    total = len(holdings)
    coverage_pct = round((scored / total) * 100) if total else 0

    if weight_total <= 0:
        return success_response(data={
            "health_score": None, "verdict": "NO_DATA",
            "label": "لا توجد بيانات تحليل كافية بعد — تُبنى تلقائياً مع مرور الوقت",
            "companies_scored": scored, "companies_total": total, "coverage_pct": coverage_pct,
        })

    score = round(weighted_sum / weight_total, 1)
    if score >= 70:
        verdict, label = "STRONG", "محفظة قوية"
    elif score >= 45:
        verdict, label = "AVERAGE", "محفظة متوسطة"
    else:
        verdict, label = "WEAK", "محفظة ضعيفة"

    return success_response(data={
        "health_score": score,
        "verdict": verdict,
        "label": label,
        "deviation": round(score - 50, 1),  # signed distance from the 50 midpoint, for the diverging bar
        "companies_scored": scored,
        "companies_total": total,
        "coverage_pct": coverage_pct,
    })

@router.get("/roi")
async def get_portfolio_roi(db: AsyncSession = Depends(get_db)):
    holdings = await _get_holdings(db)
    total_invested = sum(float(h.invested_amount or 0) for h in holdings)
    market_value = sum(float(h.market_value or 0) for h in holdings)
    dividends = sum(float(h.total_dividends_received or 0) for h in holdings)
    capital_roi = ((market_value - total_invested) / total_invested * 100) if total_invested else 0
    dividend_roi = (dividends / total_invested * 100) if total_invested else 0
    return success_response(data={
        "capital_roi": capital_roi,
        "dividend_roi": dividend_roi,
        "total_roi": capital_roi + dividend_roi,
    })

@router.get("/income")
async def get_portfolio_income(db: AsyncSession = Depends(get_db)):
    holdings = await _get_holdings(db)
    annual_income = sum(float(h.total_dividends_received or 0) for h in holdings)
    return success_response(data={
        "annual_income": annual_income,
        "monthly_income": annual_income / 12,
    })

@router.get("/history")
async def get_portfolio_history(days: int = 365, db: AsyncSession = Depends(get_db)):
    """Real daily snapshots — accumulates one point per day automatically."""
    result = await db.execute(
        select(PortfolioSnapshot).order_by(PortfolioSnapshot.snapshot_date.desc()).limit(days)
    )
    rows = list(result.scalars().all())[::-1]
    return success_response(data=[
        {
            "date": r.snapshot_date.isoformat(),
            "market_value": float(r.market_value or 0),
            "invested_amount": float(r.invested_amount or 0),
            "cash_balance": float(r.cash_balance or 0),
            "unrealized_profit": float(r.unrealized_profit or 0),
        }
        for r in rows
    ])

@router.post("/snapshot")
async def create_snapshot_now(db: AsyncSession = Depends(get_db)):
    """Manually record today's snapshot (idempotent — upserts today's row)."""
    from app.services.snapshots import take_snapshot
    snap = await take_snapshot(db)
    return success_response(data={
        "date": snap.snapshot_date.isoformat(),
        "market_value": float(snap.market_value or 0),
        "invested_amount": float(snap.invested_amount or 0),
    })

@router.get("/metrics")
async def get_portfolio_metrics(db: AsyncSession = Depends(get_db)):
    """Portfolio-level financial indicators — market-value-weighted averages of
    each holding's PE / dividend yield / ROE / EPS, plus analyst-target upside.
    Fundamentals come from the 30-day cache, so this is quota-cheap."""
    from app.services.market_data import market_service
    from app.api.v1.endpoints.holdings import yahoo_symbol
    holdings = await _get_holdings(db)
    rows, total_w = [], 0.0
    for h in holdings:
        if not h.company or float(h.market_value or 0) <= 0:
            continue
        info = await market_service.get_company_info(yahoo_symbol(h.company.symbol)) or {}
        w = float(h.market_value or 0)
        rows.append((w, info, float(h.last_price or 0)))
        total_w += w
    if not rows or total_w <= 0:
        return success_response(data=None)

    def wavg(key):
        num = sum(w * info[key] for w, info, _ in rows if isinstance(info.get(key), (int, float)))
        den = sum(w for w, info, _ in rows if isinstance(info.get(key), (int, float)))
        return round(num / den, 2) if den else None

    # analyst upside: weighted (target-price / last-price - 1)
    up_num = up_den = 0.0
    for w, info, lp in rows:
        tgt = info.get("target_mean_price")
        if isinstance(tgt, (int, float)) and lp > 0:
            up_num += w * (tgt / lp - 1) * 100
            up_den += w
    upside = round(up_num / up_den, 1) if up_den else None

    return success_response(data={
        "pe_ratio": wavg("pe_ratio"),
        "dividend_yield": wavg("dividend_yield"),
        "roe": wavg("roe"),
        "eps": wavg("eps"),
        "profit_margin": wavg("profit_margin"),
        "analyst_upside_pct": upside,
        "companies_covered": len(rows),
    })


@router.get("/statistics")
async def get_portfolio_statistics(db: AsyncSession = Depends(get_db)):
    holdings = await _get_holdings(db)
    sectors = sorted({h.company.sector for h in holdings if h.company and h.company.sector})
    return success_response(data={
        "companies_count": len(holdings),
        "total_shares": sum(float(h.quantity or 0) for h in holdings),
        "sectors": sectors,
    })
