from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.response import success_response
from app.models.market import Goal
from pydantic import BaseModel
from typing import Optional
from datetime import datetime

router = APIRouter()

class GoalCreate(BaseModel):
    goal_name: str
    target_value: float
    deadline: Optional[datetime] = None

@router.get("")
async def get_goals(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Goal))
    goals = result.scalars().all()
    return success_response(data=[{"id": g.id, "name": g.goal_name, "target": float(g.target_value), "current": float(g.current_value or 0), "pct": float(g.completion_percentage or 0)} for g in goals])

@router.post("")
async def add_goal(data: GoalCreate, db: AsyncSession = Depends(get_db)):
    goal = Goal(**data.model_dump())
    db.add(goal)
    await db.commit()
    await db.refresh(goal)
    return success_response(data={"id": goal.id}, message="Goal created.")

@router.get("/progress")
async def get_goals_progress(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Goal))
    goals = result.scalars().all()
    return success_response(data=[{"name": g.goal_name, "pct": float(g.completion_percentage or 0)} for g in goals])

@router.patch("/{goal_id}")
async def update_goal(goal_id: int, current_value: float, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Goal).where(Goal.id == goal_id))
    goal = result.scalar_one_or_none()
    if not goal:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Goal not found.")
    goal.current_value = current_value
    if goal.target_value > 0:
        goal.completion_percentage = min(current_value / float(goal.target_value) * 100, 100)
    await db.commit()
    return success_response(message="Goal updated.")
