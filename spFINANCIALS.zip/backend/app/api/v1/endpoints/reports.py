from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from datetime import date
from app.core.database import get_db
from app.core.response import success_response
from app.models.market import Report, ReportType

router = APIRouter()

_PERIOD_AR = {"DAILY": "يومي", "WEEKLY": "أسبوعي", "MONTHLY": "شهري", "ANNUAL": "سنوي", "QUARTERLY": "ربع سنوي"}


@router.get("")
async def get_reports(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Report).order_by(Report.generated_at.desc()).limit(30))
    items = result.scalars().all()
    return success_response(data=[{
        "id": r.id,
        "type": r.report_type.value if hasattr(r.report_type, "value") else r.report_type,
        "period": r.report_period,
        "generated_at": r.generated_at.isoformat() if r.generated_at else None,
        "has_content": bool(r.summary),
    } for r in items])


@router.get("/{report_id}")
async def get_report(report_id: int, db: AsyncSession = Depends(get_db)):
    r = (await db.execute(select(Report).where(Report.id == report_id))).scalar_one_or_none()
    if not r:
        raise HTTPException(status_code=404, detail="Report not found.")
    return success_response(data={
        "id": r.id,
        "type": r.report_type.value if hasattr(r.report_type, "value") else r.report_type,
        "period": r.report_period,
        "generated_at": r.generated_at.isoformat() if r.generated_at else None,
        **(r.summary or {}),
    })


@router.delete("/{report_id}")
async def delete_report(report_id: int, db: AsyncSession = Depends(get_db)):
    r = (await db.execute(select(Report).where(Report.id == report_id))).scalar_one_or_none()
    if not r:
        raise HTTPException(status_code=404, detail="Report not found.")
    await db.delete(r)
    await db.commit()
    return success_response(message="تم حذف التقرير.")


@router.post("/generate")
async def generate_report(report_type: str = "WEEKLY", db: AsyncSession = Depends(get_db)):
    """Build a real report: portfolio snapshot + weighted metrics + a Gemini
    Arabic narrative, persisted so it stays in the archive."""
    report_type = (report_type or "WEEKLY").upper()
    try:
        rtype = ReportType[report_type]
    except KeyError:
        rtype = ReportType.WEEKLY

    from app.api.v1.endpoints.portfolio import _get_holdings
    from app.api.v1.endpoints.ai import _portfolio_snapshot
    from app.services.ai_content import portfolio_report

    holdings = await _get_holdings(db)
    total_invested = sum(float(h.invested_amount or 0) for h in holdings)
    market_value = sum(float(h.market_value or 0) for h in holdings)
    dividends = sum(float(h.total_dividends_received or 0) for h in holdings)
    roi = ((market_value - total_invested) / total_invested * 100) if total_invested else 0

    positions = [{
        "name": h.company.company_name if h.company else "",
        "symbol": h.company.symbol if h.company else "",
        "shares": float(h.quantity or 0),
        "market_value": float(h.market_value or 0),
        "pnl": float(h.unrealized_profit or 0),
        "pnl_pct": float(h.unrealized_profit_pct or 0),
    } for h in holdings if float(h.quantity or 0) > 0]

    narrative = None
    try:
        hs, cash = await _portfolio_snapshot(db)
        rep = await portfolio_report(hs, cash)
        narrative = (rep or {}).get("content")
    except Exception:
        narrative = None

    content = {
        "content": narrative,
        "metrics": {
            "total_invested": total_invested,
            "market_value": market_value,
            "unrealized_pnl": market_value - total_invested,
            "roi_pct": round(roi, 2),
            "dividends": dividends,
            "positions_count": len(positions),
        },
        "positions": positions,
    }

    r = Report(report_type=rtype, report_period=f"{_PERIOD_AR.get(report_type, report_type)} — {date.today().isoformat()}", summary=content)
    db.add(r)
    await db.commit()
    await db.refresh(r)
    return success_response(data={"id": r.id}, message="تم إنشاء التقرير.")
