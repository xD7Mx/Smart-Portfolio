from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.response import success_response
from app.models.market import Notification, NotificationStatus
from datetime import datetime, timezone

router = APIRouter()

@router.get("")
async def get_notifications(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Notification).where(Notification.status != NotificationStatus.ARCHIVED).order_by(Notification.created_at.desc()).limit(50))
    items = result.scalars().all()
    return success_response(data=[{"id": n.id, "title": n.title, "message": n.message, "priority": n.priority, "status": n.status, "created_at": n.created_at.isoformat() if n.created_at else None} for n in items])

@router.patch("/{notif_id}/read")
async def mark_as_read(notif_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Notification).where(Notification.id == notif_id))
    n = result.scalar_one_or_none()
    if n:
        n.status = NotificationStatus.READ
        n.read_at = datetime.now(timezone.utc)
        await db.commit()
    return success_response(message="Marked as read.")

@router.delete("/{notif_id}")
async def delete_notification(notif_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Notification).where(Notification.id == notif_id))
    n = result.scalar_one_or_none()
    if n:
        n.status = NotificationStatus.ARCHIVED
        await db.commit()
    return success_response(message="Notification archived.")
