from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.response import success_response
from app.models.market import Backup

router = APIRouter()

@router.get("")
async def get_backups(db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Backup).order_by(Backup.created_at.desc()).limit(10))
    items = result.scalars().all()
    return success_response(data=[{"id": b.id, "name": b.backup_name, "type": b.backup_type, "size": b.file_size, "created_at": b.created_at.isoformat() if b.created_at else None} for b in items])

@router.post("/create")
async def create_backup():
    return success_response(message="Backup creation queued.")

@router.post("/restore")
async def restore_backup(backup_id: int):
    return success_response(message=f"Restore from backup {backup_id} queued.")
