from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.core.response import success_response
from app.models.market import MarketNews, MarketEvent

router = APIRouter()


def _normalize_symbol(symbol: str) -> str:
    """Saudi tickers are pure digits on Yahoo as e.g. 2222.SR."""
    s = symbol.strip().upper()
    if s.isdigit() and not s.endswith(".SR"):
        return f"{s}.SR"
    return s


def _clamp(v, lo=0, hi=100):
    return max(lo, min(hi, v))


@router.get("/history/{symbol}")
async def get_price_history(symbol: str, range: str = "3mo"):
    """Daily close history for charts — cached 24h per symbol."""
    from app.services.market_data import market_service
    if range not in ("1mo", "3mo", "6mo", "1y", "2y", "5y"):
        range = "6mo"
    points = None
    if hasattr(market_service.primary, "get_history"):
        points = await market_service.primary.get_history(_normalize_symbol(symbol), range)
    return success_response(data=points or [])


@router.get("/library")
async def get_market_library():
    """Sahmak monthly company library (empty until API paths confirmed)."""
    from app.services import sahmak_library
    lib = await sahmak_library.company_library()
    return success_response(data=lib)


@router.get("/company/{symbol}")
async def get_company_analysis(symbol: str):
    """Full automatic analysis (no button): live price + full fundamentals +
    financial verdict + technical verdict + strengths/weaknesses + AI score/100
    + investment decision. Cached 24h so a page open costs no extra calls."""
    from app.services.analysis import analyze_company
    ysym = _normalize_symbol(symbol)
    data = await analyze_company(ysym)
    if not data:
        raise HTTPException(status_code=404, detail="No data found for this symbol.")
    data["symbol"] = symbol
    # Flatten common fundamentals to the top level so existing UI keeps working.
    f = data.get("fundamentals") or {}
    for k in ("market_cap", "revenue", "net_income", "eps", "pe_ratio", "roe", "roa",
              "profit_margin", "dividend_yield", "week52_low", "week52_high",
              "avg_volume", "target_mean_price"):
        data.setdefault(k, f.get(k))
    data["overall_score"] = data.get("ai_score")
    return success_response(data=data)


def _financial_verdict(periods: list) -> str:
    """Deterministic, rule-based executive verdict — computed from the exact
    same real signals as the finance score (see scores.py), not a free-text
    AI guess. Chosen deliberately: an investor's decision sentence must be
    as traceable and reproducible as the numbers behind it.

    Rising debt and a profit dip are not automatically treated as weakness:
    when heavy capex accompanies steady-or-growing revenue (see
    scores.is_investment_phase), that pattern is a plausible sign of funded
    expansion, not distress — and the verdict says so explicitly rather
    than silently scoring it either way, so the investor sees the
    reasoning, not just a conclusion."""
    from app.services.scores import is_investment_phase
    if not periods:
        return "بيانات متاحة"
    latest = periods[-1]
    prev = periods[-2] if len(periods) >= 2 else None

    def yoy(field):
        if not prev:
            return None
        a, b = latest.get(field), prev.get(field)
        if a is None or not b:
            return None
        return (a - b) / abs(b) * 100

    rev_g = yoy("revenue")
    ni_g = yoy("net_income")
    ni = latest.get("net_income")
    ocf = latest.get("operating_cash_flow")
    quality_ok = ocf is not None and ni and ni != 0 and (ocf / ni) >= 0.8
    fcf = latest.get("free_cash_flow")
    debt_rising = prev and latest.get("debt_ratio") is not None and prev.get("debt_ratio") is not None \
        and latest["debt_ratio"] > prev["debt_ratio"]
    coverage = latest.get("interest_coverage")
    weak_coverage = coverage is not None and coverage < 2
    profit_declining = ni_g is not None and ni_g < 0
    inv_phase = is_investment_phase(periods)

    # Highest-priority warnings first — these are real risk facts regardless
    # of any growth narrative, so they are never softened by capex context.
    if ni is not None and ni < 0:
        return "خسائر تشغيلية — يتطلب حذراً"
    if weak_coverage:
        return "تغطية فوائد ضعيفة — مخاطر خدمة الدين"
    if ocf is not None and ni and ocf < 0 < ni:
        return "نمو محاسبي بلا نقد — تحذير جودة الأرباح"

    # Debt-funded expansion: explained explicitly rather than folded into a
    # plain "growth" or "decline" sentence.
    if debt_rising and inv_phase:
        if rev_g is not None and rev_g >= 0 and quality_ok:
            return "توسع استثماري مموَّل بالدين — الإيرادات مستقرة/نامية ورأس المال يُعاد استثماره؛ ارتفاع الدين هنا لا يعني ضعفاً بالضرورة"
        if profit_declining:
            return "انخفاض مؤقت في الربح مع دين مرتفع، مرتبطان بنفقات رأسمالية توسعية — راقب تحوّل الاستثمار إلى نمو قادم"

    if rev_g is not None:
        if rev_g > 0 and quality_ok and fcf is not None and fcf > 0 and not debt_rising:
            return "قوة أرباح ونمو حقيقي مدعوم بنقد ✓"
        if rev_g > 0 and quality_ok and debt_rising:
            return "نمو مدعوم بأرباح سليمة، مع ارتفاع دين غير مرتبط بوضوح باستثمار رأسمالي — راقب السبب"
        if rev_g > 0 and quality_ok:
            return "نمو مدعوم بأرباح سليمة"
        if rev_g > 0:
            return "نمو إيرادات مع ضغط على جودة الأرباح"
        if rev_g < 0:
            return "تراجع في الإيرادات — يتطلب مراجعة"
    if quality_ok and not debt_rising:
        return "ربحية مستقرة بلا نمو ملحوظ"
    return "بيانات متاحة"


@router.get("/financials/{symbol}")
async def get_company_financials(symbol: str):
    """Three-year income/balance/cashflow with YoY change + section grouping +
    a deterministic, rule-based executive verdict — powers the governance
    report and is the exact same real basis the AI's finance score uses."""
    from app.services.market_data import market_service
    data = await market_service.get_financials(_normalize_symbol(symbol))
    if not data or not data.get("periods"):
        return success_response(data=None, message="لا توجد قوائم مالية متاحة لهذا الرمز حالياً.")

    periods = data["periods"]
    latest, prev = periods[-1], (periods[-2] if len(periods) >= 2 else None)

    def yoy(field):
        if not prev:
            return None
        a, b = latest.get(field), prev.get(field)
        if a is None or not b:
            return None
        return round((a - b) / abs(b) * 100, 1)

    from app.services.scores import is_investment_phase
    return success_response(data={
        "symbol": symbol,
        "years": [p["year"] for p in periods],
        "periods": periods,
        "changes": {k: yoy(k) for k in (
            "revenue", "net_income", "eps", "equity", "debt_ratio",
            "operating_cash_flow", "ending_cash", "free_cash_flow", "interest_coverage",
        )},
        "verdict": _financial_verdict(periods),
        "investment_phase": is_investment_phase(periods),
    })


@router.get("/dividends/{symbol}")
async def get_company_dividends(symbol: str):
    """Dividend profile: frequency, last-10-years history, and an upcoming/last
    distribution note (e.g. 'أحقية قادمة بعد يومين' / 'آخر توزيع قبل أسبوعين')."""
    from app.services.market_data import market_service
    from datetime import date
    data = await market_service.get_dividends(_normalize_symbol(symbol))
    if not data:
        return success_response(data=None, message="لا توجد بيانات توزيعات متاحة لهذا الرمز حالياً.")

    # last 10 announced years, aggregated per year
    from collections import defaultdict
    by_year = defaultdict(float)
    for h in data.get("history", []):
        by_year[h["year"]] += h["amount"]
    years = sorted(by_year.keys())[-10:]
    yearly = [{"year": y, "amount": round(by_year[y], 3)} for y in years]

    # note about the next ex/eligibility date or the last distribution
    note = None
    today = date.today()
    ref = data.get("ex_date") or data.get("pay_date")
    try:
        if ref:
            d = date.fromisoformat(ref)
            days = (d - today).days
            if days > 0:
                note = {"type": "upcoming", "text": f"أحقية/توزيع قادم بعد {days} يوم ({ref})"}
            elif days == 0:
                note = {"type": "today", "text": f"يوم الأحقية اليوم ({ref})"}
            else:
                note = {"type": "past", "text": f"آخر أحقية قبل {abs(days)} يوم ({ref})"}
    except Exception:
        note = None
    if not note and data.get("history"):
        last = data["history"][-1]
        try:
            days = (today - date.fromisoformat(last["date"])).days
            note = {"type": "past", "text": f"آخر توزيع معلن قبل {days} يوم ({last['date']}) بقيمة {last['amount']} للسهم"}
        except Exception:
            pass

    return success_response(data={
        "symbol": symbol,
        "frequency": data.get("frequency"),
        "ex_date": data.get("ex_date"),
        "pay_date": data.get("pay_date"),
        "yearly": yearly,
        "recent": data.get("history", [])[-8:][::-1],
        "note": note,
    })


@router.get("/ownership/{symbol}")
async def get_company_ownership(symbol: str):
    """Ownership structure (insiders / institutions / public float)."""
    from app.services.market_data import market_service
    data = await market_service.get_ownership(_normalize_symbol(symbol))
    return success_response(data=data)

async def _portfolio_symbols(db: AsyncSession) -> list[str]:
    from app.models.portfolio import Company
    result = await db.execute(select(Company.symbol).where(Company.status != "ARCHIVED"))
    return [row[0] for row in result.all()]


@router.get("/overview")
async def market_overview(db: AsyncSession = Depends(get_db)):
    """Live tickers (each cached 15 min): TASI index, Brent crude, Gold futures."""
    import asyncio as _aio
    from app.services.market_data import market_service
    tasi, brent, gold = await _aio.gather(
        market_service.get_price("^TASI.SR"),
        market_service.get_price("BZ=F"),   # Brent crude futures (USD)
        market_service.get_price("GC=F"),   # Gold futures (USD/oz)
    )
    return success_response(data={
        "tasi": tasi,
        "brent": brent,
        "gold": gold,
        "status": "ok" if (tasi or brent or gold) else "unavailable",
    })

async def _ensure_news(db: AsyncSession):
    """Populate the news feed on first view instead of waiting for the daily job."""
    have = (await db.execute(select(MarketNews.id).limit(1))).scalar_one_or_none()
    if have is None:
        try:
            from app.services.content_engine import refresh_news
            await refresh_news(db)  # respects the 1h guard; startup usually did this
        except Exception:
            pass


@router.get("/summary")
async def get_market_summary(db: AsyncSession = Depends(get_db)):
    """AI market brief about TASI (index environment up to last close) — NOT the
    user's portfolio. Rule-based text always, Gemini narrative when available."""
    import asyncio as _aio
    from app.services.market_data import market_service
    tasi, brent, gold = await _aio.gather(
        market_service.get_price("^TASI.SR"),
        market_service.get_price("BZ=F"),
        market_service.get_price("GC=F"),
    )
    # top market headlines for context
    rows = (await db.execute(
        select(MarketNews).order_by(MarketNews.published_at.desc().nullslast()).limit(6)
    )).scalars().all()
    headlines = [n.headline for n in rows]

    def part(name, d, unit=""):
        if not d or d.get("price") is None:
            return None
        return f"{name} عند {d['price']:,.2f}{unit} ({d.get('change_pct', 0):+.2f}%)"
    bits = [p for p in [part("مؤشر تاسي", tasi), part("برنت", brent, "$"), part("الذهب", gold, "$")] if p]
    rule = ("حتى آخر إغلاق: " + "، ".join(bits) + "." ) if bits else "بيانات المؤشرات غير متاحة حالياً."
    if tasi and tasi.get("change_pct") is not None:
        rule += " اتجاه السوق " + ("إيجابي" if tasi["change_pct"] >= 0 else "هابط") + " اليوم."

    summary = rule
    source = "rule"
    try:
        from app.services.ai_content import market_brief
        ai = await market_brief(tasi, brent, gold, headlines)
        if ai:
            summary = ai
            source = "AI"
    except Exception:
        pass
    return success_response(data={"summary": summary, "source": source,
                                  "tasi": tasi, "brent": brent, "gold": gold,
                                  "headlines": headlines})


@router.get("/news")
async def get_news(db: AsyncSession = Depends(get_db)):
    await _ensure_news(db)
    result = await db.execute(select(MarketNews).order_by(MarketNews.published_at.desc().nullslast()).limit(25))
    news = result.scalars().all()
    if news:
        return success_response(data=[{"id": n.id, "headline": n.headline, "company": n.company_symbol, "source": n.provider, "url": n.url, "category": n.category, "published": n.published_at.isoformat() if n.published_at else None} for n in news])
    from app.services.ai_content import market_news
    return success_response(data=await market_news(await _portfolio_symbols(db)))

@router.get("/events")
async def get_events(db: AsyncSession = Depends(get_db)):
    # Real stored events first; otherwise a Gemini-generated forward calendar (cached 24h).
    result = await db.execute(select(MarketEvent).order_by(MarketEvent.event_date.desc()).limit(20))
    events = result.scalars().all()
    if events:
        return success_response(data=[{"id": e.id, "type": e.event_type, "symbol": e.company_symbol, "date": e.event_date.isoformat() if e.event_date else None} for e in events])
    from app.services.ai_content import upcoming_events
    return success_response(data=await upcoming_events(await _portfolio_symbols(db)))

@router.get("/economic-news")
async def get_economic_news(db: AsyncSession = Depends(get_db)):
    """Real stored economic/macro news (Google News). Self-populates on first view."""
    await _ensure_news(db)
    rows = (await db.execute(
        select(MarketNews).where(MarketNews.category == "اقتصاد")
        .order_by(MarketNews.published_at.desc().nullslast()).limit(8)
    )).scalars().all()
    if not rows:
        # no dedicated economic rows — show the freshest market news instead
        rows = (await db.execute(
            select(MarketNews).order_by(MarketNews.published_at.desc().nullslast()).limit(8)
        )).scalars().all()
    return success_response(data=[{
        "id": n.id, "headline": n.headline, "category": n.category or "اقتصاد",
        "impact": "محايد", "company": n.company_symbol, "source": n.provider,
        "url": n.url, "published": n.published_at.isoformat() if n.published_at else None,
    } for n in rows])


@router.get("/feedstock")
async def get_feedstock():
    """Saudi official feedstock (اللقيم) reference prices — government-set, not a
    live market. Shown as reference because they drive petrochem margins."""
    return success_response(data={
        "note": "أسعار اللقيم المرجعية — تُحدَّد حكومياً وتؤثر على هوامش البتروكيماويات",
        "items": [
            {"name": "الميثان (الغاز الطبيعي)", "price": 1.25, "unit": "$/MMBtu"},
            {"name": "الإيثان", "price": 0.75, "unit": "$/MMBtu"},
            {"name": "البروبان", "price": 430, "unit": "$/طن (مرتبط بأرامكو)"},
            {"name": "البيوتان", "price": 425, "unit": "$/طن (مرتبط بأرامكو)"},
        ],
    })


@router.get("/results")
async def get_financial_results(db: AsyncSession = Depends(get_db)):
    return success_response(data=[], message="Financial results feed.")

@router.get("/dividends")
async def get_market_dividends(db: AsyncSession = Depends(get_db)):
    return success_response(data=[], message="Dividend calendar.")
