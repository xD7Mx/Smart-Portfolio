import asyncio
import httpx
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession
from loguru import logger
from app.core.database import get_db
from app.core.response import success_response
from app.core.config import settings as cfg

router = APIRouter()


# ── Real connectivity checks for each external integration ──────
async def _check_yahoo() -> dict:
    """Live check: fetch a well-known symbol via Yahoo Finance."""
    if not cfg.YAHOO_FINANCE_ENABLED:
        return {"status": "disabled", "detail": "Disabled in settings"}
    # Query Yahoo's public chart API directly (more reliable than the yfinance lib,
    # which frequently breaks when Yahoo changes its internal endpoints).
    headers = {"User-Agent": "Mozilla/5.0"}
    for sym in ("2222.SR", "1120.SR", "AAPL", "MSFT"):
        try:
            url = f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}?range=1d&interval=1d"
            async with httpx.AsyncClient(timeout=6, headers=headers) as client:
                r = await client.get(url)
            if r.status_code == 200:
                result = r.json().get("chart", {}).get("result")
                if result:
                    price = result[0].get("meta", {}).get("regularMarketPrice")
                    if price:
                        return {"status": "up", "detail": f"{sym} = {round(float(price), 2)}"}
        except Exception:
            continue
    return {"status": "down", "detail": "No price returned"}


async def _check_gemini() -> dict:
    """Check Gemini key by listing models (light, no generation quota)."""
    if not cfg.AI_API_KEY:
        return {"status": "not_configured", "detail": "No API key set"}
    try:
        url = f"https://generativelanguage.googleapis.com/v1beta/models?key={cfg.AI_API_KEY}"
        async with httpx.AsyncClient(timeout=6) as client:
            r = await client.get(url)
        if r.status_code == 200:
            return {"status": "up", "detail": "Key valid"}
        return {"status": "down", "detail": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"status": "down", "detail": str(e)[:120]}


async def _check_sahmak() -> dict:
    """Check Sahmak provider key/connectivity."""
    if not cfg.SAHMAK_API_KEY:
        return {"status": "not_configured", "detail": "No API key set"}
    try:
        async with httpx.AsyncClient(timeout=6) as client:
            r = await client.get(
                cfg.SAHMAK_BASE_URL,
                headers={"Authorization": f"Bearer {cfg.SAHMAK_API_KEY}"},
            )
        if r.status_code < 500:
            return {"status": "up", "detail": f"Reachable (HTTP {r.status_code})"}
        return {"status": "down", "detail": f"HTTP {r.status_code}"}
    except Exception as e:
        return {"status": "down", "detail": str(e)[:120]}


def _gemini_quota() -> dict:
    try:
        from app.agents.coordinator import coordinator
        q = coordinator.quota_status()
        return {"daily_used": q.get("daily_used", 0), "daily_limit": cfg.GEMINI_DAILY_LIMIT}
    except Exception:
        return {"daily_used": 0, "daily_limit": cfg.GEMINI_DAILY_LIMIT}


# Cache the health-check result so the settings page auto-refresh (every 30s) does
# NOT hammer the providers on every load — this protects paid quotas (e.g. Sahmak
# 100/day) and avoids triggering Yahoo rate-limits. Providers are re-checked at most
# once per _HEALTH_TTL seconds regardless of how many clients are watching.
import time as _time
_health_cache = {"ts": 0.0, "data": None}
_HEALTH_TTL = 120  # seconds


@router.get("/integrations")
async def get_integrations(refresh: bool = False):
    """Health status + usage quota of every data source. Cached for _HEALTH_TTL
    seconds so it never drains provider quotas. Pass ?refresh=true to force a live check."""
    from app.services.usage_tracker import usage

    now = _time.time()
    if not refresh and _health_cache["data"] and (now - _health_cache["ts"] < _HEALTH_TTL):
        cached = _health_cache["data"]
    else:
        async def _safe(coro):
            try:
                return await asyncio.wait_for(coro, timeout=8)
            except Exception as e:
                return {"status": "down", "detail": str(e)[:120] or "Timeout"}

        yahoo, gemini, sahmak = await asyncio.gather(
            _safe(_check_yahoo()), _safe(_check_gemini()), _safe(_check_sahmak())
        )
        cached = {"yahoo": yahoo, "gemini": gemini, "sahmak": sahmak}
        _health_cache["ts"] = now
        _health_cache["data"] = cached

    # Quota counters are always live (cheap, in-memory) even when health is cached.
    yahoo = {**cached["yahoo"], **usage("yahoo")}
    sahmak = {**cached["sahmak"], **usage("sahmak")}
    gemini = {**cached["gemini"], **_gemini_quota()}

    data = [
        {"id": "yahoo",  "name": "Yahoo Finance", "name_ar": "ياهو المالية", "kind": "market", **yahoo},
        {"id": "sahmak", "name": "Sahmak",        "name_ar": "سهمك",         "kind": "market", **sahmak},
        {"id": "gemini", "name": "Gemini AI",     "name_ar": "جيمناي",       "kind": "ai",     **gemini},
    ]
    return success_response(data=data)

@router.get("")
async def get_settings():
    return success_response(data={"app": cfg.APP_NAME, "version": cfg.APP_VERSION, "currency": cfg.DEFAULT_CURRENCY, "ai_provider": cfg.AI_PROVIDER, "ai_model": cfg.AI_MODEL, "telegram_enabled": cfg.TELEGRAM_ENABLED, "backup_enabled": cfg.BACKUP_ENABLED})

@router.get("/system")
async def get_system_settings():
    return success_response(data={"env": cfg.APP_ENV, "debug": cfg.DEBUG, "scheduler": cfg.SCHEDULER_ENABLED})

@router.get("/ai")
async def get_ai_settings():
    return success_response(data={"provider": cfg.AI_PROVIDER, "model": cfg.AI_MODEL, "temperature": cfg.AI_TEMPERATURE, "max_tokens": cfg.AI_MAX_TOKENS, "key_configured": bool(cfg.AI_API_KEY)})

@router.get("/telegram")
async def get_telegram_settings():
    return success_response(data={"enabled": cfg.TELEGRAM_ENABLED, "username": cfg.TELEGRAM_BOT_USERNAME})

@router.get("/providers")
async def get_providers():
    return success_response(data={"primary": cfg.PRIMARY_MARKET_PROVIDER, "secondary": cfg.SECONDARY_MARKET_PROVIDER, "daily_limit": cfg.DAILY_API_LIMIT})
