"""
Smart Portfolio — Backend Entry Point
=====================================
Version: 1.0.0
Philosophy: AI Assists. Human Decides.
"""

import os
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse
from contextlib import asynccontextmanager
from loguru import logger

from app.core.config import settings
from app.core.database import init_db
from app.scheduler.scheduler import start_scheduler, stop_scheduler
from app.api.v1.router import api_router


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifecycle manager."""
    logger.info(f"🚀 Starting {settings.APP_NAME} v{settings.APP_VERSION}")
    await init_db()
    # Record today's portfolio snapshot if missing (uses cached prices only).
    try:
        from app.core.database import AsyncSessionLocal
        from app.services.snapshots import snapshot_if_missing_today
        async with AsyncSessionLocal() as db:
            await snapshot_if_missing_today(db)
            # Auto-analysis: scores fill themselves in — no manual trigger.
            from app.services.scores import refresh_company_scores
            await refresh_company_scores(db)
            # Populate & persist news / events / notifications so no screen is empty.
            from app.services.content_engine import refresh_all
            await refresh_all(db)
            # Self-heal: create the Dividend row for any historical DIVIDEND/
            # REINVESTMENT transaction that predates the dividends table wiring.
            from app.api.v1.endpoints.dividends import backfill_from_transactions
            backfilled = await backfill_from_transactions(db)
            if backfilled:
                logger.info(f"Backfilled {backfilled} dividend record(s) from historical transactions.")
    except Exception as e:
        logger.warning(f"Startup snapshot skipped: {e}")
    start_scheduler()
    logger.info("✅ Smart Portfolio is ready.")
    yield
    stop_scheduler()
    logger.info("👋 Smart Portfolio shutting down.")


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    description="AI-Powered Personal Investment Management Platform",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

# ── Middleware ────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(GZipMiddleware, minimum_size=1000)

# ── API Router ────────────────────────────────────────────────
app.include_router(api_router, prefix="/api/v1")


@app.get("/api", tags=["Root"])
async def root():
    return {
        "name": settings.APP_NAME,
        "version": settings.APP_VERSION,
        "motto": "حلّل أكثر... قرّر بنفسك.",
        "docs": "/api/docs",
    }

# ── Serve frontend (single-process deployment, no nginx) ───────
FRONTEND_BUILD = os.path.join(os.path.dirname(__file__), "..", "frontend", "build")
if os.path.isdir(FRONTEND_BUILD):
    app.mount("/assets", StaticFiles(directory=os.path.join(FRONTEND_BUILD, "assets")), name="assets")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_spa(full_path: str):
        return FileResponse(os.path.join(FRONTEND_BUILD, "index.html"))
